sap.ui.define([
	"zyldirtyflag/zyldirtyflag/test/unit/controller/View1.controller"
], function () {
	"use strict";
});