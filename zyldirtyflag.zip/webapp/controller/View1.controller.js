sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("zyldirtyflag.zyldirtyflag.controller.View1", {
		onInit: function () {
			this._oViewModel = this.getOwnerComponent().getModel("ViewModel");
			this._oViewModel.setProperty("/bIsDetailActive", false);
		},
		getRouter: function () {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},

		gotoMain: function () {
			this._oViewModel.setProperty("/edit", false);
			this.getRouter().navTo("main");
		}

	});
});