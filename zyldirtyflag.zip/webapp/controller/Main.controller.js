sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox"
], function (Controller, MessageBox) {
	"use strict";

	return Controller.extend("zyldirtyflag.zyldirtyflag.controller.Main", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf zyldirtyflag.zyldirtyflag.view.Main
		 */
		onInit: function () {
			this._oViewModel = this.getOwnerComponent().getModel("ViewModel");
			var g = this._getContainer().registerDirtyStateProvider(function (a) {
				// this.onBack();
			//	var x = 10;
			}.bind(this));
			this._oViewModel.setProperty("/data", {
				YardNo: "YardNo_1234",
				IdLoadingPoint: "ID_LoadingPoint_X",
				LoadingPointText: "LoadingPointText_XY"
			});
			this._oViewModel.setProperty("/edit", false);

			this._oOriginalCopy = Object.assign({}, this._oViewModel.getProperty("/data")); // set original data
			this._oViewModel.refresh(true);
		},

		onSave: function () {
			this._oOriginalCopy = Object.assign({}, this._oViewModel.getProperty("/data")); // set new changes as original copy
			this._oViewModel.setProperty("/edit", false);
		},

		onEdit: function () {
			this._oViewModel.setProperty("/edit", true);
		},

		onCancel: function () {
			this._oViewModel.setProperty("/edit", false);
		},

		_getContainer: function () {
			return sap.ushell && sap.ushell.Container ? sap.ushell.Container : {};
		},

		setDirtyFlag: function () {
			this._getContainer().setDirtyFlag(true);
		},

		clearDirtyFlag: function () {
			this._getContainer().setDirtyFlag(false);
		},

		onBack: function () {
			this._oChanges = Object.assign({}, this._oViewModel.getProperty("/data")); // get new changes
			this._oOriginalData = Object.assign({}, this._oOriginalCopy); // get original changes

			if (JSON.stringify(this._oOriginalData) !== JSON.stringify(this._oChanges)) {
				this._getContainer().setDirtyFlag(true);
				this.getRouter().navTo("RouteView1");
			} else {
				this.getRouter().navTo("RouteView1");
			}

			// ODATA model example
			// var oModel = this.getOwnerComponent().getModel();
			/*if (oModel.hasPendingChanges()) {
				MessageBox.warning("Changes made will be lost..!", {
					actions: [MessageBox.Action.YES, MessageBox.Action.NO],
					onClose: function (sAction) {
						if (sAction === "YES") {
							oModel.resetChanges("/LoadingPointSet(YardNo='R001',ID_LoadingPoint='R001_LP01')");
							this.getRouter().navTo("RouteView1");
						}
					}.bind(this)

				});
			} else {
				this.getRouter().navTo("RouteView1");
			}*/

		},
		getRouter: function () {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf zyldirtyflag.zyldirtyflag.view.Main
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf zyldirtyflag.zyldirtyflag.view.Main
		 */
		onAfterRendering: function () {
			/*
						// var oModel = this.getOwnerComponent().getModel();
						var oContext = new sap.ui.model.Context(this.getView().getModel(), "/LoadingPointSet");
						this.getView().setBindingContext(oContext);
					*/
		}

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf zyldirtyflag.zyldirtyflag.view.Main
		 */
		//	onExit: function() {
		//
		//	}

	});

});