sap.ui.define([
	"com/win/ewmpicking/test/unit/controller/App.controller"
], function () {
	"use strict";
});