sap.ui.define([
	"com/win/ewmpicking/controller/BaseController"
], function (BaseController) {
	"use strict";

	return BaseController.extend("com.win.ewmpicking.controller.Master", {
		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.win.ewmpicking.view.Master
		 */
		onInit: function () {
			this._oAppView = this.getOwnerComponent().getModel("AppView");
			this._setupMockData();
		},

		_setupMockData: function () {
			var aData = [{
				WarehouseTask: "10000005403",
				WarehouseOrder: "2000005710",
				Product: "TG11",
				ProcessType: "TP21",
				OutDeliveryOrder: "80002001",
				Status: "Open",
				Quantity: "10",
				Unit: "EA",
				Description: "Smart Phone, small part, fast moving, 5.5-inch, Storage 128GB",
				SourceBin: "S001-XUJ-01"
			}, {
				WarehouseTask: "10000005404",
				WarehouseOrder: "2000005710",
				Product: "TG11",
				ProcessType: "TP21",
				OutDeliveryOrder: "80002001",
				Status: "Open",
				Quantity: "15",
				Unit: "EA",
				Description: "Smart Phone, small part, fast moving, 5.5-inch, Storage 128GB",
				SourceBin: "S001-XUJ-02"
			}, {
				WarehouseTask: "10000005407",
				WarehouseOrder: "2000005711",
				Product: "TG11",
				ProcessType: "TP21",
				OutDeliveryOrder: "80002001",
				Status: "Open",
				Quantity: "6",
				Unit: "EA",
				Description: "Smart Phone, small part, fast moving, 5.5-inch, Storage 128GB",
				SourceBin: "S029-CEJ-01"
			}];
			this._oAppView.setProperty("/list", aData);
		},

		onListItemPress: function (oEvent) {
			var oNextUIState = this.getOwnerComponent().getHelper().getNextUIState(1),
				sPath = oEvent.getParameter("listItem").getBindingContext("AppView").getPath(),
				iIndex = sPath.split("/").slice(-1).pop();

			this.getRouter().navTo("detail", {
				layout: oNextUIState.layout,
				index: iIndex
			});
		}

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf com.win.ewmpicking.view.Master
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf com.win.ewmpicking.view.Master
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf com.win.ewmpicking.view.Master
		 */
		//	onExit: function() {
		//
		//	}

	});

});