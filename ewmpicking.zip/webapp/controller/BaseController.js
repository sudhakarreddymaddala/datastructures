sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/UIComponent",
	"sap/ui/core/Fragment",
	"sap/ui/core/syncStyleClass",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageBox",
	"sap/base/Log",
	"sap/f/GridListItem",
	"sap/m/MessageToast"
], function (Controller, UIComponent, Fragment, syncStyleClass, Filter, FilterOperator, MessageBox, Log, GridListItem,
	MessageToast) {
	"use strict";

	return Controller.extend("com.win.ewmpicking.controller.BaseController", {
		_oDialogSettings: {},

		/**
		 * <b>Convenience method for accessing the router</b>.
		 * 
		 * @returns {sap.ui.core.routing.Router} the router for this component
		 */
		getRouter: function () {
			return UIComponent.getRouterFor(this);
		},

		/**
		 * <b>Convenience method for getting the view model by name.</b>
		 * 
		 * @param {string} [sName] the model name
		 * @returns {sap.ui.model.Model} the model instance
		 */
		getModel: function (sName) {
			return this.getOwnerComponent().getModel(sName);
		},

		/**
		 * <b>Convenience method for setting the view model.</b>
		 * 
		 * @param {sap.ui.model.Model} oModel the model instance
		 * @param {string} sName the model name
		 * @returns {sap.ui.mvc.View} the view instance
		 */
		setModel: function (oModel, sName) {
			return this.getView().setModel(oModel, sName);
		},

		/**
		 * <b>Convenience method to get resource bundle.</b>
		 * 
		 * @returns {sap.ui.model.resource.ResourceModel} the resourceModel of the component
		 */
		getResourceBundle: function () {
			return this.getOwnerComponent().getModel("i18n").getResourceBundle();
		},

		/** 
		 * <b>Convenience method to get i18n text.</b>
		 *  
		 * @param {string} [sText] - i18n text name
		 * @param {string} [sParam] - Arguments to i18n text
		 * @returns Text from i18n
		 */
		_getI18nText: function (sText, sParam) {
			return this.getResourceBundle().getText(sText, [sParam]);
		},

		/** 
		 * <b>Shows error message from OData response</b>
		 * <ul> <li> Checks response text formate is JSON/XML</li>
		 * <li> Parse the error message from JSON/XML formate</li>
		 * <li> Displays parsed error message on sap.m.MessageBox</li>
		 * </ul>
		 * @param {object} [oError] - Error information from ODATA response
		 */
		_showResponseErrMsg: function (oError, fnCallback) {
			let fnIsJSON = (str) => {
				try {
					return (JSON.parse(str) && !!str);
				} catch (e) {
					return false;
				}
			};
			if (fnIsJSON(oError.responseText)) {
				MessageBox.error(JSON.parse(oError.responseText).error.message.value, {
					onClose: () => {
						if (fnCallback) {
							fnCallback();
						}
					}
				});
			} else {
				try {
					let oDOMParser = new DOMParser();
					let oXMLError = oDOMParser.parseFromString(oError.responseText, "application/xml");

					if (oError.statusCode === 503) {
						// For HTTP 503
						MessageBox.error(oXMLError.all[4].innerHTML, {
							actions: [MessageBox.Action.OK],
							onClose: function () {
								// Reload the app again
							}
						});
					} else {
						MessageBox.error(oXMLError.all[2].innerHTML, {
							onClose: () => {
								if (fnCallback) {
									fnCallback();
								}
							}
						});
					}

				} catch (e) {
					MessageBox.error(e, {
						onClose: () => {
							if (fnCallback) {
								fnCallback();
							}
						}
					});
				}
			}
		},

		/** 
		 * <b> Convenience method to open sap.ui.core.Fragment </b>
		 * <ul><li>Loads fragment by given fragment path</li>
		 * <li> Initiates loaded fragment to this._oDialog local instance</li>
		 * <li> Adds loaded fragment to the view and applies CSS size compart to fragment </li>
		 * <li> Opens sap.ui.core.Fragment </li>
		 * <ul>
		 * @param {string} [sFragmentPath] - Fragment path
		 */
		openFragment: function (sFragmentPath, bIsInitialLoader = false) {
			return new Promise(function (fnResolve) {
				// load BusyDialog fragment asynchronously
				this._oDialog = this._oDialogSettings[sFragmentPath];
				if (!this._oDialog) {
					Fragment.load({
						name: sFragmentPath,
						controller: this
					}).then(function (oFragment) {
						this._oDialog = oFragment;
						this.getView().addDependent(this._oDialog);
						syncStyleClass("sapUiSizeCompact", this.getView(), this._oDialog);
						this._oDialogSettings[sFragmentPath] = this._oDialog;
						if (bIsInitialLoader === false) {
							this._oDialog.open();
						}
						if (this._oAppViewModel) {
							this._oAppViewModel.refresh(true);
						}
						fnResolve(this._oDialog);
					}.bind(this));
				} else {
					this._oDialog.open();
					if (this._oAppViewModel) {
						this._oAppViewModel.refresh(true);
					}
					fnResolve(this._oDialog);
				}
			}.bind(this));

		},

		/** 
		 * <b> Auto selecion of table list item </b>
		 * <ul>
		 * <li> Gets the table list item context binding</li>
		 * <li> Checks and validates the given value with table list item </li>
		 * <li> Fires the RowSelectionChange event by rowIndex</li>
		 * <li> Sets selection list item settings to make visible to user </li>
		 * </ul>
		 * @param {string} [sValue] - Value name
		 * @param {sap.ui.table.Table} [oTable] - Table control
		 * @param {string} [sPropertyName] - Property name
		 * @param {string} [oModel] - Model name which is binded to table
		 * @returns boolean false/true
		 */
		_autoListItemSelection: function (sValue, oTable, sPropertyName, oModel) {
			var bIsFoundItem = false;
			var oTableContexts = oTable.getBindingInfo("rows").binding.getContexts();

			for (let d = 0; d < oTableContexts.length; d++) {
				let sTotePath = oTableContexts[d].getPath();
				let oToteInfo = oModel.getProperty(sTotePath);
				if (oToteInfo[sPropertyName] && oToteInfo[sPropertyName].trim() === sValue) {
					let iSelectedIndex = parseInt(sTotePath.split("/")[2], 10);
					oTable.fireRowSelectionChange({
						rowIndex: iSelectedIndex
					});
					oTable.setSelectedIndex(iSelectedIndex);
					oTable.setFirstVisibleRow(iSelectedIndex);
					bIsFoundItem = true;
					break;
				}
				if (bIsFoundItem) {
					break;
				}
			}
			return bIsFoundItem;
		},

		/** 
		 * <b> Callback method of all ODATA calls</b>
		 * 
		 * <ul> <li> Triggers _showResponseErrMsg method to show error message from ODATA response </li> </ul>
		 *  
		 * @param {object} oError error details from ODATA response
		 */
		_fnErrorCallback: function (oError, fnCallback) {
			this._showResponseErrMsg(oError, fnCallback);
		},

		/**
		 * <b> Closes the fragment dialog which is opended by openFragment</b>
		 */
		_closeDialog: function () {
			if (this._oDialog) {
				this._oDialog.close();
			}
		},

		/**
		 * Prepares create key for entity set
		 * Calls ODATA read operation to get single record
		 * CAlls callback methods on sucess
		 */
		_getSingleRecord: function (sEntitySet, oPrimaryKeyValues, oParams) {
			return new Promise((fnResolve) => {

				this._oComponent._oServiceHelper._createKey(this._oDefaultODATAModel, sEntitySet, oPrimaryKeyValues).then((sKey) => {
					this._oComponent._oServiceHelper._callReadOperation(this._oDefaultODATAModel, sKey, [],
						(oData) => fnResolve(oData),
						this._fnErrorCallback.bind(this),
						oParams
					);
				});

			});
		},
		/**
		 * Prepares create key for ToteComps entityset
		 * Calls ODATA read operation to get specific tote compartments
		 * CAlls callback methods on sucess
		 */
		_getSingleToteComps: function (sEntitySet, aFilters, oParams) {
			return new Promise((fnResolve) => {

				this._oComponent._oServiceHelper._callReadOperation(this._oDefaultODATAModel, sEntitySet, aFilters,
					(oData) => fnResolve(oData.results),
					this._fnErrorCallback.bind(this),
					oParams
				);

			});
		},

		/**
		 * Converts value into user format
		 * Returns user format value
		 */
		_getUserSpecificQuantity: function (sPickQty, sGroupingSeparator, sDecimalSeparator) {

			if (sPickQty) {

				var oFormatOptions = {
					groupingSeparator: sGroupingSeparator,
					decimalSeparator: sDecimalSeparator
				};

				oFormatOptions.minFractionDigits = 1;

				var oFloatFormat = sap.ui.core.format.NumberFormat.getCurrencyInstance(oFormatOptions);
				return oFloatFormat.format(sPickQty);
			} else {
				return null;
			}
		}

	});
});