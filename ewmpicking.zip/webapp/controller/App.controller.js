sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("com.win.ewmpicking.controller.App", {
		onInit: function () {
			this._oAppView = this.getOwnerComponent().getModel("AppView");
			this._oAppView.setProperty("/layout", "OneColumn");
		}
	});
});