sap.ui.define([
	"com/win/ewmpicking/controller/BaseController",
	// "com/westernacher/utilscommon//controls/Main"
], function (BaseController, WINUtils) {
	"use strict";

	return BaseController.extend("com.win.ewmpicking.controller.Detail", {
		// WINUtils: WINUtils,

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.win.ewmpicking.view.Detail
		 */
		onInit: function () {
			this._oAppView = this.getOwnerComponent().getModel("AppView");
			this.getRouter().getRoute("detail").attachPatternMatched(this._onPatternMatched, this);
            this._sNoImage = jQuery.sap.getModulePath("com.win.ewmpicking", "/model/image.png"); 
		},
		_onPatternMatched: function (oEvent) {
			var oArguments = oEvent.getParameter("arguments");
			var oDetail = this._oAppView.getProperty("/list")[oArguments.index];
			this._oAppView.setProperty("/detail", oDetail);
			this._oAppView.setProperty("/layout", oArguments.layout);

			this._setupGridSComps();
		},

		_setupGridSComps: function (oEvent) {
			var oGridControl = this.getView().byId("gridList");

			var aNoOfComps = oEvent && oEvent.getSource().getValue();
			aNoOfComps = "3,4";
			aNoOfComps = aNoOfComps ? aNoOfComps.split(",") : "";

			var aCompData = [];
			var iCnt = 0,
				iLength = aNoOfComps.reduce((p, n, ci, arr) => p * n);
			while (iCnt < iLength) {
				aCompData.push({
					text: "Comp" + (iCnt + 1)
				});
				iCnt++;
			}

			/*this.WINUtils.prototype._oUtils.prototype._buildBoxes({
				data: aCompData,
				gridControl: oGridControl,
				rowSpace: "0.1",
				columnSpace: "0.1",
				xpos: aNoOfComps[0],
				ypos: aNoOfComps[1],
				display: true,
				gridEvent: function () {}.bind(this)
			}, function () {

			});*/
		},

		/**
		 * On display image press event
		 * Displays product image in the popup
		 */
		handleTitlePress: function () {
			this.openFragment("com.win.ewmpicking.view.fragments.DisplayImage").then(() => {
				this._addImageToUI(sap.ui.getCore().byId("idVBoxImage"), this._sNoImage);
			});
		},
		/**
		 * On after dislay image open
		 * Sets product image for rework station compartments
		 */
		onAfterDisplayImageOpen: function () {
			let oGreenCompData = this._oAppViewModel.getProperty("/greenCompData");
			this._addImageToUI(sap.ui.getCore().byId("idVBoxImage"), oGreenCompData.PicUrl ? oGreenCompData.PicUrl : this._sNoImage);
		},

		/**
		 * On display image close button press event
		 * Closes the display image popup
		 */
		onDisplayImageClose: function () {
			this._closeDialog();
		},
		/**
		 * <b> Dynamic product image creation based on selected HU </b>
		 * <ul>
		 * <li> Destroys VBox content to re-add product image </li>
		 * <li> Adds VBox item with product image control </li>
		 * </ul>
		 * @param {sap.m.VBox} [oImageParent] - Any control to append image control Ex: sap.m.Vox 
		 * @param {string} [sImageUrl] - Image url
		 */
		_addImageToUI: function (oImageParent, sImageUrl) {
			oImageParent.destroyItems();
			sap.ui.core.BusyIndicator.show();
			oImageParent.addItem(new sap.m.Image({
				src: sImageUrl,
				height: "17rem",
				width: "26rem",
				load: this._fnImageLoaded.bind(this),
				error: this._fnImageFailed.bind(this)
			}).addStyleClass("customImageBorder"));
		},
		/**
		 * <b> Success callback method of product image load </b>
		 * Hides busy indicator
		 * @param {sap.ui.base.Event} [oEvent] - oSource and mParamater from control event
		 */
		_fnImageLoaded: function () {
			sap.ui.core.BusyIndicator.hide();
		},
		/**
		 * <b> Error callback method of product image load </b>
		 * Hides busy indicator
		 * @param {sap.ui.base.Event} [oEvent] - oSource and mParamater from control event
		 */
		_fnImageFailed: function (oEvent) {
			sap.ui.core.BusyIndicator.hide();
			oEvent.getSource().setSrc(this._sNoImage);
		},

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf com.win.ewmpicking.view.Detail
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf com.win.ewmpicking.view.Detail
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf com.win.ewmpicking.view.Detail
		 */
		//	onExit: function() {
		//
		//	}

	});

});