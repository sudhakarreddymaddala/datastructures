sap.ui.define([
	"westernacher/yl/shunting/util/BaseController",
	"sap/m/MessageBox",
	"westernacher/yl/shunting/util/Formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (BaseController, MessageBox, Formatter, Filter, FilterOperator) {
	"use strict";

	return BaseController.extend("westernacher.yl.shunting.controller.Mafi", {
		formatter: Formatter,
		onInit: function () {
		
		},

		onRouteMatched: function (oEvent) {
			BaseController._AppStart = true;
		},
		onBConfirmationPress: function (oEvent) {
			var oMafiContext = oEvent.getParameter("listItem").getBindingContext();
			if (!oMafiContext.getProperty("CurrentTask")) {
				this.displayMessageBox(this.getI18nText("Message_CurrentTaskDoesntExists"));
			} else {
				var oConfigModel = this.getView().getModel("configModel");
				oConfigModel.setProperty("/Mafi", oMafiContext.getProperty("Name"));

				this.getRouter().navTo("shunting", {
					yardId: oMafiContext.getProperty('YardNo'),
					resourceId: oMafiContext.getProperty('Resource')
				}, false);
			}
		}

	});

});