sap.ui.define([
	"westernacher/yl/shunting/util/BaseController",
	"sap/m/MessageBox",
	"westernacher/yl/shunting/util/Formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/json/JSONModel"
], function (BaseController, MessageBox, Formatter, Filter, FilterOperator, JSONModel) {
	"use strict";

	return BaseController.extend("westernacher.yl.shunting.controller.Shunting", {
		_OriginalStatus: "",
		_OriginalDestination: "",
		_CurrentPath: "",
		formatter: Formatter,
		onInit: function () {
			this.getRouter().attachRoutePatternMatched(this.onRouteMatched, this);
			this._oAppView = this.getOwnerComponent().getModel("AppView");

			var oButtonVisiblityModel = new JSONModel({
				startVisible: false,
				confirmVisible: false,
				rejectVisible: false,
				backVisible: false
			});
			this.getView().setModel(oButtonVisiblityModel, "buttonsVisible");
			var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/ZYL_SHUNTING_SRV/");
			this.getView().setModel(oModel, "functionModel");
		},

		onRouteMatched: function (oEvent) {
			var sResourceId = oEvent.getParameter("arguments").resourceId;
			var sYardId = oEvent.getParameter("arguments").yardId;

			if (sResourceId) {
				this.getView().getModel().metadataLoaded().then(function () {
					var sObjectPath = this.getView().getModel().createKey("HandlingResourceSet", {
						Resource: sResourceId,
						YardNo: sYardId
					});
					this._bindView("/" + sObjectPath);
				}.bind(this));
			}

		},
		_bindView: function (sObjectPath) {

			this.getView().bindElement({
				path: sObjectPath,
				parameters: {
					expand: "CurrentTask"
				},
				events: {
					// 	change: this._onBindingChange.bind(this),
					// 	dataRequested: function() {
					// 		oViewModel.setProperty("/busy", true);
					// 	},
					dataReceived: function (oEvent) {
						if (!oEvent.getParameter('data')) {
							return;
						}
						//	var oModel = this.getView().getModel("buttonsVisible");
						var oCurrentTask = oEvent.getParameter('data').CurrentTask;
						this._manageButtonsAvailability(oCurrentTask);
					}.bind(this)
				}
			});
			// this._CHECK_DATA(sObjectPath + "/CurrentTask");
			var oCurrentTask = this.getView().getModel().getProperty(sObjectPath + "/CurrentTask");
			if (oCurrentTask) {
				this._manageButtonsAvailability(oCurrentTask);
			}
		},

		_manageButtonsAvailability: function (oCurrentTask) {
			var oModel = this.getView().getModel("buttonsVisible");
			if (oCurrentTask && oCurrentTask.LifecycleStatus === "02") {
				oModel.setProperty("/startVisible", true);
				oModel.setProperty("/confirmVisible", false);
				oModel.setProperty("/rejectVisible", false);
				oModel.setProperty("/backVisible", true);
				oModel.setProperty("/breakVisible", false);
			} else if (oCurrentTask && oCurrentTask.LifecycleStatus === "03") {
				oModel.setProperty("/startVisible", false);
				oModel.setProperty("/confirmVisible", true);
				oModel.setProperty("/rejectVisible", true);
				oModel.setProperty("/backVisible", false);
				oModel.setProperty("/breakVisible", true);
			} else {
				oModel.setProperty("/startVisible", false);
				oModel.setProperty("/confirmVisible", false);
				oModel.setProperty("/rejectVisible", false);
				oModel.setProperty("/backVisible", true);
				oModel.setProperty("/breakVisible", false);
			}

			if (!oCurrentTask.ShowStartButton) {
				oModel.setProperty("/startVisible", false);
			}
			if (!oCurrentTask.ShowConfirmButton) {
				oModel.setProperty("/confirmVisible", false);
			}
		},
		onBStartShunting: function () {
			var oObject = this.getView().byId("idTYOShunt");
			var oSelectedItem = oObject.getSelectedItem();

			if (!oSelectedItem) {
				sap.m.MessageToast.show(this.getI18nText("Message_SelectTask"));

				return;
			}

			var aContext = oSelectedItem.getBindingContext();
			var oItemObject = aContext.getObject();

			if (oItemObject.Status === "done") {
				sap.m.MessageToast.show(this.getI18nText("Message_TaskDone"));

				return;
			}

			var sPath = aContext.getPath();
			var objectId = sPath.replace("/TUSet/", "");

			this.getRouter().navTo("secureloading", {
				objectId: objectId
			}, false);
		},
		onNavBack: function () {
			this.getRouter().navTo("mafi", {}, true);
		},
		onBCancelPress: function () {
			var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;

			var myThis = this;
		},
		onBStopBreakPress: function () {
			var oModel = this.getView().getModel();
			oModel.setProperty(this._CurrentPath + "/Status", "stop");

			this.getRouter().navTo("tasklist", {});
		},

		onBDestinationChangePress: function () {
			this.openConfirmationDialog(this, "", this.getI18nText("ConfirmationDialog_Title"), "");
		},

		onConfirmationDialogComplette: function (sDialogId, sValue) {
			//this.getView().byId("idTToLocation").setText(sValue);
			var oView = this.getView();
			var oBinding = oView.getBindingContext();
			var oTask = oBinding.getObject().CurrentTask;
			if (!oTask) {
				return;
			}
			var sPath = "/" + oTask.__ref;
			oView.getModel().update(sPath, {
				"StorBindst": sValue
			}, {
				success: function (oResponse) {
					sap.m.MessageToast.show(this.getI18nText("Message_UpdateSuccess"));
				}
			});
		},
		onStartTaskButtonPress: function () {
			//StartYardTask
			var oBinding = this.getView().getBindingContext();
			var sYardNo = oBinding.getProperty("CurrentTask/YardNo");
			var sYardtaskNo = oBinding.getProperty("CurrentTask/YardTaskNo");
			var functionParams = {
				YardNo: sYardNo,
				YardTaskNo: sYardtaskNo
			};
			var fnSuccess = function (oData, oResponse) {
				//oModel.refresh();
				sap.m.MessageToast.show(this.getI18nText("Message_SuccessStart"));
				this.getView().getModel().refresh(true);
			}.bind(this);
			var fnError = function (oError) {
				var oErrorResponse = JSON.parse(oError.responseText);
				var sErrorText = oErrorResponse.error.message.value;
				if (sErrorText) {
					sap.m.MessageToast.show(sErrorText);
				} else {
					sap.m.MessageToast.show(this.getI18nText("Message_UnexpectedErrorStart"));
				}

			}.bind(this);
			this.callFunctionImport('StartYardTask', functionParams, fnSuccess, fnError);
		},
		onConfirmationButtonPress: function () {
			//StartYardTask
			var oBinding = this.getView().getBindingContext();
			var sYardNo = oBinding.getProperty("CurrentTask/YardNo");
			var sYardtaskNo = oBinding.getProperty("CurrentTask/YardTaskNo");
			var functionParams = {
				YardNo: sYardNo,
				YardTaskNo: sYardtaskNo
			};
			var fnSuccess = function (oData, oResponse) {
				//oModel.refresh();
				sap.m.MessageToast.show(this.getI18nText("Message_SuccessConfirm"));
				this.getView().getModel().refresh(true);
			}.bind(this);
			var fnError = function (oError) {
				var oErrorResponse = JSON.parse(oError.responseText);
				var sErrorText = oErrorResponse.error.message.value;
				if (sErrorText) {
					sap.m.MessageToast.show(sErrorText);
				} else {
					sap.m.MessageToast.show(this.getI18nText("Message_UnexpectedErrorConfirm"));
				}

			}.bind(this);
			this.callFunctionImport('ConfirmYardTask', functionParams, fnSuccess, fnError);
		},
		onRejectButtonPress: function () {
			//StartYardTask
			var oBinding = this.getView().getBindingContext();
			var sYardNo = oBinding.getProperty("CurrentTask/YardNo");
			var sYardtaskNo = oBinding.getProperty("CurrentTask/YardTaskNo");
			var functionParams = {
				YardNo: sYardNo,
				YardTaskNo: sYardtaskNo
			};
			var fnSuccess = function (oData, oResponse) {
				sap.m.MessageToast.show(this.getI18nText("Message_SuccessReject"));
				this.getView().getModel().refresh(true);
			}.bind(this);
			var fnError = function (oError) {
				var oErrorResponse = JSON.parse(oError.responseText);
				var sErrorText = oErrorResponse.error.message.value;
				if (sErrorText) {
					sap.m.MessageToast.show(sErrorText);
				} else {
					sap.m.MessageToast.show(this.getI18nText("Message_UnexpectedErrorReject"));
				}

			}.bind(this);
			this.callFunctionImport('RejectYardTask', functionParams, fnSuccess, fnError);
		},
		onBreakButtonPress: function (oEvent) {
			if (!this._breakDialog) {
				this._breakDialog = sap.ui.xmlfragment("westernacher.yl.shunting.fragment.BreakDialog", this);
				this.getView().addDependent(this._breakDialog);
			}
			this._breakDialog.open();
		}
	});

});