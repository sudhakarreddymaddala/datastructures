sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"westernacher/yl/shunting/model/models",
	"westernacher/yl/shunting/controller/ErrorHandler"
], function (UIComponent, Device, models, ErrorHandler) {
	"use strict";

	return UIComponent.extend("westernacher.yl.shunting.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function () {
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);

			// set the device model
			this.setModel(models.createDeviceModel(), "device");

			this.getRouter().initialize();
			this._oErrorHandler = new ErrorHandler(this);
			var oRootPath = jQuery.sap.getModulePath("westernacher.yl.shunting");
			var oImageModel = new sap.ui.model.json.JSONModel({
				path: oRootPath
			});
			this.setModel(oImageModel, "imageModel");

			var oConfigModel = new sap.ui.model.json.JSONModel({
				Mafi: ""
			});
			this.setModel(oConfigModel, "configModel");
		//	var oModel = this.getModel();
			this._CHECK_DATA();
		},
		destroy: function () {
			this._oErrorHandler.destroy();
			// call the base component's destroy function
			UIComponent.prototype.destroy.apply(this, arguments);
		},
		_CHECK_DATA: function () {

			var oModel = this.getModel();
			var that = this;

			// oModel.read(sPath, {
			// 	success: function (oData) {
			jQuery.sap.delayedCall(60 * 100, that, function () {
				oModel.refresh(true);
				that._CHECK_DATA();
			});
			// 	},
			// 	error: function (oError) {
			// 		jQuery.sap.delayedCall(60 * 100, that, function () {
			// 			that._CHECK_DATA(sPath);
			// 		});
			// 	}
			// });
		}
	});
});