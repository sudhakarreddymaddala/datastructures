jQuery.sap.declare("westernacher.yl.shunting.util.DialogController");

westernacher.yl.shunting.util.DialogController = {
	openConfirmationDialog: function(oThis, sValue, sTitle, sDialogId) {
		this._that = oThis;
		this.sValue = sValue;
		this._sDialogId = sDialogId;
		this.sPosition = this._that.getI18nText("ConfirmationDialog_Destination_Park");

		var sFragmentId = "idDialog" + oThis.getView().getId();

		if (!oThis._oDialog) {
			oThis._oDialog = sap.ui.xmlfragment(sFragmentId, "westernacher.yl.shunting.fragment.ConfirmationDialog", this);
			oThis._oDialog.setModel(oThis.getView().getModel());
		}

		oThis.getView().addDependent(oThis._oDialog);

		sap.ui.getCore().byId(sFragmentId + "--idDialogInput").setValue(this.sPosition + " " + sValue);
		sap.ui.getCore().byId(sFragmentId + "--idDialogTitle").setTitle(sTitle);
		sap.ui.getCore().byId(sFragmentId + "--idSBDestination").setSelectedKey("Park");

		oThis._oDialog.open();
	},

	onNumKeyboardPressed: function(oEvent) {
		var oParameters = oEvent.getParameters();
		var oPressedKey = oParameters.id.substring(oParameters.id.length - 1, oParameters.id.length);

		this.numKeyboardAction(oPressedKey);
	},

	numKeyboardAction: function(numValue) {
		switch (numValue) {
			case "B":
				this.sValue = this.sValue.substring(0, this.sValue.length - 1);
				break;
			case "C":
				this.sValue = "";
				break;
			default:
				this.sValue = this.sValue + numValue;
				break;
		}

		var sFragmentId = "idDialog" + this._that.getView().getId();
		sap.ui.getCore().byId(sFragmentId + "--idDialogInput").setValue(this.sPosition + " " + this.sValue);
	},

	onPressLEOK: function() {
		var sFragmentId = "idDialog" + this._that.getView().getId();
		var sValue = sap.ui.getCore().byId(sFragmentId + "--idDialogInput").getValue();

		this._that.onConfirmationDialogComplette(this._sDialogId, sValue);

		this._that._oDialog.close();
	},

	onPressLECancel: function() {
		this._that._oDialog.close();
	},

	onBParkPress: function() {
		this.sPosition = this._that.getI18nText("ConfirmationDialog_Destination_Park");

		var sFragmentId = "idDialog" + this._that.getView().getId();
		sap.ui.getCore().byId(sFragmentId + "--idDialogInput").setValue(this.sPosition + " " + this.sValue);
	},

	onBDoorPress: function() {
		this.sPosition = this._that.getI18nText("ConfirmationDialog_Destination_Door");

		var sFragmentId = "idDialog" + this._that.getView().getId();
		sap.ui.getCore().byId(sFragmentId + "--idDialogInput").setValue(this.sPosition + " " + this.sValue);
	}
};