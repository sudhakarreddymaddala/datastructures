sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"westernacher/yl/shunting/util/DialogController",
	"westernacher/yl/shunting/dialogController/MafiDialog",
	"sap/m/MessageBox",
	"sap/m/MessageToast"
], function (Controller, DialogController, MafiDialog, MessageBox, MessageToast) {
	"use strict";

	return Controller.extend("westernacher.yl.shunting.util.BaseController", {
		_AppStart: false,

		getRouter: function () {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},

		onNavigationBack: function () {
			var oHistory = sap.ui.core.routing.History.getInstance(),
				sPreviousHash = oHistory.getPreviousHash();

			if (sPreviousHash !== undefined) {
				// The history contains a previous entry
				history.go(-1);
			} else {
				this.getOwnerComponent().getRouter().navTo("menu", {}, false);
			}
		},

		openMafiDialog: function (oThis, oInput, sParent) {
			MafiDialog.openMafiDialog(oThis, oInput, sParent);
		},

		selectedMafi: function (oThis, sParent, oInput, sValue) {
			switch (sParent) {
			case "Mafi":
				oInput.setValue(sValue);
				oThis.onBConfirmetionPress();

				break;
			}
		},
		openConfirmationDialog: function (oThis, sValue, sTitle, sDialogId) {
			DialogController.openConfirmationDialog(oThis, sValue, sTitle, sDialogId);
		},

		getI18nText: function (cValue) {
			var oBundle = this.getView().getModel("i18n").getResourceBundle();
			var sText = oBundle.getText(cValue);

			return sText;
		},
		callFunctionImport: function (sName, oParameters, fSuccess, fError) {
			var oModel = this.getView().getModel("functionModel");
			oModel.callFunction("/" + sName, {
				method: "POST",
				urlParameters: oParameters,
				success: fSuccess,
				error: fError
			});
		},
		displayMessageBox: function (sMessageText) {
			if (!sMessageText) {
				return;
			}
			MessageBox.alert(sMessageText, {
				title: this.getI18nText("Info"),
				icon: MessageBox.Icon.INFORMATION
			});
		}

	});

});