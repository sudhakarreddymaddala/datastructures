sap.ui.define([
	"./BaseController",
	"sap/ui/model/json/JSONModel",
	"../model/formatter",
	"sap/m/library",
	"sap/m/MessageToast",
	"sap/m/MessageBox",
	"sap/ui/core/Fragment",
	"sap/ui/model/Filter",
	"sap/ui/model/Sorter",
	"sap/ui/model/FilterOperator"
], function (BaseController, JSONModel, formatter, mobileLibrary, MessageToast, MessageBox, Fragment, Filter, Sorter, FilterOperator) {
	"use strict";

	return BaseController.extend("com.service.entry.serviceentry.controller.Detail", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		onInit: function () {
			this.oDataModel = this.getOwnerComponent().getModel();
			this.getRouter().getRoute("object").attachPatternMatched(this._onObjectMatched, this);
			this._oAppViewModel = this.getOwnerComponent().getModel("AppViewModel");
			this._sItemNo = 0;
			this._oAppViewModel.setProperty("/mode", "DISPLAY");
			//	this._oAppViewModel.setSizeLimit(50000);

		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		/* =========================================================== */
		/* begin: internal methods                                     */
		/* =========================================================== */

		/**
		 * Binds the view to the object path and expands the aggregated line items.
		 * @function
		 * @param {sap.ui.base.Event} oEvent pattern match event in route 'object'
		 * @private
		 */
		_onObjectMatched: function (oEvent) {
			var sObjectId = oEvent.getParameter("arguments").objectId,
				sPONum = oEvent.getParameter("arguments").PONum,
				sPOItem = oEvent.getParameter("arguments").POItem,
				bNewEntry = this.getModel("appView").getProperty("/newEntry");
			this._sObjectId = sObjectId;
			if (sObjectId === "EMPTYSCREEN") {
				return;
			}
			this.getModel("appView").setProperty("/layout", "TwoColumnsMidExpanded");
			this.getModel("appView").setProperty("/newEntry", false);

			if (!bNewEntry) {
				this._bIsNewSE = false;
				this._oAppViewModel.setProperty("/bIsNewSE", this._bIsNewSE);
				sap.ui.core.BusyIndicator.show();
				this.getModel().metadataLoaded().then(function () {
					this._sObjectPath = this.getModel().createKey("SEheaderSet", {
						serviceentry: sObjectId
					});
					this._setServiceLineItem("", sPONum, sPOItem);
				}.bind(this));
			} else {
				this._bIsNewSE = true;
				this._oAppViewModel.setProperty("/bIsNewSE", this._bIsNewSE);

				this.toggleFullScreen();

				this._oAppViewModel.setProperty("/bIsCopy", false);
				this._oAppViewModel.setProperty("/mode", "CREATE");
				this.getModel("appView").setProperty("/bIsCreate", true);
				this._oAppViewModel.setProperty("/create", []);
				if (!this._oAppViewModel.getProperty("/bIsSelectedPO")) {
					this._oAppViewModel.setProperty("/detailpage", {});
					this._oAppViewModel.setProperty("/itemDetails", []);
					this._oAppViewModel.setProperty("/create", []);
				} else {
					this._oAppViewModel.setProperty("/bIsNewSE", false);
				}
			}
			this._oAppViewModel.refresh(true);
		},

		_onBindingChange: function () {
			var oView = this.getView(),
				oElementBinding = oView.getElementBinding();

			// No data for the binding
			if (!oElementBinding.getBoundContext()) {
				this.getRouter().getTargets().display("detailObjectNotFound");
				// if object could not be found, the selection in the master list
				// does not make sense anymore.
				this.getOwnerComponent().oListSelector.clearMasterListSelection();
				return;
			}

			var sPath = oElementBinding.getPath(),
				oResourceBundle = this.getResourceBundle(),
				oObject = oView.getModel().getObject(sPath),
				sObjectId = oObject.OrderID,
				sObjectName = oObject.OrderDate,
				oViewModel = this.getModel("detailView");

			this.getOwnerComponent().oListSelector.selectAListItem(sPath);

			oViewModel.setProperty("/shareSendEmailSubject",
				oResourceBundle.getText("shareSendEmailObjectSubject", [sObjectId]));
			oViewModel.setProperty("/shareSendEmailMessage",
				oResourceBundle.getText("shareSendEmailObjectMessage", [sObjectName, sObjectId, location.href]));
		},

		/**
		 * Set the full screen mode to false and navigate to master page
		 */
		onCloseDetailPress: function () {
			this.getModel("appView").setProperty("/actionButtonsInfo/midColumn/fullScreen", false);
			// No item should be selected on master after detail page is closed
			this.getOwnerComponent().oListSelector.clearMasterListSelection();
			this.getRouter().navTo("master");
		},

		onEdit: function () {
			//Clone short test from detail
			var aAllShortTxts = [];
			var aItemDetail = this._oAppViewModel.getProperty("/itemDetails");
			aItemDetail.forEach((lineitem) => {
				aAllShortTxts.push(lineitem.servicelinetext);
			});

			this._oAppViewModel.setProperty("/allShortTexts", aAllShortTxts);
			this._oAppViewModel.setProperty("/itemDetails", []);

			this._setServiceLineItem();
			this._setPoLineItem();

			var bIsOneColumn = this.getModel("appView").getProperty("/layout");
			if (bIsOneColumn !== "MidColumnFullScreen") {
				this.toggleFullScreen();
			}

			this._oAppViewModel.setProperty("/bIsCopy", false);
			this._oAppViewModel.setProperty("/mode", "EDIT");
			this._oAppViewModel.refresh(true);
		},

		onCancel: function () {
			// navigate to master if it is new service entry and detail entried are initial
			var bIsCreate = this.getModel("appView").getProperty("/bIsCreate"),
				oDetailpage = this._oAppViewModel.getProperty("/detailpage");
			var currentLayout = this.getModel("appView").getProperty("/layout");
			//&& !oDetailpage.hasOwnProperty("PONum") && !oDetailpage.hasOwnProperty("POItem")
			if (bIsCreate) {
				if (currentLayout !== "TwoColumnsMidExpanded") {
					this.toggleFullScreen();
				}
				this.getOwnerComponent().oListSelector.clearMasterListSelection();
				this.getRouter().navTo("master");
				return;
			} else {
				this._oAppViewModel.setProperty("/bIsCopy", true);
				this._oAppViewModel.setProperty("/mode", "DISPLAY");
				this.getModel("appView").setProperty("/bIsCreate", false);

				if (bIsCreate) {
					let previousLayout = this.getModel("appView").getProperty("/previousLayout"),
						layout = this.getModel("appView").getProperty("/layout");
					let showTwoColumns = this._oAppViewModel.getProperty("/showTwoColumns");

					if (previousLayout !== layout) {
						if (previousLayout && previousLayout === "TwoColumnsMidExpanded" && showTwoColumns) {
							this.toggleFullScreen();
						} else {
							this.toggleFullScreen();
							this.getOwnerComponent().oListSelector.clearMasterListSelection();
							this.getRouter().navTo("master");
						}
					}
				} else {
					if (currentLayout !== "TwoColumnsMidExpanded") {
						this.toggleFullScreen();
					}

					var oHeader = this._oAppViewModel.getProperty("/clonnedDataHeader");
					var oItem = this._oAppViewModel.getProperty("/clonnedDataItem");

					let oClonnedData = Object.assign({}, oHeader);
					this._oAppViewModel.setProperty("/detailpage", oClonnedData);
					this._oAppViewModel.setProperty("/itemDetails", oItem);

					this._oAppViewModel.refresh(true);
				}

			}

		},
		onSubmit: function (oEvent) {
			this.submitCreateForm(oEvent);
		},

		submitCreateForm: function (oActionEvent) {
			var sOperaration = this._bIsDelete && !oActionEvent ? "D" : oActionEvent.getSource().getCustomData()[0].getValue();

			// var oODATAModel = new sap.ui.model.odata.ODataModel("/serviceenty/odata/SAP/ZSES_CREATE_SERVICEENTRY_SHEET_SRV/");
			// oODATAModel.setUseBatch(true);
			// this.oDataModel.setUseBatch(true);
			// Prepare item data
			let oHeaderData, sDraft, oStartDate, oEndDate, oDocumentDate, oPostingDate, sShortText, sPOItem;
			if (sOperaration === "CO" || sOperaration === "U" || sOperaration === "R" || sOperaration === "D") {
				oHeaderData = this._oAppViewModel.getProperty("/detailpage");
				sDraft = this.getView().byId("idEditDraft").getSelected();

				oStartDate = this.getView().byId("idStartEdit").getDateValue();
				oEndDate = this.getView().byId("idEndEdit").getDateValue();
				oDocumentDate = this.getView().byId("idDocEdit").getDateValue();
				oPostingDate = this.getView().byId("idPostEdit").getDateValue();
				sShortText = this.getView().byId("idShortTextEdit").getValue();
				sPOItem = this._oAppViewModel.getProperty("/detailpage/POItem");

			} else if (sOperaration === "C") {
				oHeaderData = this._oAppViewModel.getProperty("/createDetail");
				sDraft = this.getView().byId("idCreateDraft").getSelected();

				oStartDate = this.getView().byId("idStartCreate").getDateValue();
				oEndDate = this.getView().byId("idEndCreate").getDateValue();
				oDocumentDate = this.getView().byId("idDocCreate").getDateValue();
				oPostingDate = this.getView().byId("idPostCreate").getDateValue();
				sShortText = this.getView().byId("idShortTextCreate").getValue();
				sPOItem = this._oAppViewModel.getProperty("/detailpage/POItem");
			}

			var oSEHeaderData = {
				serviceentry: oHeaderData.serviceentry ? oHeaderData.serviceentry : "",
				PONum: this._oAppViewModel.getProperty("/detailpage/PONum"),
				periodstart: oStartDate ? oStartDate : null,
				periodend: oEndDate ? oEndDate : null,
				postingdate: oPostingDate ? oPostingDate : null,
				documentdate: oDocumentDate ? oDocumentDate : null,
				shorttext: sShortText,
				POItem: this._oAppViewModel.getProperty("/detailpage/POItem"),
				// Final: this.getView().byId("idFinal").getSelected() ? "X" : "",
				operation: sOperaration,
				draft: sDraft ? "X" : "",
				status: this._oAppViewModel.getProperty("/detailpage/status")
			};

			var bIsCreate = this.getModel("appView").getProperty("/bIsCreate");
			if (bIsCreate) {
				// delete service entry for create
				delete oSEHeaderData.serviceentry;
			}

			var oSEItemData;
			if (sOperaration === "CO" || sOperaration === "U" || sOperaration === "R" || sOperaration === "D") {
				oSEItemData = this._oAppViewModel.getProperty("/itemDetails");
			} else if (sOperaration === "C") {
				oSEItemData = this._oAppViewModel.getProperty("/create");
			}

			// Deleting unneccessary properties from item data
			oSEItemData.forEach((itemData) => {
				delete itemData.__metadata;
				delete itemData.SEheader;
				delete itemData.price;
			});

			oSEHeaderData.SEItemDetails = oSEItemData;
			sap.ui.core.BusyIndicator.show();

			// make operation as C if it is CO
			oSEHeaderData.operation = oSEHeaderData.operation === "CO" ? "C" : oSEHeaderData.operation;
			this.oDataModel.setUseBatch(true);
			// oODATAModel.create("/SEheaderSet", oSEHeaderData, {
			this.oDataModel.create("/SEheaderSet", oSEHeaderData, {
				// method: "POST",
				success: function (oData) {
					this._oAppViewModel.setProperty("/bIsActionTriggered", true);
					sap.ui.core.BusyIndicator.hide();
					this.toggleFullScreen();
					this._bIsDelete = false;
					let msg = "Created successfully";
					if (sOperaration === "CO") {
						msg = "Copied successfully";
					} else if (sOperaration === "U") {
						msg = "Updated successfully";
					} else if (sOperaration === "R") {
						msg = "Revoked successfully";
					} else if (sOperaration === "D") {
						msg = "Deleted successfully";

					}
					MessageBox.alert(msg);
					this._oAppViewModel.setProperty("/mode", "DISPLAY");
					this._oAppViewModel.setProperty("/bIsSelectedPO", false);
					this.getOwnerComponent().oListSelector.clearMasterListSelection();
					this.getRouter().navTo("master");

				}.bind(this),
				error: function (error) {
					sap.ui.core.BusyIndicator.hide();
					//	this.toggleFullScreen();
					//	this.getOwnerComponent().oListSelector.clearMasterListSelection();
					//	this.getRouter().navTo("master");
					// this._showResponseErrMsg(error);
				}.bind(this)

			});

		},

		submitEditForm: function () {
			let aItemData = this._oAppViewModel.getProperty("/itemDetails");
			aItemData = aItemData ? aItemData : [];
			let oHeaderData = this._oAppViewModel.getProperty("/detailpage");
			// var oODATAModel = new sap.ui.model.odata.ODataModel("/serviceenty/odata/SAP/ZSES_CREATE_SERVICEENTRY_SHEET_SRV/");

			// Prepare item data
			var SEItemDetailsData = [];
			aItemData.forEach((data) => {
				SEItemDetailsData.push({
					servicelinetext: data.servicelinetext,
					quntity: data.quntity
				});
			});
			var oSEHeaderData = {
				serviceentry: oHeaderData.serviceentry,
				PONum: oHeaderData.PONum,
				periodstart: oHeaderData.periodstart,
				periodend: oHeaderData.periodend,
				postingdate: oHeaderData.postingdate,
				documentdate: oHeaderData.documentdate,
				servicelinetext: oHeaderData.servicelinetext
			};

			oSEHeaderData.SEItemDetails = SEItemDetailsData;

			// oODATAModel.update("/SEheaderSet('" + this._sObjectId + "')", oSEHeaderData, {
			this.oDataModel.update("/SEheaderSet('" + this._sObjectId + "')", oSEHeaderData, {
				success: function (oData) {
					MessageToast.show("Updated successfully");
					this._oAppViewModel.setProperty("/mode", "DISPLAY");
				}.bind(this),
				error: function (error) {
					MessageBox.error(JSON.stringify(error));
				}
			});
		},

		onEditAdd: function () {
			this._oAppViewModel.setProperty("/bIsNewLineItem", true);
			var sServiceEntry = this._oAppViewModel.getProperty("/detailpage/serviceentry");
			this._sObjectId = sServiceEntry ? sServiceEntry : this._sObjectId;
			this._setServiceLineItem(true).then(() => {
				this._oAppViewModel.setProperty("/bIsNewLineItem", false);
			});
		},
		onEditDelete: function () {
			var oTable = this.getView().byId("lineItemsList");
			var aContextData = this._oAppViewModel.getProperty("/itemDetails");
			if (oTable.getSelectedItems().length > 0) {
				var aSeletedItems = Array.from(aContextData);
				var aSelectedOrders = [];
				// store selected line items 

				oTable.getSelectedItems().forEach((e) => aSelectedOrders.push(parseInt(e.getBindingContextPath().split("/")[2], 10)));

				aSelectedOrders.forEach((sOrder) => {
					var iIndex = aSeletedItems.findIndex((selectedItem) => selectedItem.order === sOrder);
					aSeletedItems.splice(iIndex, 1);
				});
				this._oAppViewModel.setProperty("/itemDetails", aSeletedItems);
				// de-select all rows
				oTable.getSelectedItems().forEach((oItem) => {
					this.getView().byId("lineItemsList").removeSelections(true);
				});
			} else {
				MessageToast.show("please select atleast one line item");
			}
			this._oAppViewModel.refresh(true);
		},
		onAddItem: function () {
			this._oAppViewModel.setProperty("/bIsNewLineItem", true);

			this._setServiceLineItem("", "", "", this._bIsNewSE).then(() => {
				this._oAppViewModel.setProperty("/bIsNewLineItem", false);
			});

			var oItems = this._oAppViewModel.getProperty("/create");
			this._oAppViewModel.setProperty("/bIsItemSelected", true);
			var sServiceEntry = this._oAppViewModel.getProperty("/detailpage/serviceentry");
			this._sObjectId = sServiceEntry ? sServiceEntry : this._sObjectId;
			this._oAppViewModel.setProperty("/create", oItems);
		},
		onDeleteItem: function () {
			var oTable = this.getView().byId("idCreateTable");
			var aContextData = this._oAppViewModel.getProperty("/create");
			if (oTable.getSelectedItems().length > 0) {
				var aSeletedItems = Array.from(aContextData);
				var aSelectedOrders = [];
				// store selected line items 

				oTable.getSelectedItems().forEach((e) => aSelectedOrders.push(parseInt(e.getBindingContextPath().split("/")[2], 10)));

				aSelectedOrders.forEach((sOrder) => {
					var iIndex = aSeletedItems.findIndex((selectedItem) => selectedItem.order === sOrder);
					aSeletedItems.splice(iIndex, 1);
				});
				this._oAppViewModel.setProperty("/create", aSeletedItems);
				// de-select all rows
				oTable.getSelectedItems().forEach((oItem) => {
					this.getView().byId("idCreateTable").removeSelections(true);
				});
			} else {
				MessageToast.show("please select atleast one line item");
			}
		},
		onShortTextChange: function (oEvent) {
			// AppViewModel>/detailpage/shorttext
			var oSource = oEvent.getSource();
			var oAllItemData = this._oAppViewModel.getProperty("/allItemData");

			var oItemData = oAllItemData.filter((itemData) => itemData.shorttext === oEvent.getParameter("selectedItem").getText())[0];
			var oContext = oSource.getParent().getBindingContext("AppViewModel");

			var iCalculatePercent = (parseInt(oItemData.Consum, 10) * 100) / (parseInt(oItemData.Actual, 10) * 100);
			iCalculatePercent = iCalculatePercent * 100; // qty in percentage
			iCalculatePercent = parseInt(iCalculatePercent, 10) + "";

			var bIsCreate = this.getModel("appView").getProperty("/bIsCreate");
			var data = oContext.getModel().getProperty(oContext.getPath());

			this._oAppViewModel.setProperty("/currentNetValue", bIsCreate ? oAllItemData[0].price : data.price);

			var preIndex = oContext.getPath().split("/")[2];
			preIndex = parseInt(preIndex, 10) - 1;
			var sPath = bIsCreate ? "/create/" : "/itemDetails/";

			var preItemData = preIndex > -1 && oContext.getModel().getProperty(sPath + preIndex);
			var preLineNo = preIndex > -1 && preItemData && preItemData.Linenum.replace(/^0+/, "");

			if (bIsCreate) {
				var oCreatData = this.getModel("AppViewModel").getProperty("/create");
				if (oCreatData.length > 1) {
					preLineNo = oCreatData.length * 10;
				} else {
					preLineNo = 10;
				}
				preLineNo = preLineNo + "";
			} else {
				if (preLineNo.length === 1) {
					preLineNo = preLineNo ? (parseInt(preLineNo, 10) + 1) + "" : "1";
				} else if (preLineNo.length > 1) {
					preLineNo = preLineNo ? (parseInt(preLineNo, 10) + 1) * 10 + "" : "10";
				} else {
					preLineNo = "1";
				}
			}
			data.Linenum = preLineNo;
			data.activitynum = oItemData.Srvpos;
			data.RemainingQty = oItemData.Remqty;
			data.fillRate = iCalculatePercent;
			data.displayQty = oItemData.Consum + "/" + oItemData.Actual;
			data.Meins = oItemData.Meins;
			data.wbslement = oItemData.PsPspPnr;
			data.costcenter = oItemData.Kostl;
			data.grossvalue = oItemData.grossvalue;
			data.netvalue = oItemData.Netwr;
			data.Actualqty = oItemData.Actual;
			data.Consumqty = oItemData.Consum;
			
			if (!data.price) {
				data.price = parseFloat(oItemData.Netwr) / parseFloat(oItemData.Remqty);
			}

			oContext.getModel().setProperty(oContext.getPath(), data);

		},

		_arrangeLineNos: function (oData) {

		},

		onRevoke: function (oEvent) {
			this.submitCreateForm(oEvent);
		},
		onDelete: function (oEvent) {
			this._bIsDelete = true;
			MessageBox.confirm("Do you want to delete?", {
				actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
				onClose: function (sAction) {
					if (sAction === "YES") {
						this.submitCreateForm();
					}
				}.bind(this)
			});
		},
		onSelectionChangeOfPO: function (oEvent) {
			this._oAppViewModel.setProperty("/create", []);

			var oContext = oEvent.getParameter("listItem").getBindingContext("AppViewModel");
			this._sObjectId = oContext.getProperty(oEvent.getParameter("listItem").getBindingContextPath()).serviceentry;
			if (this._oAppViewModel.getProperty("/mode") === "CREATE") {
				this._oAppViewModel.setProperty("/detailpage", {});
				this._oAppViewModel.setProperty("/create", {});
				this._oAppViewModel.setProperty("/detailpage/PONum", oEvent.getParameter("listItem").getTitle());
			} else {
				this._oAppViewModel.setProperty("/detailpage", {});
				this._oAppViewModel.setProperty("/detailpage/PONum", oEvent.getParameter("listItem").getTitle());
				this._oAppViewModel.setProperty("/itemDetails", {});
			}
			this._oAppViewModel.refresh(true);
			this._PODialog.close();
			this._setPoLineItem();
		},

		onPODocNo: function () {
			this._iSkip = 0;
			this._iTop = 50000;
			this._getPOs().then(() => {

				if (!this._PODialog) {
					Fragment.load({
						name: "com.service.entry.serviceentry.view.fragments.POs",
						controller: this
					}).then((oDialog) => {
						this._PODialog = oDialog;
						this.getView().addDependent(this._PODialog);
						this._PODialog.open();
					});
				} else {
					this._PODialog.open();
				}

			});

		},

		_getPOs: function () {
			sap.ui.core.BusyIndicator.show();
			return new Promise((fnResolve, fnReject) => {
				this._oAppViewModel.setProperty("/PORange", "from " + this._iSkip + " to " + this._iTop);

				this.oDataModel.read("/ValueHelpPONumSet", {
					urlParameters: {
						"$skip": this._iSkip,
						"$top": this._iTop
					},
					success: function (oData) {
						sap.ui.core.BusyIndicator.hide();
						if (oData.results.length > 0) {
							this._oAppViewModel.setProperty("/POs", oData.results);
						} else {
							this._oAppViewModel.setProperty("/POs", []);
						}
						this._oAppViewModel.refresh(true);
						fnResolve();
					}.bind(this),
					error: function (error) {
						sap.ui.core.BusyIndicator.hide();
						MessageBox.error(JSON.stringify(error));
						fnReject();
					}
				});

			});
		},

		onSearchPO: function (oEvent) {
			var sValue = oEvent.getParameter("query") || oEvent.getParameter("newValue");
			var oList = oEvent.getSource().getParent().getContent()[2];
			var aFilter = [];
			aFilter.push(
				new Filter({
					path: "PONum",
					operator: FilterOperator.Contains,
					value1: sValue
				})
			);
			aFilter.push(
				new Filter({
					path: "VendorName",
					operator: FilterOperator.Contains,
					value1: sValue
				})
			);
			if (sValue) {
				oList.getBindingInfo("items").binding.filter(
					new Filter({
						filters: aFilter,
						and: false
					})
				);
			} else {
				oList.getBindingInfo("items").binding.filter([]);
			}
		},
		onPOBtnClose: function () {
			this._PODialog.close();
		},

		onTableItemSelection: function (oEvent) {
			if (oEvent.getSource().getSelectedItems().length > 0) {
				this._oAppViewModel.setProperty("/bIsItemSelected", true);
			} else {
				this._oAppViewModel.setProperty("/bIsItemSelected", false);
			}
			this._oAppViewModel.refresh(true);
		},

		onStartPeriodChange: function (oEvent) {
			var oStartPeriod = oEvent.getSource().getDateValue();
			var oEndPeriod;
			if (this._oAppViewModel.getProperty("/mode") === "CREATE") {
				oEndPeriod = this._oAppViewModel.getProperty("/createDetail/periodend");
				this._oAppViewModel.setProperty("/endPeriodMinDate", oStartPeriod);
				if (oEndPeriod && oStartPeriod.getTime() > oEndPeriod.getTime()) {
					this._oAppViewModel.setProperty("/createDetail/periodend", "");
				}
			} else {
				oEndPeriod = this._oAppViewModel.getProperty("/detailpage/periodend");
				this._oAppViewModel.setProperty("/endPeriodMinDate", oStartPeriod);
				if (oEndPeriod && oStartPeriod.getTime() > oEndPeriod.getTime()) {
					this._oAppViewModel.setProperty("/detailpage/periodend", "");
				}
			}
		},
		onSubmitQty: function (oEvent) {

			var sRemainingQty = oEvent.getParameter("value");
			var oContext = oEvent.getSource().getBindingContext("AppViewModel"),
				data = oContext.getProperty(oContext.getPath());
			// var sConsumedQty = parseInt(data.Actualqty, 10) - parseInt(sRemainingQty, 10);
			var sConsumedQty = parseInt(sRemainingQty, 10) + parseInt(data.Consumqty, 10);

			if (!this._oAppViewModel.getProperty("/currentNetValue")) {
				this._oAppViewModel.setProperty("/currentNetValue", data.price);
			}

			var iCalculatePercent = (sConsumedQty * 100) / (parseInt(data.Actualqty, 10) * 100);
			iCalculatePercent = iCalculatePercent * 100; // qty in percentage
			iCalculatePercent = parseInt(iCalculatePercent, 10) + "";
			data.fillRate = iCalculatePercent;
			data.displayQty = sConsumedQty + "/" + data.Actualqty;

			data.netvalue = parseFloat(this._oAppViewModel.getProperty("/currentNetValue")) * parseFloat(sRemainingQty) + "";
			oContext.getModel().setProperty(oContext.getPath(), data);
			// oContext.getModel().refresh(true);
		},

		onPrevious: function () {
			if (this._iSkip === 0) {
				this._oAppViewModel.setProperty("/previousBtn", false);
				return;
			}
			this._oAppViewModel.refresh(true);
			this._iSkip = this._iSkip === 0 ? 0 : this._iSkip - 50000;
			this._iTop = this._iTop === 50000 ? 50000 : this._iTop - 50000;
			this._getPOs();
		},

		onNext: function () {
			if (this._iSkip > 0) {
				this._oAppViewModel.setProperty("/previousBtn", true);
			}

			this._iSkip = this._iSkip + 50000;
			this._iTop = this._iTop + 50000;
			this._getPOs();
		}

		// onAfterRendering: function () {
		// 	if (sap.ushell && sap.ushell.Container && sap.ushell.Container.getRenderer("fiori2")) {
		// 		sap.ushell.Container.getRenderer("fiori2").hideHeaderItem("backBtn", false);
		// 	}
		// }

	});
});