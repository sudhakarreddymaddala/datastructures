sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History",
	"sap/m/MessageBox",
	"com/service/entry/serviceentry/model/formatter",
	"sap/m/MessageToast"
], function (Controller, History, MessageBox, Formatter, MessageToast) {
	"use strict";

	return Controller.extend("com.service.entry.serviceentry.controller.BaseController", {
		formatter: Formatter,

		/**
		 * Convenience method for accessing the router in every controller of the application.
		 * @public
		 * @returns {sap.ui.core.routing.Router} the router for this component
		 */
		getRouter: function () {
			return this.getOwnerComponent().getRouter();
		},

		/**
		 * Convenience method for getting the view model by name in every controller of the application.
		 * @public
		 * @param {string} sName the model name
		 * @returns {sap.ui.model.Model} the model instance
		 */
		getModel: function (sName) {
			return this.getView().getModel(sName);
		},

		/**
		 * Convenience method for setting the view model in every controller of the application.
		 * @public
		 * @param {sap.ui.model.Model} oModel the model instance
		 * @param {string} sName the model name
		 * @returns {sap.ui.mvc.View} the view instance
		 */
		setModel: function (oModel, sName) {
			return this.getView().setModel(oModel, sName);
		},

		/**
		 * Convenience method for getting the resource bundle.
		 * @public
		 * @returns {sap.ui.model.resource.ResourceModel} the resourceModel of the component
		 */
		getResourceBundle: function () {
			return this.getOwnerComponent().getModel("i18n").getResourceBundle();
		},

		/**
		 * Event handler for navigating back.
		 * It there is a history entry we go one step back in the browser history
		 * If not, it will replace the current entry of the browser history with the master route.
		 * @public
		 */
		onNavBack: function () {
			var sPreviousHash = History.getInstance().getPreviousHash();

			if (sPreviousHash !== undefined) {
				// eslint-disable-next-line sap-no-history-manipulation
				history.go(-1);
			} else {
				this.getRouter().navTo("master", {}, true);
			}
		},
		/**
		 * Toggle between full and non full screen mode.
		 */
		toggleFullScreen: function () {
			var bFullScreen = this.getModel("appView").getProperty("/actionButtonsInfo/midColumn/fullScreen");
			this.getModel("appView").setProperty("/actionButtonsInfo/midColumn/fullScreen", !bFullScreen);
			if (!bFullScreen) {
				// store current layout and go full screen
				this.getModel("appView").setProperty("/previousLayout", this.getModel("appView").getProperty("/layout"));
				this.getModel("appView").setProperty("/layout", "MidColumnFullScreen");
			} else {
				// reset to previous layout
				this.getModel("appView").setProperty("/layout", this.getModel("appView").getProperty("/previousLayout"));
			}
		},
		_showResponseErrMsg: function (oError) {
			if (Formatter.isJSON(oError.responseText)) {
				MessageBox.error(JSON.parse(oError.responseText).error.message.value);
			} else {
				try {
					var oDOMParser = new DOMParser();
					var oXMLError = oDOMParser.parseFromString(oError.responseText, "application/xml");
					MessageBox.error(oXMLError.all[2].innerHTML);
				} catch (e) {
					MessageBox.error(e);
				}
			}
		},
		_getMasterList: function () {
			// var oODATAModel = new sap.ui.model.odata.ODataModel("/serviceenty/odata/SAP/ZSES_CREATE_SERVICEENTRY_SHEET_SRV/");
			sap.ui.core.BusyIndicator.show(3000);

			// Prepare item data
			// oODATAModel.read("/SEheaderSet", {
			this.oDataModel.read("/SEheaderSet", {
				success: function (oData) {
					sap.ui.core.BusyIndicator.hide();
					if (oData.results.length > 0) {
						this._oAppViewModel.setProperty("/masterlist", oData.results);
						this._setTitle(oData.results);
					} else {
						this._oAppViewModel.setProperty("/masterlist", []);
						this._oAppViewModel.setProperty("/allCount", "");
						this._oAppViewModel.setProperty("/acceptedCount", "");
						this._oAppViewModel.setProperty("/notAcceptedCount", "");
						this._oAppViewModel.setProperty("/workflowCount", "");
					}
					let bIsRefresh = this._oAppViewModel.getProperty("/bIsReload"),
						sSelectedSE = this._oAppViewModel.getProperty("/selectedSE");
					if (bIsRefresh) {
						let oTable = this.getOwnerComponent()._oAllTable;
						oTable.getItems()[1].firePress(oTable.getItems()[1]);
					}

				}.bind(this),
				error: function (error) {
					sap.ui.core.BusyIndicator.hide();
					MessageBox.error(JSON.stringify(error));
				}
			});
		},
		_setTitle: function (oData) {
			this._oAppViewModel.setProperty("/allCount", oData.length);
			var aAccepted = oData.filter((data) => data.status === "X" && data.sesstatus === "");
			this._oAppViewModel.setProperty("/acceptedCount", aAccepted.length ? aAccepted.length : 0);
			var aNotAccepted = oData.filter((data) => data.status === "" && data.sesstatus === "");
			this._oAppViewModel.setProperty("/notAcceptedCount", aNotAccepted.length ? aNotAccepted.length : 0);
			var aworkflow = oData.filter((data) => data.sesstatus === "W");
			this._oAppViewModel.setProperty("/workflowCount", aworkflow.length ? aworkflow.length : 0);
		},

		_getTable: function () {
			var oTable;

			var _oComponent = this.getOwnerComponent();
			if (this._selectedKey === "A") {
				oTable = _oComponent._oATable;
			} else if (this._selectedKey === "NA") {
				oTable = _oComponent._oNATable;
			} else if (this._selectedKey === "WF") {
				oTable = _oComponent._oWFTable;
			} else {
				oTable = _oComponent._oAllTable;
			}

			return oTable;

		},

		onAcceptCreate: function () {
			let oPromise = new Promise((fnResolve, Reject) => {
				var oTable = this._getTable();
				let oSelectedSE = [];
				oSelectedSE[0] = oTable._aSelectedPaths.length > 0 ? oTable._aSelectedPaths[0] : this._oAppViewModel.getProperty("/detailpage");
				this.oDataModel.setUseBatch(true);
				var iCnt = oTable._aSelectedPaths.length > 0 ? oTable._aSelectedPaths.length : 1;
				//	var oDataToSend = [];
				var oEntry = null;
				for (var i = 0; i < iCnt; i++) {
					if (oTable._aSelectedPaths.length > 0) {
						oEntry = oTable.getModel("AppViewModel").getProperty(oTable._aSelectedPaths[i]);
					} else {
						oEntry = oSelectedSE[0];
					}
					//	let	obj= Object.assign({}, [oEntry]);
					// delete oEntry.SEItemDetails;
					// oModel.create("/SEheaderSet", oEntry, {
					sap.ui.core.BusyIndicator.show();

					this.oDataModel.create("/SEheaderSet", oEntry, {
						method: "POST",
						success: (data) => {
							sap.ui.core.BusyIndicator.hide();
							this._oAppViewModel.setProperty("/mode", "DISPLAY");
							this._oAppViewModel.setProperty("/bIsSelectedPO", false);
							this.getOwnerComponent().oListSelector.clearMasterListSelection();
							this.getRouter().navTo("master");
							var msg = "Accepted successfully";
							MessageBox.alert(msg);
							fnResolve();
						},
						error: (e) => {
							sap.ui.core.BusyIndicator.hide();
							Reject();
						}
					});

				}

				// oModel.submitChanges({
				this.oDataModel.submitChanges({
					success: function () {}.bind(this),
					error: function () {}.bind(this)
				});
			});

			oPromise.then(() => {
				this._getMasterList();
			});

		},

		_setPoLineItem: function () {
			var sPONum = this._oAppViewModel.getProperty("/detailpage/PONum");
			sap.ui.core.BusyIndicator.show();

			this.oDataModel.read("/ValueHelpPONumSet('" + sPONum + "')/POItem", {
				success: function (oData) {
					sap.ui.core.BusyIndicator.hide();

					if (oData.results.length > 0) {
						this._oAppViewModel.setProperty("/POItems", oData.results);
					} else {
						this._oAppViewModel.setProperty("/POItems", []);
					}

				}.bind(this),
				error: function (error) {
					sap.ui.core.BusyIndicator.hide();
					MessageBox.error(JSON.stringify(error));
				}
			});
		},

		_setServiceLineItem: function (bIsDetailAction, sPONumFromUrl, sPOItemFromUrl, bIsNewSE) {

			return new Promise((fnResolve, fnReject) => {
				var sPONum = this._oAppViewModel.getProperty("/detailpage/PONum");
				var sPOItem = this._oAppViewModel.getProperty("/detailpage/POItem");
				var sserviceentry = this._oAppViewModel.getProperty("/detailpage/serviceentry");

				// Show message if PO/item is empty
				if (!sPONum || !sPOItem) {
					sPONum = sPONumFromUrl ? sPONumFromUrl : "";
					sPOItem = sPOItemFromUrl ? sPOItemFromUrl : "";
					sserviceentry = sserviceentry ? sserviceentry : "";

					if (sPOItemFromUrl && sPONumFromUrl && sPONumFromUrl !== "NA" && sPONumFromUrl !== "NA") {
						// this.getRouter().navTo("master");
					} else {
						MessageToast.show("Enter PO/Item");
						return;
					}
				}
				var sKey;
				if (bIsNewSE) {
					sKey = sPONum + sPOItem;
				} else {
					sKey = sPONum + sPOItem; // + sserviceentry;
				}
				this.oDataModel.read("/ValueHelpPONumSet('" + sKey + "')/ServLineItems", {
					success: function (oData) {
						sap.ui.core.BusyIndicator.hide();
						var oShortTxt = [];
						var bIsNewLineItem = this._oAppViewModel.getProperty("/bIsNewLineItem"); // Get new line item or not from add buttons

						var shortTxtJsonModel = this.getOwnerComponent().getModel("shortText");
						var aAllShortTxts = this._oAppViewModel.getProperty("/allShortTexts");
						if (this._oAppViewModel.getProperty("/mode") === "CREATE") {

							if (oData.results.length > 0) {

								this._oAppViewModel.setProperty("/bIsItemSelected", true);

								var oCreateData = this._oAppViewModel.getProperty("/create");
								oCreateData = oCreateData && oCreateData.length > 0 && bIsNewLineItem ? oCreateData : [];

								// Set short text
								oData.results.forEach((data) => {
									oShortTxt.push({
										servicelinetext: data.shorttext
									});
									data.price = parseFloat(data.Netwr) / parseFloat(data.Remqty);
								});

								if (oShortTxt.length > 0) {
									shortTxtJsonModel.setData(oShortTxt);
								} else {
									shortTxtJsonModel.setData([]);
								}
								shortTxtJsonModel.refresh(true);

								oCreateData.push({
									Linenum: "",
									activitynum: "",
									RemainingQty: "",
									fillRate: "",
									displayQty: "",
									Meins: "",
									wbslement: "",
									costcenter: "",
									grossvalue: "",
									netvalue: "",
									Actualqty: "",
									Consumqty: ""
								});

								this._oAppViewModel.setProperty("/create", oCreateData);
								this._oAppViewModel.setProperty("/allItemData", oData.results);

							} else {
								this._oAppViewModel.setProperty("/bIsItemSelected", false);

								this._oAppViewModel.setProperty("/create", []);
								this._oAppViewModel.setProperty("/allItemData", []);
							}

						} else {
							if (oData.results.length > 0) {

								// Set short text
								oData.results.forEach((data) => {
									oShortTxt.push({
										servicelinetext: data.shorttext
									});
								});

								if (oShortTxt.length > 0) {
									shortTxtJsonModel.setData(oShortTxt);
								} else {
									shortTxtJsonModel.setData([]);
								}
								shortTxtJsonModel.refresh(true);

								var oItemData = this._oAppViewModel.getProperty("/itemDetails");
								oItemData = oItemData && oItemData.length > 0 && bIsNewLineItem ? oItemData : [];

								let sMode = this._oAppViewModel.getProperty("/mode");
								if (aAllShortTxts && aAllShortTxts.length > 0 && !bIsDetailAction && sMode !== "DISPLAY") {
									this._oAppViewModel.setProperty("/bIsItemSelected", true);

									aAllShortTxts.forEach((sShortText) => {
										var oFilterShortTextData = oData.results.filter((itemData) => itemData.shorttext === sShortText)[0];
										this._addItem(oFilterShortTextData, oItemData, sShortText);
									});
								} else if (sMode === "DISPLAY") {

									oData.results.forEach((item) => {
										this._addItem(item, oItemData, item.shorttext);
									});

									let oCloneItemData = Object.assign([], oItemData);
									this._oAppViewModel.setProperty("/clonnedDataItem", oCloneItemData);

								} else {
									oItemData.push({
										Linenum: "",
										activitynum: "",
										RemainingQty: "",
										fillRate: "",
										displayQty: "",
										Meins: "",
										wbslement: "",
										costcenter: "",
										grossvalue: "",
										netvalue: "",
										Actualqty: "",
										Consumqty: ""
									});
								}

								this._oAppViewModel.setProperty("/itemDetails", oItemData);
								this._oAppViewModel.setProperty("/allItemData", oData.results);

							} else {
								this._oAppViewModel.setProperty("/bIsItemSelected", false);

								this._oAppViewModel.setProperty("/itemDetails", []);
								this._oAppViewModel.setProperty("/allItemData", []);
							}
						}

						this._oAppViewModel.setProperty("/currentNetValue", null);

						fnResolve();
					}.bind(this),
					error: function (error) {
						sap.ui.core.BusyIndicator.hide();
						MessageBox.error(JSON.stringify(error));
						fnReject();
					}
				});
			});

		},

		_addItem: function (oFilterShortTextData, oItemData, sShortText) {
			var iCalculatePercent = (parseInt(oFilterShortTextData.Consum, 10) * 100) / (parseInt(oFilterShortTextData.Actual, 10) *
				100);
			iCalculatePercent = iCalculatePercent * 100; // qty in percentage
			iCalculatePercent = parseInt(iCalculatePercent, 10) + "";

			let sQty, sMode = this._oAppViewModel.getProperty("/mode");
			if (sMode === "DISPLAY" || sMode === "EDIT") {
				sQty = oFilterShortTextData.Menge;
			} else {
				sQty = oFilterShortTextData.Remqty;
			}

			oItemData.push({
				Linenum: oFilterShortTextData.Extrow,
				activitynum: oFilterShortTextData.Srvpos,
				RemainingQty: sQty,
				fillRate: iCalculatePercent,
				displayQty: oFilterShortTextData.Consum + "/" + oFilterShortTextData.Actual,
				Meins: oFilterShortTextData.Meins,
				wbslement: oFilterShortTextData.PsPspPnr,
				costcenter: oFilterShortTextData.Kostl,
				grossvalue: oFilterShortTextData.grossvalue,
				netvalue: oFilterShortTextData.Netwr,
				Actualqty: oFilterShortTextData.Actual,
				Consumqty: oFilterShortTextData.Consum,
				servicelinetext: sShortText,
				price: parseFloat(oFilterShortTextData.Netwr) / parseFloat(sQty)
			});
		}

	});
});