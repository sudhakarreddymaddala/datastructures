sap.ui.define([
	"./BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/Sorter",
	"sap/ui/model/FilterOperator",
	"sap/m/GroupHeaderListItem",
	"sap/ui/Device",
	"sap/ui/core/Fragment",
	"../model/formatter"
], function (BaseController, JSONModel, Filter, Sorter, FilterOperator, GroupHeaderListItem, Device, Fragment, formatter) {
	"use strict";

	return BaseController.extend("com.service.entry.serviceentry.controller.Master", {
		_mViewSettingsDialogs: {},
		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the master list controller is instantiated. It sets up the event handling for the master/detail communication and other lifecycle tasks.
		 * @public
		 */
		onInit: function () {
			this.oDataModel = this.getOwnerComponent().getModel();
			this.getRouter().getRoute("master").attachPatternMatched(this._onMasterMatched, this);
			this.getRouter().getRoute("object").attachPatternMatched(this._onDetailPage, this);
			this._oAppViewModel = this.getOwnerComponent().getModel("AppViewModel");
			this._oAppViewModel.setProperty("/bIsActionTriggered", true);
			this.mGroupFunctions = {
				PONum: function (oContext) {
					var name = oContext.getProperty("PONum");
					return {
						key: name,
						text: name
					};
				},
				shorttext: function (oContext) {
					var name = oContext.getProperty("shorttext");
					return {
						key: name,
						text: name
					};
				}
			};
			this._oAppViewModel.setProperty("/bIsCopy", true);
			this._oAppViewModel.setProperty("/bIsDetailActive", false);
			this._getMasterList();
		},
		_onDetailPage: function (oEvent) {
			var sObjectId = oEvent.getParameter("arguments").objectId;
			this._oAppViewModel.setProperty("/bIsReload", true);
			this._oAppViewModel.setProperty("/selectedSE", sObjectId);
		},

		iconTabBarSelect: function (oEvent) {

			var sSelectedKey = oEvent.getSource().getSelectedKey();

			if (this._currentTab === oEvent.getParameter("item").getId()) {
				this._currentTab = oEvent.getParameter("item").getId();
				// If we press same tab again, return back, do not do anything
				return;
			} else {
				this._currentTab = oEvent.getParameter("item").getId();
			}
			if (sSelectedKey === "A") {
				this._selectedKey = "A";
			} else if (sSelectedKey === "NA") {
				this._selectedKey = "NA";
			} else if (sSelectedKey === "WF") {
				this._selectedKey = "WF";
			} else {
				this._selectedKey = "ALL";
			}
			this._oAppViewModel.setProperty("/selectedKey", this._selectedKey);

			this._oAppViewModel.setProperty("/detailpage", {});
			this._oAppViewModel.setProperty("/detailpage/shorttext", "");
			this._oAppViewModel.setProperty("/itemDetails", []);
			this._oAppViewModel.setProperty("/create", []);
			this._oAppViewModel.setProperty("/hideDetail", false);
			this._oAppViewModel.setProperty("/selectedTab", this._selectedKey);
			this._oAppViewModel.refresh(true);

			var oDomRefFirstSE = sSelectedKey === "ALL" ? this._getTable().getItems()[1] : this._getTable().getItems()[1];
			var bIsDetailActive = this._oAppViewModel.getProperty("/bIsDetailActive");

			if (oDomRefFirstSE && bIsDetailActive) {
				this._oAppViewModel.setProperty("/hideDetail", true);
				oDomRefFirstSE.firePress(oDomRefFirstSE);
			} else {
				this._oAppViewModel.setProperty("/hideDetail", false);
				this._sPreviousSE = null;
				this.getRouter().navTo("object", {
					objectId: "EMPTYSCREEN",
					POItem: "NA",
					PONum: "NA"
				});
			}
		},

		/**
		 * Event handler for the master search field. Applies current
		 * filter value and triggers a new search. If the search field's
		 * 'refresh' button has been pressed, no new search is triggered
		 * and the list binding is refresh instead.
		 * @param {sap.ui.base.Event} oEvent the search event
		 * @public
		 */
		onSearch: function (oEvent) {
			var oList = this._getTable();
			var sValue = oEvent.getParameter("query") || oEvent.getParameter("newValue");
			var aStatusFilter = [],
				aMultipleFilter = [],
				aMainFilter = [];
			if (sValue) {
				aMultipleFilter.push(
					new Filter({
						path: "shorttext",
						operator: FilterOperator.Contains,
						value1: sValue
					})
				);
				aMultipleFilter.push(
					new Filter({
						path: "serviceentry",
						operator: FilterOperator.Contains,
						value1: sValue
					})
				);
				aMultipleFilter.push(
					new Filter({
						path: "PONum",
						operator: FilterOperator.Contains,
						value1: sValue
					})
				);
				aMainFilter.push(
					new Filter({
						filters: aMultipleFilter,
						and: false
					})
				);
				if (this._selectedKey === "A") {
					aStatusFilter.push(
						new Filter({
							path: "status",
							operator: FilterOperator.EQ,
							value1: "X"
						})
					);
					aStatusFilter.push(
						new Filter({
							path: "sesstatus",
							operator: FilterOperator.EQ,
							value1: ""
						})
					);
				} else if (this._selectedKey === "NA") {
					aStatusFilter.push(
						new Filter({
							path: "status",
							operator: FilterOperator.EQ,
							value1: ""
						})
					);
					aStatusFilter.push(
						new Filter({
							path: "sesstatus",
							operator: FilterOperator.EQ,
							value1: ""
						})
					);
				} else if (this._selectedKey === "WF") {
					aStatusFilter.push(
						new Filter({
							path: "sesstatus",
							operator: FilterOperator.EQ,
							value1: "W"
						})
					);
				} else {
					// exceptional case
				}
				aMainFilter.push(
					new Filter({
						filters: aStatusFilter,
						and: true
					})
				);
				// applay filters when value entered
				oList.getBindingInfo("items").binding.filter(aMainFilter);
			} else {
				if (this._selectedKey === "A") {
					aStatusFilter.push(
						new Filter({
							path: "status",
							operator: FilterOperator.EQ,
							value1: "X"
						})
					);
					aStatusFilter.push(
						new Filter({
							path: "sesstatus",
							operator: FilterOperator.EQ,
							value1: ""
						})
					);
					oList.getBindingInfo("items").binding.filter(aStatusFilter);
				} else if (this._selectedKey === "NA") {
					aStatusFilter.push(
						new Filter({
							path: "status",
							operator: FilterOperator.EQ,
							value1: ""
						})
					);
					aStatusFilter.push(
						new Filter({
							path: "sesstatus",
							operator: FilterOperator.EQ,
							value1: ""
						})
					);
					oList.getBindingInfo("items").binding.filter(aStatusFilter);
				} else if (this._selectedKey === "WF") {
					aStatusFilter.push(
						new Filter({
							path: "sesstatus",
							operator: FilterOperator.EQ,
							value1: "W"
						})
					);
					oList.getBindingInfo("items").binding.filter(aStatusFilter);
				} else {
					oList.getBindingInfo("items").binding.filter([]);
				}
			}

		},

		/**
		 * Event handler for the list selection event
		 * @param {sap.ui.base.Event} oEvent the list selectionChange event
		 * @public
		 */
		onSelectionChange: function (oEvent) {

			this._oAppViewModel.setProperty("/bIsCopy", true);

			this._oAppViewModel.setProperty("/mode", "DISPLAY");
			this.getModel("appView").setProperty("/bIsCreate", false);

			var oSource = oEvent.getSource();

			// set the layout property of FCL control to show two columns
			this.getModel("appView").setProperty("/layout", "TwoColumnsMidExpanded");
			var sPath = oSource.getBindingContext("AppViewModel").getPath(),
				oSelectedServiceEntry = oSource.getBindingContext("AppViewModel").getProperty(sPath);

			if (this._sPreviousSE === oSelectedServiceEntry.serviceentry) {
				this.getRouter().navTo("object", {
					objectId: "EMPTYSCREEN",
					POItem: "NA",
					PONum: "NA"
				}, false);
				this._oAppViewModel.setProperty("/itemDetails", []);

			} else {
				this._oAppViewModel.setProperty("/itemDetails", []);
				this._sPreviousSE = oSelectedServiceEntry.serviceentry;
			}

			// Convert date to js date
			if (oSelectedServiceEntry.periodstart) {
				oSelectedServiceEntry.periodstart = new Date(oSelectedServiceEntry.periodstart);
				this._oAppViewModel.setProperty("/endPeriodMinDate", new Date(oSelectedServiceEntry.periodstart));
			}
			oSelectedServiceEntry.periodend = new Date(oSelectedServiceEntry.periodend);
			oSelectedServiceEntry.postingdate = new Date(oSelectedServiceEntry.postingdate);
			oSelectedServiceEntry.documentdate = new Date(oSelectedServiceEntry.documentdate);

			this._oAppViewModel.setProperty("/detailpage", oSelectedServiceEntry);

			this._oAppViewModel.setProperty("/allShortTexts", []);

			let oClonnedData = Object.assign({}, oSelectedServiceEntry);
			this._oAppViewModel.setProperty("/clonnedDataHeader", oClonnedData);

			this._oAppViewModel.setProperty("/bIsDetailActive", true);
			this._oAppViewModel.setProperty("/hideDetail", true);

			this.getRouter().navTo("object", {
				objectId: oSelectedServiceEntry && oSelectedServiceEntry.serviceentry,
				POItem: oSelectedServiceEntry && oSelectedServiceEntry.POItem,
				PONum: oSelectedServiceEntry && oSelectedServiceEntry.PONum
			}, false);
		},

		/**
		 * Event handler for navigating back.
		 * We navigate back in the browser historz
		 * @public
		 */
		onNavBack: function () {
			// eslint-disable-next-line sap-no-history-manipulation
			history.go(-1);
		},

		_onMasterMatched: function () {
			this._oAppViewModel.setProperty("/bIsReload", false);
			let bIsActionTriggered = this._oAppViewModel.getProperty("/bIsActionTriggered");
			if (this.byId("iconTabBar") && bIsActionTriggered) {
				this._oAppViewModel.setProperty("/selectedTab", "ALL");
				this.byId("iconTabBar").setSelectedKey("ALL");
				this._currentTab = "ALL";
			}

			if (bIsActionTriggered) {
				this._oAppViewModel.setProperty("/bIsActionTriggered", false);
				this._getMasterList();
			}

			//Set the layout property of the FCL control to 'OneColumn'
			this.getModel("appView").setProperty("/layout", "OneColumn");
			this._oAppViewModel.setProperty("/bIsDetailActive", false);

		},

		onDelete: function (oEvent) {

		},
		onCreate: function () {
			this._oAppViewModel.setProperty("/hideDetail", true);
			this._getTable().removeSelections(true);
			this._oAppViewModel.setProperty("/bIsItemSelected", false);
			var bIsOneColumn = this.getModel("appView").getProperty("/layout");

			this._oAppViewModel.setProperty("/bIsCopy", false);
			this._oAppViewModel.setProperty("/mode", "CREATE");
			this.getModel("appView").setProperty("/bIsCreate", true);
			this._oAppViewModel.setProperty("/create", []);

			let bIsDetailActive = this._oAppViewModel.getProperty("/bIsDetailActive");
			if (bIsDetailActive) {
				this._oAppViewModel.setProperty("/showTwoColumns", true);
			} else {
				this._oAppViewModel.setProperty("/showTwoColumns", false);
			}

			let sStartDate = this._oAppViewModel.getProperty("/detailpage/periodstart");
			sStartDate = sStartDate ? new Date(sStartDate) : "";
			let sEndDate = this._oAppViewModel.getProperty("/detailpage/periodend");
			sEndDate = sEndDate ? new Date(sEndDate) : "";

			this._setPoLineItem();

			this._oAppViewModel.setProperty("/createDetail", {
				postingdate: new Date(),
				documentdate: new Date(),
				periodend: sEndDate,
				periodstart: sStartDate
			});

			if (bIsOneColumn === "OneColumn") {
				this.getRouter().navTo("object", {
					objectId: "new entry",
					POItem: "NA",
					PONum: "NA"
				});
				this.getModel("appView").setProperty("/newEntry", true);
			} else {
				var aAllShortTxts = [];
				var aItemDetail = this._oAppViewModel.getProperty("/itemDetails");
				aItemDetail.forEach((lineitem) => {
					aAllShortTxts.push(lineitem.servicelinetext);
				});
				this._oAppViewModel.setProperty("/allShortTexts", aAllShortTxts);

				this.toggleFullScreen();
				this.getModel("appView").setProperty("/newEntry", false);
				///////////////////////
				if (bIsDetailActive) {
					this._oAppViewModel.setProperty("/bIsNewSE", true);
					this._oAppViewModel.setProperty("/bIsCopy", false);
					this._oAppViewModel.setProperty("/mode", "CREATE");
					this.getModel("appView").setProperty("/bIsCreate", true);
					this._oAppViewModel.setProperty("/create", []);
					this._oAppViewModel.setProperty("/detailpage", {});
					this._oAppViewModel.setProperty("/itemDetails", []);
					this._oAppViewModel.setProperty("/create", []);
					this._oAppViewModel.setProperty("/createDetail/periodend", "");
					this._oAppViewModel.setProperty("/createDetail/periodstart", "");
				} else {
					this._oAppViewModel.setProperty("/bIsNewSE", false);

					this._setServiceLineItem();
				}
				///////////////////////
			}
			this._oAppViewModel.refresh(true);
		},
		onCopy: function () {
			//Clone short test from detail
			var aAllShortTxts = [];
			var aItemDetail = this._oAppViewModel.getProperty("/itemDetails");
			aItemDetail.forEach((lineitem) => {
				aAllShortTxts.push(lineitem.servicelinetext);
			});

			var sShortTxt = this._oAppViewModel.getProperty("/detailpage/shorttext");
			this._oAppViewModel.setProperty("/detailpage/shorttext", "Copy of " + sShortTxt);

			var sServiceentryortTxt = this._oAppViewModel.getProperty("/detailpage/serviceentry");
			this._oAppViewModel.setProperty("/copyTitle", "Copy from " + sServiceentryortTxt);

			this._oAppViewModel.setProperty("/allShortTexts", aAllShortTxts);

			this._oAppViewModel.setProperty("/itemDetails", []);

			this._setPoLineItem();

			this._oAppViewModel.setProperty("/hideDetail", true);
			var aItemDetails = this._oAppViewModel.getProperty("/itemDetails");
			if (aItemDetails.length > 0) {
				this._oAppViewModel.setProperty("/bIsItemSelected", true);
			} else {
				this._oAppViewModel.setProperty("/bIsItemSelected", false);
			}
			this._oAppViewModel.setProperty("/bIsCopy", true);
			this.toggleFullScreen();
			this._oAppViewModel.setProperty("/mode", "EDIT");
			this._setServiceLineItem();
		},
		getViewSettingsDialog: function (sDialogFragmentName) {
			var pDialog = this._mViewSettingsDialogs[sDialogFragmentName];

			if (!pDialog) {
				pDialog = Fragment.load({
					id: this.getView().getId(),
					name: sDialogFragmentName,
					controller: this
				}).then(function (oDialog) {
					oDialog.addStyleClass("sapUiSizeCompact");
					return oDialog;
				});
				this._mViewSettingsDialogs[sDialogFragmentName] = pDialog;
			}
			return pDialog;
		},

		handleSortButtonPressed: function () {
			this.getViewSettingsDialog("com.service.entry.serviceentry.view.fragments.Sort")
				.then(function (oViewSettingsDialog) {
					oViewSettingsDialog.open();
				});
		},

		handleGroupButtonPressed: function () {
			this.getViewSettingsDialog("com.service.entry.serviceentry.view.fragments.Grouping")
				.then(function (oViewSettingsDialog) {
					oViewSettingsDialog.open();
				});
		},

		handleSortDialogConfirm: function (oEvent) {
			var oTable = this._getTable(),
				mParams = oEvent.getParameters(),
				oBinding = oTable.getBinding("items"),
				sPath,
				bDescending,
				aSorters = [];

			sPath = mParams.sortItem.getKey();
			bDescending = mParams.sortDescending;
			aSorters.push(new Sorter(sPath, bDescending));

			// apply the selected sort and group settings
			oBinding.sort(aSorters);
		},
		handleGroupDialogConfirm: function (oEvent) {
			var oTable = this._getTable(),
				mParams = oEvent.getParameters(),
				oBinding = oTable.getBinding("items"),
				sPath,
				bDescending,
				vGroup,
				aGroups = [];

			if (mParams.groupItem) {
				sPath = mParams.groupItem.getKey();
				bDescending = mParams.groupDescending;
				vGroup = this.mGroupFunctions[sPath];
				aGroups.push(new Sorter(sPath, bDescending, vGroup));
				// apply the selected group settings
				oBinding.sort(aGroups);
			} else if (this.groupReset) {
				oBinding.sort();
				this.groupReset = false;
			}
		},

		onMasterListSelect: function (oEvent) {
			if (oEvent.getSource().getSelectedItems().length === 1) {
				this._oAppViewModel.setProperty("/masterCreate", true);
				var sPath = oEvent.getSource()._aSelectedPaths[0];
				this._oAppViewModel.setProperty("/bIsSelectedPO", true);
				var selectedShortTxt = oEvent.getSource().getBindingInfo("items").binding.getModel().getProperty(sPath).shorttext;
				var oList = oEvent.getSource().getBindingInfo("items").binding.getModel().getProperty("/masterlist");
				var oSelectedSE = oList.filter((data) => data.shorttext === selectedShortTxt);
				// Convert date to js date
				oSelectedSE[0].periodstart = new Date(oSelectedSE[0].periodstart);
				oSelectedSE[0].periodend = new Date(oSelectedSE[0].periodend);
				oSelectedSE[0].postingdate = new Date(oSelectedSE[0].postingdate);
				oSelectedSE[0].documentdate = new Date(oSelectedSE[0].documentdate);
				this._oAppViewModel.setProperty("/detailpage", oSelectedSE[0]);
				// this._oAppViewModel.setProperty("/detailpage", {});

				this._oAppViewModel.refresh(true);
			} else {
				this._oAppViewModel.setProperty("/bIsSelectedPO", false);
				if (oEvent.getSource().getSelectedItems().length === 0) {
					this._oAppViewModel.setProperty("/masterCreate", true);
				} else {
					this._oAppViewModel.setProperty("/masterCreate", false);
				}
			}
			this._oAppViewModel.refresh(true);
		},

		onAfterRendering: function () {
			// if (sap.ushell && sap.ushell.Container && sap.ushell.Container.getRenderer("fiori2")) {
			// 	sap.ushell.Container.getRenderer("fiori2").hideHeaderItem("backBtn", false);
			// }
			var _oComponent = this.getOwnerComponent();
			_oComponent._oATable = this.byId("idAccepted");
			_oComponent._oNATable = this.byId("idNotAccepted");
			_oComponent._oWFTable = this.byId("idworkflow");
			_oComponent._oAllTable = this.byId("idAll");

		}
	});
});