sap.ui.define([
	"Quickstart/CameraFunctionality/test/unit/controller/View1.controller"
], function () {
	"use strict";
});