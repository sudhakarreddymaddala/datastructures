/*eslint-disable no-console, no-alert ,no-debugger*/
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/Dialog",
	"sap/m/Button",
	"CameraFunctionality/libs/Download",
	"sap/m/MessageToast",
	"sap/m/MessageBox"

], function (Controller, Dialog, Button, Download, MessageToast, MessageBox) {
	"use strict";

	return Controller.extend("CameraFunctionality.controller.Snapshot", {
		onInit: function () {},
		capturePic: function () {
			// In async we can only access that pointer
			var that = this;
			// create popup object as a global variable
			this.cameraDialog = new Dialog({
				title: "Click on Capture to take a photo",
				beginButton: new Button({
					text: "Capture",
					press: function (oEvent) {
						// Get the object of our video player in which live camera streaming is running
						// Take image object out of it and set it to main page using global variable
						that.imageValue = document.getElementById("player");
						var oButton = oEvent.getSource();
						that.imageText = oButton.getParent().getContent()[1].getValue();
						that.cameraDialog.close();
						that.cameraDialog.destroy();
					}
				}),
				content: [
					new sap.ui.core.HTML({
						content: "<video id='player' autoplay></video>"
					}),
					new sap.m.Input({
						placeholder: "Please input image text here",
						required: true
					})
				],
				endButton: new Button({
					text: "Cancel",
					press: function () {
						that.cameraDialog.close();
						that.cameraDialog.destroy();
					}
				})

			});
			this.getView().addDependent(this.cameraDialog);
			this.cameraDialog.open();
			this.cameraDialog.attachBeforeClose(this.setImage, this);
			navigator.mediaDevices.getUserMedia({
				video: true
			}).then(function (stream) {
				player.srcObject = stream;
			});

		},

		setImage: function () {
			var oVBox = this.getView().byId("vBox1");
			var oItems = oVBox.getItems();
			var imageId = 'reddy-' + oItems.length;
			var fileName = this.imageText;
			var imageValue = this.imageValue;

			if (imageValue === null) {
				MessageToast.show("No image captured");
			} else {
				var oCanvas = new sap.ui.core.HTML({
					content: "<canvas id='" + imageId + "' width='320px' height='320px' " +
						" style='2px solid red'></canvas> "
				});
				var snapShotCanvas;

				oVBox.addItem(oCanvas);
				oVBox.addItem(new sap.m.Text({
					text: fileName
				}));
				oCanvas.addEventDelegate({
					onAfterRendering: function () {
						snapShotCanvas = document.getElementById(imageId);
						var oContext = snapShotCanvas.getContext('2d');
						oContext.drawImage(imageValue, 0, 0, snapShotCanvas.width, snapShotCanvas.height);
						var imageData = snapShotCanvas.toDataURL('image/png');
						var imageBase64 = imageData.substring(imageData.indexOf(",") + 1);
						// MessageBox.confirm("capture this image?", {
						// 	actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
						// 	onClose: function (sAction) {
						// 		if (sAction === "YES") {
						// 			this.close();
						// 		}
						// 	}
						// }).bind(this);
						//	window.open(imageData);  --Use this if you dont want to use third party download.js file 
						//	download(imageData, fileName + ".png", "image/png");

					}.bind(this)
				});
			}

		}
	});
});