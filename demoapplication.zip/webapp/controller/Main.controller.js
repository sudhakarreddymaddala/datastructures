sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageToast",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/Fragment"

], function (Controller, MessageToast, JSONModel,Fragment) {
	"use strict";

	return Controller.extend("com.rm.test.demo.controller.Main", {
		onInit : function () {
         // set data model on view
         var oData = {
            recipient : {
               name : "World"
            }
         };
         var oModel = new JSONModel(oData);
         this.getView().setModel(oModel);
      },
      onShowHello : function () {
         MessageToast.show("Hello World");
      },
      onOpenDialog : function(oEvent){
      	if(!this.pDialog){
      		this.pDialog = Fragment.load({
      			name: "com.rm.test.demo.view.HelloDialog"
      		});
      	}
      	 this.pDialog.then(function(oDialog) {
				oDialog.open();
			});
      },
      onCloseDialog : function(){
      	if(this.pDialog){
      	this.byId("helloDialog").close();
      		
      	}
      }
	});

});