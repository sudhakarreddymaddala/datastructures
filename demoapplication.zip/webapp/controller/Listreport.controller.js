sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/UIComponent",
	"sap/m/MessageBox",
	"sap/ui/model/json/JSONModel"
], function (Controller, UIComponent,MessageBox,JSONModel) {
	"use strict";

	return Controller.extend("com.rm.test.demo.controller.Listreport", {
		onInit: function () {
		this.oRouter = this.getOwnerComponent().getRouter();	
        
		},
		/*handleSelectChange: function (oEvent) {
			var mode = oEvent.getParameter("selectedItem").getKey();
			this.byId("ProductList").setMode(mode);
		},*/
		getRouter: function () {
			return UIComponent.getRouterFor(this);
		},
		onBConfirmationPress : function(oEvent){
			// set the layout property of FCL control to show two columns
		
		var oBindingContext = oEvent.getParameter("listItem").getBindingContext();
		this.getModel("appView").setProperty("/layout", "TwoColumnsMidExpanded");
		this.getRouter().navTo("shuntingRoute", {
			        layout: "TwoColumnsMidExpanded",
					CategoryID: oBindingContext.getProperty('CategoryID')
					
				});
			
			
		},
		getModel: function (sName) {
			return this.getView().getModel(sName);
		},
		setModel: function (oModel, sName) {
			return this.getView().setModel(oModel, sName);
		}
	});
});