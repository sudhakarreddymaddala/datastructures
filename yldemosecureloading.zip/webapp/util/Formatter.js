sap.ui.define([
	"sap/ui/core/format/DateFormat"
], function (DateFormat) {
	"use strict";

	var Formatter = {

		uppercaseFirstChar: function (sStr) {
			return sStr.charAt(0).toUpperCase() + sStr.slice(1);
		},

		StatusIcon: function (sStatus) {
			if (sStatus === 0) {
				return "sap-icon://sys-cancel";
			} else if (sStatus === 2) {
				return "sap-icon://sys-enter";
			} else {
				return "sap-icon://sys-help";
			}
		},

		iconDirection: function (sDirection) {
			if (sDirection === "Inbound") {
				return "sap-icon://download";
			} else {
				return "sap-icon://upload";
			}
		},

		statusState: function (sStatus) {
			if (sStatus === "03") {
				return "Success";
			} else {
				return "Warning";
			}
		},

		iconStatus: function (sStatus) {
			if (sStatus === "Active") {
				return "sap-icon://circle-task-2";
			} else {
				return "sap-icon://circle-task";
			}
		},

		iconColorStatus: function (sStatus) {
			if (sStatus === "Active") {
				return "#009900";
			} else {
				return "";
			}
		},

		formatStringTime: function (sDate) {
			if (sDate === null) {
				return "";
			} else {
				var sFormatedDate = "";
				var dFormatDate = DateFormat.getDateInstance({
					pattern: "HH:mm"
				});

				sFormatedDate = dFormatDate.format(sDate);

				return sFormatedDate;
			}
		},

		sliderAnswer: function (sAnswer) {
			switch (sAnswer) {
			case "1":
				return 2;

			case "0":
				return 0;

			default:
				return 1;
			}
		},

		StatusName: function (sStatus) {
			var oBundle = this.getModel("i18n").getResourceBundle();

			if (sStatus === "0") {
				return oBundle.getText("SatusName_No");
			} else if (sStatus === "1") {
				return oBundle.getText("SatusName_Yes");
			} else {
				return oBundle.getText("SatusName_ToDo");
			}
		},

		StatusStatus: function (sStatus) {
			if (sStatus === "0") {
				return "Error";
			} else if (sStatus === "1") {
				return "Success";
			} else {
				return "None";
			}
		}

	};

	return Formatter;

}, /* bExport= */ true);