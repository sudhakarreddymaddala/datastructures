jQuery.sap.require("com.westernacher.yl.secureloading.util.Constant");
jQuery.sap.declare("com.westernacher.yl.secureloading.util.Picture");
com.westernacher.yl.secureloading.util.Picture = {

	oPhotosLoadFinishedDeferred: null,
	oPicturesModel: new sap.ui.model.json.JSONModel(),

	sServicePictureUploadPath: "/sap/opu/odata/sap/ZYL_LOAD_SECURITY_SRV",

	generatePictureName: function (sType) {
		var n = new Date(),
			d = "0" + n.getDate(),
			h = "0" + n.getHours(),
			m = "0" + n.getMinutes(),
			ms = "00" + n.getMilliseconds();
		var sFileName;

		switch (sType) {
		case "Picture":
			sFileName = "YLSecureLoadingPic";

			break;
		case "Signature":
			sFileName = "YLSecureLoadingSign";

			break;
		}

		sFileName = sFileName + ms.substr(ms.length - 3) + "_" + n.getFullYear() + (n.getMonth() - 1) + d.substr(d.length - 2) + h.substr(h.length -
				2) +
			m.substr(m.length - 2) + ".png";

		return sFileName;
	},

	// YL_YardTaskNumber_Timestamp_SIG_Driver
	// YL_YardTaskNumber_Timestamp_SIG_Employee
	// YL_YardTaskNumber_Timestamp_PIC_Number

	generatePictureCustomName: function (oThis, sType) {
		var oView = oThis.getView();
		var oObject = oView.getBindingContext().getObject();
		var sYardTaskNo = oObject.YardTaskNo.substr(oObject.YardTaskNo.length - 9);

		var n = new Date(),
			d = "0" + n.getDate(),
			h = "0" + n.getHours(),
			m = "0" + n.getMinutes(),
			s = "0" + n.getSeconds();

		var sTimestamp = n.getFullYear().toString() + (n.getMonth() + 1).toString() + d.substr(d.length - 2) + h.substr(h.length - 2) + m.substr(m.length - 2) + s.substr(s.length - 2);
		var sFileName;

		switch (sType) {
		case "Picture":
			sFileName = "YLSecureLoadingPic";
			sFileName = "YL_" + sYardTaskNo + "_" + sTimestamp + "_PIC_.png";

			break;
		case "SignatureC":
			sFileName = "YL_" + sYardTaskNo + "_" + sTimestamp + "_SIG_Employee.png";

			break;
		case "SignatureD":
			sFileName = "YL_" + sYardTaskNo + "_" + sTimestamp + "_SIG_Driver.png";

			break;
		}

		return sFileName;
	},

	generatePictureDescr: function (sType) {
		var sFileDescr;

		switch (sType) {
		case "Picture":
			sFileDescr = "YL Secure Loading picture";

			break;
		case "Signature":
			sFileDescr = "YL Secure Loading signature";

			break;
		}

		return sFileDescr;
	},

	sendByFileUploader: function (that) {
		var oView = that.getView();
		var oModel = oView.getModel(); //"DocumentService"
		var sToken = oModel.getSecurityToken();

		var oObject = oView.getBindingContext().getObject();

		var sTaskKey = oObject.Key,
			sPictureDescr = "YL Secure Loading picture",
			sPictureFileName = this.generatePictureName("YLSecureLoadingPic"),
			h = null,
			H = null,
			s = "";
		var F = oView.byId("idFUPictureUploader");

		// try {
		F.setSendXHR(true);
		F.setUseMultipart(false);
		F.removeAllHeaderParameters();
		// if (sPictureFileName.indexOf(".jpeg") === -1) {
		// 	sPictureFileName += ".jpeg";
		// }
		F.setValue(sPictureFileName);
		s = window.btoa(F.getValue()) + "," + window.btoa(sPictureDescr) + "," + window.btoa("image/jpeg");
		h = new sap.ui.unified.FileUploaderParameter({
			name: "slug",
			value: s
		});
		F.insertHeaderParameter(h, -1);
		H = new sap.ui.unified.FileUploaderParameter({
			name: "X-CSRF-Token",
			value: sToken
		});
		F.insertHeaderParameter(H, -1);
		F.setUploadUrl(this.sServicePictureUploadPath + "/YardTaskSet(guid'{$}')/YardTaskATFDocumentSet".replace("{$}", sTaskKey));
		if (!F.getValue()) {
			sap.m.MessageToast.show(this.getView().getModel("i18n").getProperty("CHOOSE_FILE_MSG"));
			return;
		}
		F.upload();
		// } catch (e) {
		// 	this.oUtil.ErrorDialog(e.toString());
		// }
	},

	sendByAjaxBase64: function (that, oData) {
		var oView = that.getView();
		var oModel = oView.getModel(); //"DocumentService"
		var sToken = oModel.getSecurityToken();
		var oObject = oView.getBindingContext().getObject();
		var sTaskKey = oObject.Key;

		var sSlug;
		sSlug = window.btoa(oData.pictureName) + "," + window.btoa(oData.pictureDescr) + "," + window.btoa("image/png");

		jQuery.ajax({
			url: this.sServicePictureUploadPath + "/YardTaskSet(guid'{$}')/YardTaskATFDocumentSet".replace("{$}", sTaskKey),
			async: false,
			cache: false,
			//dataType: "text",
			//data: atob(pictureData),
			data: oData.pictureData,
			processData: false,
			//contentType: false,
			//contentType: "application/x-www-form-urlencoded;charset=ISO-8859-15",
			type: "POST",
			beforeSend: function (xhr) {
				xhr.setRequestHeader("X-CSRF-Token", sToken);
				xhr.setRequestHeader("Content-Type", "image/png");
				xhr.setRequestHeader("slug", sSlug);
				//xhr.setRequestHeader("Content-Type", "application/text;charset=UTF-8");
			},
			success: function (odata) {
				sap.m.MessageToast.show("File uploaded");
			},
			error: function (oError) {
				//sap.m.MessageToast.show("File upload error");
			}
		});
	},

	readAttachments: function (that) {
		var oView = that.getView();
		var oObject = oView.getBindingContext().getObject();

		var sTaskKey = oObject.Key;
		var sParentKey = oObject.ParentKey;

		this._loadData(that, sParentKey);
	},

	_loadData: function (that, t) {
		var oConstant = com.westernacher.yl.secureloading.util.Constant;

		this.oPhotosLoadFinishedDeferred = jQuery.Deferred();
		jQuery.when(this.oPhotosLoadFinishedDeferred).then(jQuery.proxy(function (d) {
			if (d && d.results) {
				this._prepareAttachments(d.results);
			}
		}, that));

		that.getView().getModel().read("/YardTaskATFDocumentSet?$filter=ParentKey eq guid'" + t + "'", {
			success: function (oData, oResponse) {

			},
			error: function (oError) {

			}
		});
	},

	_prepareAttachments: function (r) {
		var oConstant = com.westernacher.yl.secureloading.util.Constant;

		var f = [],
			i = 0,
			a = r.length,
			t = this;
		for (i = 0; i < a; i++) {
			var c = r[i].CategoryCode;
			if (c === "3" || c === "2") {
				f.push({
					"src": (c === "2") ? oConstant.path.attachmentMediaPath.replace("{$}", r[i].Key) : r[i].ExternalLinkWebUri,
					"thumbnail": "",
					"date": r[i].DatetimeCr,
					"description": r[i].Description,
					"name": r[i].Name,
					"mimeType": r[i].Mimecode,
					"key": r[i].Key,
					"display": true
				});
			}
		}
		this.oPicturesModel.setData({
			"items": f
		});
		for (var i = 0; i < f.length; i++) {
			(function (i, t) {
				var x = new XMLHttpRequest();
				var I = t.oConstant.path.attachmentMediaPath.replace("{$}", f[i].key);
				x.open('GET', I, true);
				x.responseType = "blob";
				x.setRequestHeader("Image-Height", "75");
				x.onload = function (b, d) {
					var e = b.response,
						u = window.URL.createObjectURL(e);
					this.oPicturesModel.setProperty("/items/" + i + "/thumbnail", u);
				}.bind(t, x);
				x.send();
			})(i, t);
		}
	}

};