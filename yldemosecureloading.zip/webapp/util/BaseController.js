sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"com/westernacher/yl/secureloading/dialogController/SignatureDialog",
	"com/westernacher/yl/secureloading/dialogController/PictureDialog",
	"com/westernacher/yl/secureloading/dialogController/ConfirmationDialog"
], function (Controller, SignatureDialog, PictureDialog, ConfirmationDialog) {
	"use strict";

	return Controller.extend("com.westernacher.yl.secureloading.util.BaseController", {
		_AppStart: false,

		getRouter: function () {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},

		onNavigationBack: function () {
			var oHistory = sap.ui.core.routing.History.getInstance(),
				sPreviousHash = oHistory.getPreviousHash();

			if (sPreviousHash !== undefined) {
				// The history contains a previous entry
				history.go(-1);
			} else {
				this.getOwnerComponent().getRouter().navTo("menu", {}, false);
			}
		},

		openPictureDialog: function (oThis, oImage, sTitle, bDeleteVisble) {
			PictureDialog.openPictureDialog(oThis, "", oImage, sTitle, bDeleteVisble);
		},

		openConfirmationDialog: function (oThis) {
			ConfirmationDialog.openConfirmationDialog(oThis, "");
		},

		// openSignatureDialog: function(oThis, sTitle) {
		// 	SignatureDialog.openSignatureDialog(oThis, "", sTitle);
		// },

		openSignatureDialog: function (oThis, sType, oObject, sTitle) {
			SignatureDialog.openSignatureDialog(oThis, "", sType, oObject, sTitle);
		},

		getI18nText: function (cValue) {
			var oBundle = this.getView().getModel("i18n").getResourceBundle();
			var sText = oBundle.getText(cValue);

			return sText;
		},

		_YardTaskCancel: function (oThis, oCurrentItemData) {
			var ofunctionParams = {
				YardTaskNo: oCurrentItemData.YardTaskNo,
				YardNo: oCurrentItemData.YardNo
			};

			var oModel = oThis.getView().getModel();

			oThis._oBusyDialog.open();

			oModel.callFunction("/RejectYardTask", {
				method: "POST",
				urlParameters: ofunctionParams,
				success: function (oData, oResponse) {
					oThis._oBusyDialog.close();
					//sap.m.MessageBox.information(that.getI18nText("ConfirmationMessage_Success"));
				},
				error: function (oError) {
					oThis._oBusyDialog.close();
					//sap.m.MessageBox.error(that.getI18nText("ConfirmationMessage_Error"));
				}
			});
		},
		// Moved _autoRefresh method from TaslList controller to BaseController to use in both SecureLoading and TaskList controller
		_autoRefresh: function () {
			var oList = this.getView().byId("idLTask");
			var iCountBefore = oList.getBinding("items").getLength();
			var that = this;

			oList.getBinding("items").attachEventOnce("dataReceived",
				function (oEvent) {
					var iCountAfter = oList.getBinding("items").getLength();

					//sap.m.MessageToast.show(iCountBefore + "     " + iCountAfter);

					// if (iCountBefore < iCountAfter) {
					// 	that._playSound();
					// }
				});

			this.onBRefreshPress();
		},

	});

});