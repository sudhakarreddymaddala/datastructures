sap.ui.define([], function () {
	"use strict";

	return {

		postalCodeValidator: function (sValue) {
			if (sValue && sValue === "12209") {
				return "Success";
			} else if (sValue && sValue === "1111") {
				return "Warning";
			}

		},
		oneMoreFunction: function () {

		},
		statusText: function (sStatus) {
			var resourceBundle = this.getView().getModel("i18n").getResourceBundle();
			switch (sStatus) {
				case "A":
					return resourceBundle.getText("invoiceStatusA");
				case "B":
					return resourceBundle.getText("invoiceStatusB");
				case "C":
					return resourceBundle.getText("invoiceStatusC");
				default:
					return sStatus;
			}
		}

	};
});