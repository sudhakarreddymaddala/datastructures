sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/UIComponent",
	"sap/m/MessageToast",
	"sap/m/MessageBox"

], function (Controller, UIComponent, MessageToast, MessageBox) {
	"use strict";

	return Controller.extend("com.rm.test.demo.controller.Detail", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.rm.test.demo.view.Detail
		 */
		onInit: function () {
			this.oDataModel = this.getOwnerComponent().getModel();
			this._oViewModel = this.getOwnerComponent().getModel("ViewModel");
			this._oModel = this.getOwnerComponent().getModel();
			this._oModel.read("/Products", {
				success: function (oData) {
					var jsonModel = new sap.ui.model.json.JSONModel(oData.results);
					this.getView().setModel(jsonModel, "AppView");
				}.bind(this),
				error: function () {}
			});
		},

		onPatternMatched: function (oEvent) {
			this.getView().bindElement({
				path: "/" + window.decodeURIComponent(oEvent.getParameter("arguments").invoicePath),
				model: "invoice"

			});

		},
		getRouter: function () {
			return UIComponent.getRouterFor(this);
		},
		onBackPress: function () {
			this.getRouter().navTo("mainRoute", {});
		},
		onEdit: function () {

			this._oViewModel.setProperty("/edit", true);
		},
		onSave: function () {

			this._oViewModel.setProperty("/edit", false);
		},
		onCancel: function () {
			this._oViewModel.setProperty("/edit", false);
		},
		onEditAdd: function () {
			this._oViewModel.setProperty("/bIsCreate", true);
		},
		onHidePress: function () {
			this._oViewModel.setProperty("/bIsCreate", false);
		},
		onSavePress: function () {

			this._oViewModel.setProperty("/create", []);
			var oHeaderData = this._oViewModel.getProperty("/create");
			var oSEHeaderData = {
				serviceentry: oHeaderData.serviceentry,
				PONum: oHeaderData.PONum,
				shorttext: oHeaderData.shorttext,
				periodstart: oHeaderData.periodstart,
				periodend: oHeaderData.periodend,
				postingdate: oHeaderData.postingdate,
				documentdate: oHeaderData.documentdate,
				servicelinetext: oHeaderData.servicelinetext
			};
			this.oDataModel.update("/Products", oSEHeaderData, {
				success: function (oData) {
					MessageToast.show("Updated successfully");
					//	this._oAppViewModel.setProperty("/mode", "DISPLAY");
				}.bind(this),
				error: function (error) {
					MessageBox.error(JSON.stringify(error));
				}
			});
		},
		onOpenViewDialog: function () {
			if (!this._oDialogCRUD) {
				this._oDialogCRUD = sap.ui.xmlfragment("com.rm.test.demo.view.DialogCRUD", this);
				this.getView().addDependent(this._oDialogCRUD);
				// forward compact/cozy style into Dialog
				//this._oDialogCRUD.addStyleClass(this.getOwnerComponent().getContentDensityClass());
			}
			this._oDialogCRUD.open();
		},
		onCloseViewDialog: function () {
			this._oDialogCRUD.close();

		},
		onCreate: function() {
			var oModel = this.getOwnerComponent().getModel();
			var oEntry = {};
			oEntry.ProductID = sap.ui.getCore().byId("__inputCRUD0").getValue(); //control with Fragment
			oEntry.ProductName = sap.ui.getCore().byId("__inputCRUD1").getValue();
			oEntry.SupplierID = sap.ui.getCore().byId("__inputCRUD2").getValue();
			oEntry.CategoryID = sap.ui.getCore().byId("__inputCRUD3").getValue();
			oEntry.QuantityPerUnit = sap.ui.getCore().byId("__inputCRUD4").getValue();
			oEntry.UnitPrice = sap.ui.getCore().byId("__inputCRUD5").getValue();
			oEntry.UnitsInStock = sap.ui.getCore().byId("__inputCRUD6").getValue();

			oModel.create("/Products", oEntry, {
				success: function() {
					sap.m.MessageBox.show("Created successfully!", {
						icon: sap.m.MessageBox.Icon.SUCCESS,
						title: "Information!"
					});
					oModel.refresh(true);
				},
				error: function() {
					sap.m.MessageBox.show("Error. Failed to create the Product! Please try again later,", {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Info!"
					});
				}
			});
			this._oDialogCRUD.close();
			oModel.refresh(true);
		},
		onPress : function(){
			this.getRouter().navTo("listRoute");
		}

	});

});