sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/UIComponent",
	"sap/m/MessageBox",
	"sap/ui/model/json/JSONModel"
], function (Controller, UIComponent,MessageBox,JSONModel) {
	"use strict";

	return Controller.extend("com.rm.test.demo.controller.Listreport", {
		onInit: function () {
        var oViewModel = new JSONModel({
				busy : true,
				delay : 0,
				layout : "OneColumn",
				previousLayout : "",
				actionButtonsInfo : {
					midColumn : {
						fullScreen : false
					}
				}
			});
			this.setModel(oViewModel, "appView");
		},
		/*handleSelectChange: function (oEvent) {
			var mode = oEvent.getParameter("selectedItem").getKey();
			this.byId("ProductList").setMode(mode);
		},*/
		getRouter: function () {
			return UIComponent.getRouterFor(this);
		},
		onBConfirmationPress : function(oEvent){
			// set the layout property of FCL control to show two columns
		
		var oBindingContext = oEvent.getParameter("listItem").getBindingContext();
		this.getRouter().navTo("shuntingRoute", {
					CategoryID: oBindingContext.getProperty('CategoryID')
					
				});
			
			
		},
		getModel: function (sName) {
			return this.getView().getModel(sName);
		},
		setModel: function (oModel, sName) {
			return this.getView().setModel(oModel, sName);
		}
	});
});