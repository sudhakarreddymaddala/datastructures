sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/UIComponent"
], function (Controller, UIComponent) {
	"use strict";

	return Controller.extend("com.rm.test.demo.controller.Shunting", {
		onInit: function () {
		var route = UIComponent.getRouterFor(this).getRoute("shuntingRoute");
                 route.attachMatched(this.initController, this);
			
		},
		initController: function(oEvent){
			  var sCategoryID = oEvent.getParameter("arguments").CategoryID;
                 var sPath = "/Categories(" + sCategoryID+ ")";
                 this.getView().bindElement(sPath);
		},
		getRouter: function () {
			return UIComponent.getRouterFor(this);
		},
			onBackPress: function () {
			this.getRouter().navTo("listRoute", {});
		}
	});
});