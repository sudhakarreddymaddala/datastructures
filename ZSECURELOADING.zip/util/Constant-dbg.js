jQuery.sap.declare("com.westernacher.yl.secureloading.util.Constant");
com.westernacher.yl.secureloading.util.Constant = {
	path: {
		servicePath: "/sap/opu/odata/sap/ZYL_LOAD_SECURITY_SRV/",
		yardSHPAth: "/YardNoSHSet",
		taskQueryPath: "/YardTaskSet",
		taskByManualPath: "/YardTaskNoSHSet",
		taskBindPath: "/YardTaskSet(guid'{$}')/YardTaskItemSet",
		resourceCheckPath: "/HandlingResUsrAsgnmntSet",
		measurementsArrayPath: "/YardTuMeasurementSet?$filter=YardTaskKey%20eq%20guid%27{$}%27%20and%20YardTaskItemKey%20eq%20guid%27{$$}%27&$format=json",
		measurementPath: "/YardTuMeasurementSet(guid'{$}')",
		tuPath: "YardTaskItemSet(guid'{$}')",
		sealsArrayPath: "/YardTuSealNumSet?$filter=YardTaskItemKey%20eq%20guid%27{$}%27&$format=json",
		sealPath: "/YardTuSealNumSet(guid'{$}')",
		taskByKeyPath: "/YardTaskSet(guid'{$}')",
		checksPath: "YardTaskSet(guid'{$}')/YardTaskQuestionsSet",
		checkPath: "/YardTaskQuestionsSet(guid'{$}')",
		tuSearchPath: "/ActiveYardTuNoSHSet?$filter=YardNo eq '{$}'",
		textSet: "/YardTaskTCSet?$filter=HostKey eq guid'{$}'&$expand=YardTaskTCTextHNDLSet/YardTaskTCTextContent",
		exceptionSHPath: "/ExceptionCodeSHSet?$filter=YardNo eq '{$}'",
		confirmActionName: "ConfirmYardTask",
		setExceptionActionName: "SetExceptionCode",
		attachmentsPath: "/YardTaskATFDocumentSet?$filter=ParentKey eq guid'{$}'",
		attachmentMediaPath: "/sap/opu/odata/sap/ZYL_LOAD_SECURITY_SRV/YardTaskATFDocumentSet(guid'{$}')/$value",
		deleteAttachmentActionName: "/YardTaskATFDocumentSet(guid'{$}')/$value",
		attachmentsTaskPath: "/sap/opu/odata/sap/ZYL_LOAD_SECURITY_SRV/YardTaskSet(guid'{$}')/YardTaskATFDocumentSet",
		startTaskActionName: "StartYardTask",
		rejectTaskActionName: "RejectYardTask",
		sapUserPath: "/GetSAPUser",
		handlingResourceSHSet: "/HandlingResourceSHSet?$filter=YardNo eq '{$}'"
	},
	timeOut: 60
};