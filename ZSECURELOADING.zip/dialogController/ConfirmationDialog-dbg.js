jQuery.sap.declare("com.westernacher.yl.secureloading.dialogController.ConfirmationDialog");

com.westernacher.yl.secureloading.dialogController.ConfirmationDialog = {
	_myDialogNameSpace: "com.westernacher.yl.secureloading",
	_myDialogThis: undefined,
	_myDialog: undefined,
	_myDialogFragmentId: "",
	_myDialogParent: "",
	
	
	openConfirmationDialog: function(oThis, sParent) {
		this._myDialogThis = oThis;
		this._myDialogFragmentId = "idDConfirmation" + oThis.getView().getId();
		this._myDialogParent = sParent;
		this._myDialogParameter = {
		
		};

		//if (!this._myDialog) {
			this._myDialog = sap.ui.xmlfragment(this._myDialogFragmentId,
				this._myDialogNameSpace + ".fragment.ConfirmationDialog",
				this
			);
			this._myDialogThis.getView().addDependent(this._myDialog);
		//}

		//sap.ui.getCore().byId(this._myDialogFragmentId + "--idDConfirmation").setTitle(sTitle);
	
		this._myDialog.open();
	},

	onConfirmationDialogOKPress: function() {
		this._myDialogThis._onConfirmationDialogOK();
		
		this._myDialog.close();
		this._myDialog.destroy();
	},

	onBConfirmationDialogCancelPress: function() {
		this._myDialog.close();
		this._myDialog.destroy();
	}
};