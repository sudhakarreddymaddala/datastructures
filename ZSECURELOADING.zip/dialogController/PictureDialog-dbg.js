jQuery.sap.declare("com.westernacher.yl.secureloading.dialogController.PictureDialog");

com.westernacher.yl.secureloading.dialogController.PictureDialog = {
	_myDialogNameSpace: "com.westernacher.yl.secureloading",
	_myDialogThis: undefined,
	_myDialog: undefined,
	_myDialogFragmentId: "",
	_myDialogParent: "",
	
	
	openPictureDialog: function(oThis, sParent, oImage, sTitle, bDeleteVisble) {
		this._myDialogThis = oThis;
		this._myDialogFragmentId = "idDPicture" + oThis.getView().getId();
		this._myDialogParent = sParent;
		this._myDialogParameter = {
			oImage: oImage,
			sTitle: sTitle, 
			bDeleteVisble: bDeleteVisble
		};

		//if (!this._myDialog) {
			this._myDialog = sap.ui.xmlfragment(this._myDialogFragmentId,
				this._myDialogNameSpace + ".fragment.PictureDialog",
				this
			);
			this._myDialogThis.getView().addDependent(this._myDialog);
		//}

		sap.ui.getCore().byId(this._myDialogFragmentId + "--idDPicture").setTitle(sTitle);
		sap.ui.getCore().byId(this._myDialogFragmentId + "--idIPicture").setSrc(this._myDialogParameter.oImage.getSrc());
		sap.ui.getCore().byId(this._myDialogFragmentId + "--idBPictureDialogDelete").setVisible(this._myDialogParameter.bDeleteVisble);

		this._myDialog.open();
	},

	onBPictureOKPress: function() {
		this._myDialog.close();
		this._myDialog.destroy();
	},

	onBPictureDialogDeletePress: function() {
		this._myDialogThis.onPictureDelete(this._myDialogParameter.oImage);

		this._myDialog.close();
		this._myDialog.destroy();
	}
};