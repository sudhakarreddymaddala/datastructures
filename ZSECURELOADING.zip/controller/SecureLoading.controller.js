sap.ui.define([
	"com/westernacher/yl/secureloading/util/BaseController",
	"sap/m/MessageBox",
	"com/westernacher/yl/secureloading/util/Formatter",
	"com/westernacher/yl/secureloading/util/Picture",
	"sap/ui/core/Fragment"
], function (BaseController, MessageBox, Formatter, Picture, Fragment) {
	"use strict";

	return com.westernacher.yl.secureloading.util.BaseController.extend("com.westernacher.yl.secureloading.controller.SecureLoading", {

		_oPictures: [],
		_oSignatures: [],
		_oSignatureC: [],
		_oSignatureD: [],

		onInit: function () {
			this._wizard = this.getView().byId("idWSecureLoadingWizard");
			this._oBusyDialog = this.getView().byId("idBDBusyDialog");

			this.getRouter().attachRoutePatternMatched(this.onRouteMatched, this);
		},

		onRouteMatched: function (oEvent) {
			var sName = oEvent.getParameter("name");

			if (sName !== "secureloading") {
				return;
			}

			if (!BaseController._AppStart) {
				this.getRouter().navTo("tasklist", {});

				return;
			}

			this._oPictures = [];
			this._oSignatures = [];

			var oParameter = oEvent.getParameter("arguments");

			this._YardTaskKey = oParameter.Key;

			var sObjectPath = this.getView().getModel().createKey("YardTaskSet", {
				Key: oParameter.Key
			});

			this.sObjectPath = sObjectPath;

			this.setWizard();

			this._bindView("/" + sObjectPath);
		},

		_bindView: function (sObjectPath) {
			this.getView().bindElement({
				path: sObjectPath,
				events: {
					//change: this._onBindingChange.bind(this),
					dataRequested: function () {
						//oViewModel.setProperty("/busy", true);
					},
					dataReceived: function () {
						//oViewModel.setProperty("/busy", false);
					}
				}
			});
		},

		setWizard: function () {
			var oModel = this.getView().getModel();
			oModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);

			this.bWizardStepSealShow = oModel.getProperty("/" + this.sObjectPath + "/SealNumberCheck");

			//only for test
			//this.bWizardStepSealShow = true;

			var oWSPictures = this.getView().byId("idWSPictures");
			var oWSSeal = this.getView().byId("idWSSeal");
			var oWSSurvey = this.getView().byId("idWSSurvey");
			var oWSSignature = this.getView().byId("idWSSignature");

			var oWSecureLoadingWizard = this.getView().byId("idWSecureLoadingWizard");
			oWSecureLoadingWizard.removeAllSteps();

			oWSecureLoadingWizard.addStep(oWSPictures);
			this.sLastWizardStep = "Info";

			if (this.bWizardStepSealShow) {
				oWSecureLoadingWizard.addStep(oWSSeal);
				this.sLastWizardStep = "Seal";
			}

			oWSecureLoadingWizard.addStep(oWSSurvey);
			this.sLastWizardStep = "Survey";
			oWSecureLoadingWizard.addStep(oWSSignature);
			this.sLastWizardStep = "Signature";
		},

		onBPicturePress: function () {
			this.takeAPicture(this);
			// this._wizard.validateStep(this.getView().byId("idWSPictures"));
		},

		onBCancel: function () {
			var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;

			var that = this;

			MessageBox.confirm(
				this.getI18nText("Message_ApproveCancelOfLoading"), {
					styleClass: bCompact ? "sapUiSizeCompact" : "",
					onClose: function (oAction) {
						if (oAction !== "CANCEL") {
							var oCurrentItemData = that.getView().getBindingContext().getObject();
							that._YardTaskCancel(that, oCurrentItemData);

							that.clearWizard();
						}
					}
				}
			);
		},

		clearWizard: function () {
			var oModel = this.getView().getModel();
			oModel.resetChanges();

			var oPanel = this.getView().byId("idPPictures");
			oPanel.removeAllContent();

			var oSignatureC = this.getView().byId("idISignatureChecker");
			oSignatureC.setSrc("");

			var oSignatureD = this.getView().byId("idISignatureDriver");
			oSignatureD.setSrc("");

			this._wizard.invalidateStep(this.getView().byId("idWSPictures"));

			this.discardProgress();

			this.getRouter().navTo("tasklist", {});
		},

		discardProgress: function () {
			this._wizard.discardProgress(this.getView().byId("idWSSignature"));
			this._wizard.discardProgress(this.getView().byId("idWSSurvey"));
			this._wizard.discardProgress(this.getView().byId("idWSPictures"));

			var clearContent = function (content) {
				for (var i = 0; i < content.length; i++) {
					if (content[i].setValue) {
						content[i].setValue("");
					}

					if (content[i].getContent) {
						clearContent(content[i].getContent());
					}
				}
			};

			clearContent(this._wizard.getSteps());
		},

		takeAPicture: function (oThis) {
			if (!navigator.camera) {
				sap.m.MessageToast.show("Camera not supported");
				return;
			}

			navigator.camera.getPicture(
				function (result) {
					oThis.onPictureTaken(result);
				},
				function (error) {
					sap.m.MessageToast.show("Camera cancelled");
				}, {
					quality: 30,
					allowEdit: false,
					correctOrientation: true,
					destinationType: navigator.camera.DestinationType.DATA_URL,
					direction: 0,
					sourceType: navigator.camera.PictureSourceType.CAMERA,
					encodingType: navigator.camera.EncodingType.JPEG,
					targetWidth: 1000,
					targetHeight: 1000
				}
			);
		},

		onPictureTaken: function (pictureData) {
			this.addPicture(pictureData);
		},

		addPicture: function (pictureData, bIsCapturedImage) {
			this._testPictureData = pictureData;
			if (bIsCapturedImage) {
				// In case of captured image, the image type by default is PNG
				pictureData = pictureData.replace("data:image/png;base64,", "");
			} else {
				// the image type by default is JPEG
				pictureData = pictureData.replace("data:image/jpeg;base64,", "");
			}

			var sSrc = "";
			if (bIsCapturedImage) {
				// In case of captured image, image type is added two times, not needed to append image type again
				sSrc = pictureData;
			} else {
				sSrc = "data:image/png;base64," + pictureData;
			}

			var oImage = new sap.m.Image({
				src: sSrc,
				height: "150px",
				width: "200px"
			});

			var that = this;
			oImage.attachPress(function () {
				that.onPicturePress(this);
			});
			oImage.addStyleClass("sapUiTinyMarginEnd");

			var oPanel = this.getView().byId("idPPictures");

			oPanel.addContent(oImage);

			var iContentIndex = oPanel.indexOfContent(oImage);
			var oPicture = {
				// pictureName: Picture.generatePictureName("Picture"),
				pictureName: Picture.generatePictureCustomName(this, "Picture"),
				pictureDescr: Picture.generatePictureDescr("Picture"),
				pictureData: "data:image/png;base64," + pictureData,
				pictureType: "Picture"
			};

			this._oPictures[iContentIndex] = oPicture;

			this.onWSPictures();
		},

		onPicturePress: function (oImage) {
			this.openPictureDialog(this, oImage, "Picture", true);
		},

		onPictureDelete: function (oImage) {
			var iContentIndex = oImage.getParent().indexOfContent(oImage);
			this._oPictures.splice(iContentIndex, 1);

			var oPanel = this.getView().byId("idPPictures");

			oPanel.removeContent(oImage.getId());

			this.onWSPictures();
		},

		onWSPictures: function () {
			var oPanel = this.getView().byId("idPPictures");

			if (oPanel.mAggregations.content.length === 0) {
				this._wizard.invalidateStep(this.getView().byId("idWSPictures"));
			} else {
				this._wizard.validateStep(this.getView().byId("idWSPictures"));
			}

		},

		onWSTUNumberComplete: function () {
			var oITU = this.getView().byId("idITU");
			oITU.setEnabled(false);

			var value = this.getView().byId("idITU").getValue();
			var oBPicture = this.getView().byId("idBPicture");

			if (value.length === 0) {
				this.getView().byId("idITU").setValueState("Error");

				oBPicture.setVisible(false);
			} else {
				this.getView().byId("idITU").setValueState("None");

				oBPicture.setVisible(true);
			}
		},

		onBSignatureClearPress: function () {
			var oSignature = this.getView().byId("idSignature");
			oSignature.clear();
		},

		onWSecureLoadingWizardComplete: function () {
			var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;

			if (this._oSignatureC.length === 0 || this._oSignatureD.length === 0) {
				MessageBox.alert(
					this.getI18nText("Message_SignatureIsMissing"), {
						styleClass: bCompact ? "sapUiSizeCompact" : ""
					}
				);
			} else if (this._oPictures.length === 0) {
				MessageBox.alert(
					this.getI18nText("Message_PictureIsMissing"), {
						styleClass: bCompact ? "sapUiSizeCompact" : ""
					}
				);
			} else {
				this.openConfirmationDialog(this);

				// MessageBox.confirm(
				// 	this.getI18nText("Message_ApproveFinishOfLoading"), {
				// 		styleClass: bCompact ? "sapUiSizeCompact" : "",
				// 		onClose: function (oAction) {
				// 			if (oAction !== "CANCEL") {
				// 				that.sendPictureSignature();

				// 				//that.getView().byId("idOSStatus").setText("Loaded");

				// 				that.clearWizard();
				// 			}
				// 		}
				// 	}
				// );

			}
		},

		_onConfirmationDialogOK: function () {
			this.sendPictureSignature();
		},

		sendPictureSignature: function () {
			this.onBPictureByAjaxPress();
			this.onBSignatureByAjaxPress();

			this.onBConfirmPress();
		},

		onBSignaturePress: function () {
			this.openSignatureDialog(this, "Signature");
		},

		//auto opend signature dialog
		onWSSignatureActivate: function () {
			this._SignatureActivate = true;

			this.onBSignatureCheckerPress();
		},

		onBPictureByAjaxPress: function () {
			var sPictureName;
			var iPictureNumber;

			if (this._oPictures.length !== 0) {
				var i;

				for (i = 0; i < this._oPictures.length; i++) {
					//adding picture number to picture file name
					sPictureName = this._oPictures[i].pictureName.replace(".png", "");
					iPictureNumber = i + 1;
					sPictureName = sPictureName + iPictureNumber.toString() + ".png";
					this._oPictures[i].pictureName = sPictureName;

					Picture.sendByAjaxBase64(this, this._oPictures[i]);
				}
			}
		},

		onBSignatureByAjaxPress: function () {
			if (this._oSignatureC.length !== 0) {
				Picture.sendByAjaxBase64(this, this._oSignatureC[0]);
			}

			if (this._oSignatureD.length !== 0) {
				Picture.sendByAjaxBase64(this, this._oSignatureD[0]);
			}
		},

		onBTestReadPress: function () {
			Picture.readAttachments(this);

		},

		onFUChange: function () {
			Picture.sendByFileUploader(this);
		},

		onBTestConfirmPress: function () {
			this.onBConfirmPress();
		},

		onBConfirmPress: function () {
			this._oBusyDialog.open();

			this.oCurrentItemData = this.getView().getBindingContext().getObject();

			var ofunctionParams = {
				YardNo: this.oCurrentItemData.YardNo,
				YardTaskNo: this.oCurrentItemData.YardTaskNo
			};

			var that = this;

			var oModel = this.getView().getModel();

			oModel.callFunction("/StartAndConfirm", {
				method: "POST",
				urlParameters: ofunctionParams,
				success: function (oData, oResponse) {
					sap.m.MessageToast.show(that.getI18nText("Message_YardOperationSendSuccess"));

					that._oBusyDialog.close();

					that.clearWizard();
				},
				error: function (oError) {

				}
			});
		},

		//open signature dialog
		onBSignatureCheckerPress: function () {
			var oObject = this.getView().byId("idISignatureChecker");
			this.openSignatureDialog(this, "C", oObject, this.getI18nText("CheckerSignature_Title"));
		},

		onBSignatureDriverPress: function () {
			var oObject = this.getView().byId("idISignatureDriver");
			this.openSignatureDialog(this, "D", oObject, this.getI18nText("DriverSignature_Title"));
		},

		//signature drawing is finished
		onSignatureShow: function (oObject, sSignatureType, sSignatureTitle, oSignatureData, isSignature) {
			var oSignature = oObject;

			if (isSignature) {
				oSignature.setSrc(oSignatureData);

				switch (sSignatureType) {
				case "C":
					this._oSignatureC = [];

					break;
				case "D":
					this._oSignatureD = [];

					break;
				}

				var oSignatureFile = {
					//pictureName: Picture.generatePictureName("Signature"),
					pictureName: Picture.generatePictureCustomName(this, "Signature" + sSignatureType),
					pictureDescr: sSignatureTitle,
					pictureData: oSignatureData,
					pictureType: "Signature"
				};

				switch (sSignatureType) {
				case "C":
					this._oSignatureC.push(oSignatureFile);

					break;
				case "D":
					this._oSignatureD.push(oSignatureFile);

					break;
				}

				if (this._oSignatureC.length !== 0 && this._oSignatureD.length !== 0) {
					this._wizard.validateStep(this.getView().byId("idWSSignature"));
				}

			} else {
				oSignature.setSrc("");

				this._oSignatures = [];

				this._wizard.invalidateStep(this.getView().byId("idWSSignature"));
			}

			if (this._SignatureActivate) {
				this._SignatureActivate = false;

				this.onBSignatureDriverPress();
			}
		},

		onWSSurveyActivate: function () {
			this.checkAnswerCompleted();
		},

		//change on survey slider yes/no
		onSliderChange: function (oEvent) {
			var sPath = oEvent.getSource().getBindingContext().getPath();
			var sValue = oEvent.getParameter("value");
			var oModel = this.getView().getModel();

			switch (sValue) {
			case 0:
				oModel.setProperty(sPath + "/Answer", "0");

				break;
			case 2:
				oModel.setProperty(sPath + "/Answer", "1");

				break;
			default:
				oModel.setProperty(sPath + "/Answer", "");
			}

			this.checkAnswerCompleted();
		},

		//checking if all answer are completed
		checkAnswerCompleted: function () {
			var oTable = this.getView().byId("idTSurvey");
			var oBinding = oTable.getBinding("items");
			var oContexts = oBinding.getContexts();
			var oObject;
			var i;
			var bCombleted = true;

			if (oContexts.length === 0) {
				this._wizard.validateStep(this.getView().byId("idWSSurvey"));

				this._wizard.nextStep();
				return;
			} else {
				this._wizard.invalidateStep(this.getView().byId("idWSSurvey"));
			}

			for (i = 0; i < oContexts.length; i++) {
				oObject = oContexts[i].getObject();

				if (oObject.Answer === "") {
					bCombleted = false;
					break;
				}
			}

			if (bCombleted) {
				this._wizard.validateStep(this.getView().byId("idWSSurvey"));
			} else {
				this._wizard.invalidateStep(this.getView().byId("idWSSurvey"));
			}
		},

		onWSSurveyComplete: function () {
			var oModel = this.getView().getModel();

			if (!oModel.hasPendingChanges()) {
				return;
			}

			var that = this;

			var fnSuccessHandler = function (oData, oResponse) {
				that._oBusyDialog.close();

				// var oCheckRespose = that._checkResponse(oData);

				// if (oCheckRespose.error) {
				// 	//sap.m.MessageBox.error(that.getI18nText("SurveySendMessage_Error") + oCheckRespose.errorMessage);
				// } else {
				// 	sap.m.MessageToast.show(that.getI18nText("SurveySendMessage_Success"));
				// }
			};

			var fnErrorHandler = function (err) {
				that._oBusyDialog.close();
			};

			this._oBusyDialog.open();

			oModel.submitChanges({
				success: fnSuccessHandler,
				error: fnErrorHandler
			});
		},

		onSealCompleteCheck: function () {
			var validated = true;

			if (this.bInfoTrailerLicencePlateCheck) {
				if (this.getView().byId("idISeal").getValue().length === 0) {
					validated = false;
				}
			}

			if (validated) {
				this._wizard.validateStep(this.getView().byId("idWSSeal"));
			} else {
				this._wizard.invalidateStep(this.getView().byId("idWSSeal"));
			}
		},

		onWSSealComplete: function () {
			var oModel = this.getView().getModel();

			if (!oModel.hasPendingChanges()) {
				return;
			}

			var that = this;

			var fnSuccessHandler = function (oData, oResponse) {
				that._oBusyDialog.close();
			};

			var fnErrorHandler = function (err) {
				that._oBusyDialog.close();
			};

			this._oBusyDialog.open();

			oModel.submitChanges({
				success: fnSuccessHandler,
				error: fnErrorHandler
			});
		},

		onBTestPress: function () {
			var oModel = this.getView().getModel();

			oModel.setProperty("/" + this.sObjectPath + "/SealNumber", "AAA123");
		},
		onSnapshot: function (oEvent) {
			// The image is inside oEvent, on the image parameter,
			// let's grab it.
			var oModel = this.getView().getModel("json");
			var aPhotos = oModel.getProperty("/photos");
			aPhotos = aPhotos && aPhotos.length > 0 ? aPhotos : [];
			this._currentImage = oEvent.getParameter("image");
			aPhotos.push({
				src: oEvent.getParameter("image")
			});
			oModel.setProperty("/photos", aPhotos);
			this.addPicture(oEvent.getParameter("image"), true /* TRUE - Capture Image*/ );

			oModel.refresh(true);
		},
		onCapture: function () {
			var oCamera = sap.ui.getCore().byId("idCamera");
			oCamera._onUserClickedVideo();
			this._wizard.validateStep(this.getView().byId("idWSPictures"));
			this.onConfirmImage();

		},
		onConfirmImage: function () {
			this.oWarningMessageDialog = new sap.m.Dialog({
				type: sap.m.DialogType.Message,
				contentWidth: "500px",
				contentHeight: "500px",
				title: "confirm to capture image",
				state: "Warning",
				content: new sap.m.Image({
					src: this._currentImage,
					width: "400px",
					height: "400px"
				}),
				beginButton: new sap.m.Button({
					type: sap.m.ButtonType.Emphasized,
					text: "confirm",
					press: function () {
						this.oWarningMessageDialog.close();
						this.oWarningMessageDialog.destroy();
					}.bind(this)
				}),
				endButton: new sap.m.Button({
					type: sap.m.ButtonType.Emphasized,
					text: "Cancel",
					press: function () {
						this.oWarningMessageDialog.close();
						this.oWarningMessageDialog.destroy();
						// Cancel photo from list
						var aPhotos = this.getView().getModel("json").getProperty("/photos");
						var iCurrentPicIndx = aPhotos.findIndex(function (photos) {
							return photos.src === this._currentImage;
						}.bind(this));
						aPhotos.splice(iCurrentPicIndx, 1);
						this.getView().getModel("json").setProperty("/photos", aPhotos);
						this.getView().getModel("json").refresh(true);

					}.bind(this)
				})
			});

			this.oWarningMessageDialog.open();
		},

		onRetake: function () {
			var oCamera = this.getView().byId("idCamera");
			oCamera.rerender();
		},
		onStop: function () {
			// var oCamera = this.getView().byId("idCamera");
			// oCamera.stopCamera();
			this.oDialog.close();
			this.oDialog.destroy();
		},
		capturePic: function () {
			Fragment.load({
				name: "com.westernacher.yl.secureloading.view.Camera",
				controller: this
			}).then(function (oDialog) {
				this.oDialog = oDialog;
				oDialog.open();

			}.bind(this));
		}

	});

});