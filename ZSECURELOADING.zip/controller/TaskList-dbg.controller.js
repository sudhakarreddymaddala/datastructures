sap.ui.define([
	"com/westernacher/yl/secureloading/util/BaseController",
	"sap/m/MessageBox",
	"com/westernacher/yl/secureloading/util/Formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (BaseController, MessageBox, Formatter, Filter, FilterOperator) {
	"use strict";

	return com.westernacher.yl.secureloading.util.BaseController.extend("com.westernacher.yl.secureloading.controller.TaskList", {
		onInit: function () {
			this._oBusyDialog = this.getView().byId("idBDBusyDialog");

			this.getRouter().attachRoutePatternMatched(this.onRouteMatched, this);
		},

		onRouteMatched: function (oEvent) {
			BaseController._AppStart = true;

			var sName = oEvent.getParameter("name");

			if (sName !== "tasklist") {
				return;
			}

			// var oFilter = [];
			// var list = this.getView().byId("idLTask");
			// var oBinding = list.getBinding("items");
			// oBinding.filter(oFilter);

			// this.onSBDoorSelectionChange();

			var oList = this.getView().byId("idLTask");
			oList.removeSelections(true);

			var that = this;

			this.fGoAutoRefresh = setInterval(function () {
				// clearInterval(this.fGoAutoRefresh);
				that._autoRefresh();
			}, 0);
		},

		onExit: function () {
			clearInterval(this.fGoAutoRefresh);
		},

		_autoRefresh: function () {
			var oList = this.getView().byId("idLTask");
			var iCountBefore = oList.getBinding("items").getLength();
			var that = this;

			oList.getBinding("items").attachEventOnce("dataReceived",
				function (oEvent) {
					var iCountAfter = oList.getBinding("items").getLength();

					//sap.m.MessageToast.show(iCountBefore + "     " + iCountAfter);

					// if (iCountBefore < iCountAfter) {
					// 	that._playSound();
					// }
				});

			this.onBRefreshPress();
		},

		onBRefreshPress: function () {
			var list = this.getView().byId("idLTask");
			var oBinding = list.getBinding("items");
			oBinding.refresh();
		},

		onBStartLoadingPress: function () {
			var oList = this.getView().byId("idLTask");
			var oSelectedItem = oList.getSelectedItem();

			if (!oSelectedItem) {
				sap.m.MessageToast.show(this.getI18nText("Message_SelectTask"));

				return;
			}

			var aContext = oSelectedItem.getBindingContext();

			// this.getRouter().navTo("secureloading", {
			// 	Yardid: aContext.getObject().Yardid,
			// 	Yardtaskid: aContext.getObject().Yardtaskid
			// }, false);

			// this.getRouter().navTo("secureloading", {
			// 	Key: aContext.getObject().Key
			// }, false);

			var oObject = aContext.getObject();
			var sPath = aContext.getPath();

			this._YardTaskStart(oObject, sPath);
		},

		onBBarCodePress: function () {
			this.handleBarcodeScanner();
		},

		handleBarcodeScanner: function (evt) {
			var that = this;

			cordova.plugins.barcodeScanner.scan(
				function (result) {
					that.filterList(result.text);
				},
				function (error) {
					sap.m.MessageToast.show("Sorry, Camera Error!!" + error);
				}

			);
		},

		filterList: function (sTaskId) {
			var oFilter;

			if (sTaskId !== "") {
				oFilter = [new Filter("TUId", FilterOperator.EQ, sTaskId)];
			} else {
				oFilter = [];
			}

			var list = this.getView().byId("idLTask");
			var oBinding = list.getBinding("items");
			oBinding.filter(oFilter);

			var firstItem = this.getView().byId("idLTask").getItems()[0];
			this.getView().byId("idLTask").setSelectedItem(firstItem, true);

			this.onBStartLoadingPress();
		},

		onSelectionChange: function () {
			clearInterval(this.fGoAutoRefresh);

			var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;

			var that = this;

			MessageBox.confirm(
				this.getI18nText("Message_AreYouSureToOpenTask"), {
					styleClass: bCompact ? "sapUiSizeCompact" : "",
					onClose: function (oAction) {
						if (oAction === "OK") {
							that.onBStartLoadingPress();
						} else {
							var oList = that.getView().byId("idLTask");
							oList.removeSelections(true);
						}
					}
				}
			);
		},

		_YardTaskStart: function (oObject, sPath) {
			if (oObject.LifecycleStatus !== "03") {

				var ofunctionParams = {
					YardTaskNo: oObject.YardTaskNo,
					YardNo: oObject.YardNo
				};

				var oModel = this.getView().getModel();
				var that = this;

				this._oBusyDialog.open();

				oModel.callFunction("/StartYardTask", {
					method: "POST",
					urlParameters: ofunctionParams,
					success: function (oData, oResponse) {
						oModel.setProperty(sPath + "/LifecycleStatus", "03");
						oModel.setProperty(sPath + "/StatusDescr", that.getI18nText("YPStatusText_Started"));

						that._oBusyDialog.close();
						sap.m.MessageToast.show(that.getI18nText("StartMessage_Success"));

						that._NavigateToCheck(oObject);
					},
					error: function (oError) {
						that._oBusyDialog.close();
						//sap.m.MessageBox.error(that.getI18nText("StartMessage_Error"));
					}
				});
			} else {
				this._NavigateToCheck(oObject);
			}
		},

		_NavigateToCheck: function (oObject) {
			this.getRouter().navTo("secureloading", {
				Key: oObject.Key
			}, false);
		},

		onSBDoorSelectionChange: function () {
			var sKey = this.getView().byId("idSBDoorSelection").getSelectedKey();
			var oList = this.getView().byId("idLTask");
			var oBinding = oList.getBinding("items");

			var oFilters = [];
			var oFilter;

			if (sKey === "") {
				sKey = "08";
			}

			if (sKey === "08") {
				oFilter = new Filter("StorBinsrc", sap.ui.model.FilterOperator.StartsWith, "08");
				oFilters.push(oFilter);
				oFilter = new Filter("StorBinsrc", sap.ui.model.FilterOperator.StartsWith, "06");
				oFilters.push(oFilter);
			} else {
				oFilter = new Filter("StorBinsrc", sap.ui.model.FilterOperator.StartsWith, sKey);
				oFilters.push(oFilter);
			}

			oBinding.filter(oFilters);
		},

		onBTestPress: function () {
			this.openSignatureDialog(this, "Signature");
		}

	});

});