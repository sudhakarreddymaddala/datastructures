sap.ui.define([
	"com/westernacher/yl/trailercheck/demo/util/BaseController",
	"sap/m/MessageBox",
	"com/westernacher/yl/trailercheck/demo/util/Formatter",
	"sap/ui/core/Fragment"
], function (BaseController, MessageBox, Formatter, Fragment) {
	"use strict";

	return BaseController.extend("com.westernacher.yl.trailercheck.demo.controller.Check", {
		_oCheckFront: [],
		_oCheckBack: [],
		_oCheckLeft: [],
		_oCheckRight: [],
		_oSignatureC: [],
		_oSignatureD: [],

		_bDamageFront: false,
		_bDamageBack: false,
		_bDamageLeft: false,
		_bDamageRight: false,

		sServicePictureUploadPath: "/sap/opu/odata/sap/ZYL_TRAILER_CHECKER_SRV",

		onInit: function () {
			this._wizard = this.getView().byId("idWTrialerCheckWizard");
			this._oBusyDialog = this.getView().byId("idBDBusyDialog");

			this.getRouter().attachRoutePatternMatched(this.onRouteMatched, this);

			this._TruckFront = undefined;
		},

		onRouteMatched: function (oEvent) {
			var sName = oEvent.getParameter("name");

			if (sName !== "check") {
				return;
			}

			this.oCheckFront = [];
			this._oCheckBack = [];
			this._oCheckLeft = [];
			this._oCheckRight = [];
			this._oSignatureC = [];
			this._oSignatureD = [];

			this._bDamageFront = false;
			this._bDamageBack = false;
			this._bDamageLeft = false;
			this._bDamageRight = false;

			this.oAppPictureModel = this.getView().getModel("AppPictureModel");
			this.oAppPictureModel.setData([]);

			var oParameter = oEvent.getParameter("arguments");
			this._YardTaskKey = oParameter.Key;

			if (!BaseController._AppStart) {
				this.getRouter().navTo("tasklist", {});

				return;
			}

			this.clearWizard(false);

			this._ExecuteAutoConfirmation = true;

			var oModel = this.getView().getModel();
			oModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);

			var sObjectPath = this.getView().getModel().createKey("YardTaskSet", {
				Key: oParameter.Key
			});

			this.bShowOfficePopup = oModel.getProperty("/" + sObjectPath + "/ShowOfficePopup");

			this.bPoolReadOnlly = oModel.getProperty("/" + sObjectPath + "/PoolReadOnlly");
			this.getView().byId("idITrailerPoolText").setEditable(!this.bPoolReadOnlly);
			//this.getView().byId("idLTrailerPoolText").setRequired(!this.bPoolReadOnlly);

			this.bInfoCheck = oModel.getProperty("/" + sObjectPath + "/InfoCheck");
			this.bCheckPictures = oModel.getProperty("/" + sObjectPath + "/CheckPictures");
			this.bCheckChecks = oModel.getProperty("/" + sObjectPath + "/CheckChecks");
			this.bCheckSignature = oModel.getProperty("/" + sObjectPath + "/CheckSignature");

			// this.bInfoCheck = true;
			// this.bCheckPictures = false;
			// this.bCheckChecks = true;
			// this.bCheckSignature = true;

			// idWSInfo
			// idWSCheck
			// idWSSurvey
			// idWSSignature

			var oWSInfo = this.getView().byId("idWSInfo");
			var oWSCheck = this.getView().byId("idWSCheck");
			var oWSSurvey = this.getView().byId("idWSSurvey");
			var oWSSignature = this.getView().byId("idWSSignature");

			var oWTrialerCheckWizard = this.getView().byId("idWTrialerCheckWizard");
			oWTrialerCheckWizard.removeAllSteps();

			oWTrialerCheckWizard.addStep(oWSInfo);
			this.sLastWizardStep = "Info";

			if (this.bCheckPictures) {
				oWTrialerCheckWizard.addStep(oWSCheck);
				this.sLastWizardStep = "Check";
			}
			if (this.bCheckChecks) {
				oWTrialerCheckWizard.addStep(oWSSurvey);
				this.sLastWizardStep = "Survey";
			}
			if (this.bCheckSignature) {
				oWTrialerCheckWizard.addStep(oWSSignature);
				this.sLastWizardStep = "Signature";
			}

			this._bindView("/" + sObjectPath);

			this.onInfoCompleteCheck();
		},

		_bindView: function (sObjectPath) {
			this.getView().bindElement({
				path: sObjectPath,
				events: {
					//change: this._onBindingChange.bind(this),
					dataRequested: function () {

					},
					dataReceived: function () {

					}
				}
			});

		},

		// onWSSurveyActivate: function () {
		// 	var oBindingContext = this.getView().getBindingContext();
		// 	var oObject = oBindingContext.getObject();

		// 	var oTable = this.getView().byId("idTSurvey");
		// 	var oFilters = [];
		// 	var oFilter = null;

		// 	oFilter = new sap.ui.model.Filter("Yardid", sap.ui.model.FilterOperator.EQ, oObject.Yardid);
		// 	oFilters.push(oFilter);
		// 	oFilter = new sap.ui.model.Filter("Yardtaskid", sap.ui.model.FilterOperator.EQ, oObject.Yardtaskid);
		// 	oFilters.push(oFilter);

		// 	var that = this;

		// 	var oBinding = oTable.getBinding("items");
		// 	oBinding.attachEventOnce("dataReceived",
		// 		function (oEvent) {
		// 			var _oTable = that.getView().byId("idTSurvey");

		// 			if (oEvent.getParameter("data").results.length === 0) {
		// 				_oTable.setVisible(false);
		// 				that._wizard.validateStep(that.getView().byId("idWSSurvey"));
		// 				that.getView().byId("idTNoSurvey").setVisible(true);
		// 			} else {
		// 				_oTable.setVisible(true);
		// 				that.getView().byId("idTNoSurvey").setVisible(false);

		// 				that.checkAnswerCompleted();
		// 			}
		// 		});

		// 	oBinding.filter(oFilters);
		// },

		onTUHelpRequest: function () {
			var selectedField = this.getView().byId("idWSTUNumber");

			this.openTUSelectionDialog(this, selectedField);
		},

		onBPicturePress: function () {
			this.takeAPicture(this);
		},

		onBCancel: function () {
			var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;

			var that = this;

			MessageBox.confirm(
				this.getI18nText("Message_ApproveCancelOfChecking"), {
					styleClass: bCompact ? "sapUiSizeCompact" : "",
					onClose: function (oAction) {
						if (oAction !== "CANCEL") {
							that.clearWizard(true);
						}
					}
				}
			);
		},

		onBCancelPress: function () {
			var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;

			var that = this;

			MessageBox.confirm(
				this.getI18nText("Message_ApproveCancelOfChecking"), {
					styleClass: bCompact ? "sapUiSizeCompact" : "",
					onClose: function (oAction) {
						if (oAction !== "CANCEL") {
							var oCurrentItemData = that.getView().getBindingContext().getObject();
							that._YardTaskCancel(that, oCurrentItemData);

							that.clearWizard(true);
						}
					}
				}
			);
		},

		signatureOff: function () {
			this.getView().byId("idTruckFront").signatureOff();
			this.getView().byId("idTruckLeft").signatureOff();
			this.getView().byId("idTruckRight").signatureOff();
			this.getView().byId("idTruckBack").signatureOff();
		},

		clearWizard: function (bGoToTaskList) {
			var oModel = this.getView().getModel();
			oModel.resetChanges();

			var oWizardStepEnabledModel = this.getView().getModel("WizardStepEnabledModel");
			oWizardStepEnabledModel.setProperty("/bSurveyEnabled", true);
			oWizardStepEnabledModel.setProperty("/bPictureEnabled", true);

			// var oPanel = this.getView().byId("idPPictures");
			// oPanel.removeAllContent();

			this.oCheckFront = [];
			this._oCheckBack = [];
			this._oCheckLeft = [];
			this._oCheckRight = [];
			this._oSignatureC = [];
			this._oSignatureD = [];

			this._bDamageFront = false;
			this._bDamageBack = false;
			this._bDamageLeft = false;
			this._bDamageRight = false;

			this.oAppPictureModel = this.getView().getModel("AppPictureModel");
			this.oAppPictureModel.setData([]);

			var oSignature = this.getView().byId("idISignatureChecker");
			oSignature.setSrc("");
			oSignature = this.getView().byId("idISignatureDriver");
			oSignature.setSrc("");

			//Info
			this.getView().byId("idILicencePlate").setEnabled(true);
			this.getView().byId("idIParking").setEnabled(true);
			this.getView().byId("idITrailerPoolText").setEnabled(true);

			var oImageModel = this.getView().getModel("imageModel");
			var sImagePath = oImageModel.getProperty("/path");

			var oCheck = this.getView().byId("idIFront");
			oCheck.setSrc(sImagePath + "/image/TruckFront.png");
			oCheck = this.getView().byId("idIBack");
			oCheck.setSrc(sImagePath + "/image/TruckBack.png");
			oCheck = this.getView().byId("idILeft");
			oCheck.setSrc(sImagePath + "/image/TruckLeft.png");
			oCheck = this.getView().byId("idIRight");
			oCheck.setSrc(sImagePath + "/image/TruckRight.png");

			this.getView().byId("idTSurvey").setVisible(true);
			this.getView().byId("idTNoSurvey").setVisible(false);

			this._wizard.invalidateStep(this.getView().byId("idWSSignature"));
			this._wizard.invalidateStep(this.getView().byId("idWSSurvey"));

			this.discardProgress();

			if (bGoToTaskList) {
				this.getRouter().navTo("tasklist", {});
			}
		},

		discardProgress: function () {
			this._wizard.discardProgress(this.getView().byId("idWSSignature"));
			this._wizard.discardProgress(this.getView().byId("idWSSurvey"));
			//this._wizard.discardProgress(this.getView().byId("idWSPicture"));
			this._wizard.discardProgress(this.getView().byId("idWSCheck"));
			this._wizard.discardProgress(this.getView().byId("idWSInfo"));

			// var clearContent = function(content) {
			// 	for (var i = 0; i < content.length; i++) {
			// 		if (content[i].setValue) {
			// 			content[i].setValue("");
			// 		}

			// 		if (content[i].getContent) {
			// 			clearContent(content[i].getContent());
			// 		}
			// 	}
			// };

			// clearContent(this._wizard.getSteps());
		},

		onBTruckFrontPicturePress: function () {
			this._sCheckType = "Front";
			// this.takeAPicture(this);
			this.capturePic();
		},

		onBTruckBackPicturePress: function () {
			this._sCheckType = "Back";
			// this.takeAPicture(this);
			this.capturePic();
		},

		onBTruckLeftPicturePress: function () {
			this._sCheckType = "Left";
			// this.takeAPicture(this);
			this.capturePic();
		},

		onBTruckRightPicturePress: function () {
			this._sCheckType = "Right";
			// this.takeAPicture(this);
			this.capturePic();
		},

		takeAPicture: function (that) {
			if (!navigator.camera) {
				sap.m.MessageToast.show("Camera not supported");
				return;
			}

			navigator.camera.getPicture(
				function (result) {
					that.onPictureTaken(result);
				},
				function (error) {
					sap.m.MessageToast.show("Camera cancelled");
				}, {
					quality: 30,
					allowEdit: false,
					correctOrientation: true,
					destinationType: navigator.camera.DestinationType.DATA_URL,
					direction: 0,
					sourceType: navigator.camera.PictureSourceType.CAMERA,
					encodingType: navigator.camera.EncodingType.JPEG,
					targetWidth: 1000,
					targetHeight: 1000
				}
			);
		},

		onPictureTaken: function (pictureData) {
			this.addPicture(pictureData);
		},

		addPicture: function (pictureData, bIsCapturedImage) {
			//pictureData = pictureData.replace("data:image/jpg;base64,", "");
			var sPrePictureName;
			this._testPictureData = pictureData;
			if (bIsCapturedImage) {
				// In case of captured image, the image type by default is PNG
				pictureData = pictureData.replace("data:image/png;base64,", "");
			} else {
				// the image type by default is JPEG
				pictureData = pictureData.replace("data:image/jpeg;base64,", "");
			}

			var sSrc = "";
			if (bIsCapturedImage) {
				// In case of captured image, image type is added two times, not needed to append image type again
				sSrc = pictureData;
			} else {
				sSrc = "data:image/png;base64," + pictureData;
			}

			switch (this._sCheckType) {
			case "Front":
				sPrePictureName = "YLTrailerCheck_PF_";

				break;
			case "Back":
				sPrePictureName = "YLTrailerCheck_PB_";

				break;
			case "Left":
				sPrePictureName = "YLTrailerCheck_PL_";

				break;
			case "Right":
				sPrePictureName = "YLTrailerCheck_PR_";

				break;
			}

			var oPicture = {
				Status: "pending",
				Text: this._generatePictureName(sPrePictureName),
				pictureName: this._generatePictureName(sPrePictureName),
				pictureDescr: "",
				pictureData: "data:image/png;base64," + pictureData,
				pictureType: "Picture",
				pictureSide: this._sCheckType,
				enabled: true
			};

			var oPictures = this.oAppPictureModel.getData();
			oPictures.push(oPicture);
			this.oAppPictureModel.setData(oPictures);

			this._PictureRequired();
		},

		onBTruckPictureDeletePress: function (oEvent) {
			var sPath = oEvent.getSource().getParent().getBindingContext("AppPictureModel").getPath();

			var oPicture = this.oAppPictureModel.getProperty(sPath);

			if (oPicture.Status === "FormBackend") {
				this._deleteImage(this, oPicture);
			}

			var iLength = sPath.length;
			var iIndex = sPath.slice(iLength - 1);
			var oData = this.oAppPictureModel.getData();
			oData.splice(iIndex, 1);
			this.oAppPictureModel.setData(oData);

			this._PictureRequired();
		},

		onPicturePress: function (oEvent) {
			var oImage = oEvent.getSource();
			this.openPictureDialog(this, oImage, "Picture", true);
		},

		onPictureDelete: function (oImage) {
			var oPanel = this.getView().byId("idPPictures");
			oPanel.removeContent(oImage.getId());

			var iContentIndex = oImage.getParent().indexOfContent(oImage);
			this._oPictures.splice(iContentIndex, 1);
		},

		onWSTUNumberComplete: function () {
			var oITU = this.getView().byId("idITU");
			oITU.setEnabled(false);

			var value = this.getView().byId("idITU").getValue();
			var oBPicture = this.getView().byId("idBPicture");

			if (value.length === 0) {
				this.getView().byId("idITU").setValueState("Error");

				oBPicture.setVisible(false);
			} else {
				this.getView().byId("idITU").setValueState("None");

				oBPicture.setVisible(true);
			}
		},

		onWTrialerCheckWizardComplete: function () {
			var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;

			var that = this;

			MessageBox.confirm(
				this.getI18nText("Message_ApproveFinishOfLoading"), {
					styleClass: bCompact ? "sapUiSizeCompact" : "",
					onClose: function (oAction) {
						if (oAction !== "CANCEL") {

							switch (that.sLastWizardStep) {
							case "Info":
								that.onWSInfoComplete();

								break;
							case "Check":
								that.onWSChecAndPictureComplete();

								break;
							case "Survey":
								that.onWSSurveyComplete();

								break;
							case "Signature":
								that.onWSSignatureComplete();

								break;
							}
						}
					}
				}
			);
		},

		onBConfirmPress: function () {
			this.oCurrentItemData = this.getView().getBindingContext().getObject();

			var ofunctionParams = {
				YardTaskNo: this.oCurrentItemData.YardTaskNo,
				YardNo: this.oCurrentItemData.YardNo
			};

			var oModel = this.getView().getModel();
			var that = this;

			this._oBusyDialog.open();

			oModel.callFunction("/ConfirmYardTask", {
				method: "POST",
				urlParameters: ofunctionParams,
				success: function (oData, oResponse) {
					that._oBusyDialog.close();

					var bCompact = !!that.getView().$().closest(".sapUiSizeCompact").length;

					if (that.bShowOfficePopup) {

						sap.m.MessageBox.information(
							//that.getI18nText("ConfirmationMessage_Success") + ". " +
							that.getI18nText("Message_OfficePopup"), {
								styleClass: bCompact ? "sapUiSizeCompact" : "",
								onClose: function (oAction) {
									if (oAction === "OK") {
										that.clearWizard(true);
									}
								}
							}
						);
					} else {
						sap.m.MessageBox.information(that.getI18nText("ConfirmationMessage_Success"), {
							styleClass: bCompact ? "sapUiSizeCompact" : "",
							onClose: function (oAction) {
								if (oAction === "OK") {
									that.clearWizard(true);
								}
							}
						});
					}

				},
				error: function (oError) {
					that._oBusyDialog.close();
				}
			});

		},

		//open draw window
		onBTruckFrontDrawPress: function () {
			this._sCheckType = "Front";
			var oObject = this.getView().byId("idIFront");
			this.openCheckDialog(this, oObject, this.getI18nText("CheckFront"), "Front");
		},

		onBTruckLeftDrawPress: function () {
			this._sCheckType = "Left";
			var oObject = this.getView().byId("idILeft");
			this.openCheckDialog(this, oObject, this.getI18nText("CheckLeft"), "Left");
		},

		onBTruckRightDrawPress: function () {
			this._sCheckType = "Right";
			var oObject = this.getView().byId("idIRight");
			this.openCheckDialog(this, oObject, this.getI18nText("CheckRight"), "Right");
		},

		onBTruckBackDrawPress: function () {
			this._sCheckType = "Back";
			var oObject = this.getView().byId("idIBack");
			this.openCheckDialog(this, oObject, this.getI18nText("CheckBack"), "Back");
		},

		//drawing is finished
		onCheckShow: function (oObject, sCheckType, sCheckTitle, oCheckData, isCheck) {
			oObject.setSrc(oCheckData);

			var sPrePictureName;
			var isDamage = false;

			switch (sCheckType) {
			case "Front":
				if (this._bDamageFront) {
					isDamage = true;
				} else {
					this._bDamageFront = isCheck;
					isDamage = isCheck;
				}

				this._oCheckFront = [];
				sPrePictureName = "YLTrailerCheck_CF_";

				break;
			case "Back":
				if (this._bDamageBack) {
					isDamage = true;
				} else {
					this._bDamageBack = isCheck;
					isDamage = isCheck;
				}

				this._oCheckBack = [];
				sPrePictureName = "YLTrailerCheck_CB_";

				break;
			case "Left":
				if (this._bDamageLeft) {
					isDamage = true;
				} else {
					this._bDamageLeft = isCheck;
					isDamage = isCheck;
				}

				this._oCheckLeft = [];
				sPrePictureName = "YLTrailerCheck_CL_";

				break;
			case "Right":
				if (this._bDamageRight) {
					isDamage = true;
				} else {
					this._bDamageRight = isCheck;
					isDamage = isCheck;
				}

				this._oCheckRight = [];
				sPrePictureName = "YLTrailerCheck_CR_";

				break;
			}

			if (isDamage) {
				var oCheckFile = {
					pictureName: this._generatePictureName(sPrePictureName),
					pictureDescr: sCheckTitle,
					pictureData: oCheckData,
					pictureType: "Check " + sCheckType,
					isDamage: isDamage
				};
				switch (sCheckType) {
				case "Front":
					this._oCheckFront.push(oCheckFile);

					break;
				case "Back":
					this._oCheckBack.push(oCheckFile);

					break;
				case "Left":
					this._oCheckLeft.push(oCheckFile);

					break;
				case "Right":
					this._oCheckRight.push(oCheckFile);

					break;
				}

			} else {
				this._deleteOldCheckPictures(Formatter.formatCheckType(sCheckType));
			}

			this._PictureRequired();
		},

		onCheckClear: function (sCheckType) {
			switch (sCheckType) {
			case "Front":
				this._bDamageFront = false;

				break;
			case "Back":
				this._bDamageBack = false;

				break;
			case "Left":
				this._bDamageLeft = false;

				break;
			case "Right":
				this._bDamageRight = false;

				break;
			}

			this._PictureRequired();
		},

		_PictureRequired: function () {
			var bValidation = true;

			if (this._bDamageFront && this.getView().byId("idVBFront").getItems().length === 0) {
				this.getView().byId("idBTruckFrontPicture").setType("Reject");
				this.getView().byId("idMSFront").setVisible(true);

				bValidation = false;
			} else {
				this.getView().byId("idBTruckFrontPicture").setType("Default");
				this.getView().byId("idMSFront").setVisible(false);
			}

			if (this._bDamageBack && this.getView().byId("idVBBack").getItems().length === 0) {
				this.getView().byId("idBTruckBackPicture").setType("Reject");
				this.getView().byId("idMSBack").setVisible(true);

				bValidation = false;
			} else {
				this.getView().byId("idBTruckBackPicture").setType("Default");
				this.getView().byId("idMSBack").setVisible(false);
			}

			if (this._bDamageLeft && this.getView().byId("idVBLeft").getItems().length === 0) {
				this.getView().byId("idBTruckLeftPicture").setType("Reject");
				this.getView().byId("idMSLeft").setVisible(true);

				bValidation = false;
			} else {
				this.getView().byId("idBTruckLeftPicture").setType("Default");
				this.getView().byId("idMSLeft").setVisible(false);
			}

			if (this._bDamageRight && this.getView().byId("idVBRight").getItems().length === 0) {
				this.getView().byId("idBTruckRightPicture").setType("Reject");
				this.getView().byId("idMSRight").setVisible(true);

				bValidation = false;
			} else {
				this.getView().byId("idBTruckRightPicture").setType("Default");
				this.getView().byId("idMSRight").setVisible(false);
			}

			if (bValidation) {
				this._wizard.validateStep(this.getView().byId("idWSCheck"));
			} else {
				this._wizard.invalidateStep(this.getView().byId("idWSCheck"));
			}
		},

		//open signature dialog
		onBSignatureCheckerPress: function () {
			var oObject = this.getView().byId("idISignatureChecker");
			this.openSignatureDialog(this, "C", oObject, this.getI18nText("CheckerSignature_Title"));
		},

		onBSignatureDriverPress: function () {
			var oObject = this.getView().byId("idISignatureDriver");
			this.openSignatureDialog(this, "D", oObject, this.getI18nText("DriverSignature_Title"));
		},

		//signature drawing is finished
		onSignatureShow: function (oObject, sSignatureType, sSignatureTitle, oSignatureData, isSignature) {
			var oSignature = oObject;
			var sPrePictureName;

			if (isSignature) {
				oSignature.setSrc(oSignatureData);

				switch (sSignatureType) {
				case "C":
					this._oSignatureC = [];
					sPrePictureName = "YLTrailerCheck_SC_";

					break;
				case "D":
					this._oSignatureD = [];
					sPrePictureName = "YLTrailerCheck_SD_";

					break;
				}

				var oSignatureFile = {
					pictureName: this._generatePictureName(sPrePictureName),
					pictureDescr: sSignatureTitle,
					pictureData: oSignatureData,
					pictureType: "Signature"
				};

				switch (sSignatureType) {
				case "C":
					this._oSignatureC.push(oSignatureFile);

					break;
				case "D":
					this._oSignatureD.push(oSignatureFile);

					break;
				}

				if (this._oSignatureC.length !== 0 && this._oSignatureD.length !== 0) {
					this._wizard.validateStep(this.getView().byId("idWSSignature"));
				}

			} else {
				oSignature.setSrc("");

				this._oSignatures = [];

				this._wizard.invalidateStep(this.getView().byId("idWSSignature"));
			}

			if (this._SignatureActivate) {
				this._SignatureActivate = false;

				this.onBSignatureDriverPress();
			}
		},

		//auto opend signature dialog
		onWSSignatureActivate: function () {
			this._SignatureActivate = true;

			this.onBSignatureCheckerPress();
		},

		//change on survey slider yes/no
		onSliderChange: function (oEvent) {
			var sPath = oEvent.getSource().getBindingContext().getPath();
			var sValue = oEvent.getParameter("value");
			var oModel = this.getView().getModel();

			switch (sValue) {
			case 0:
				oModel.setProperty(sPath + "/Answer", "0");

				break;
			case 2:
				oModel.setProperty(sPath + "/Answer", "1");

				break;
			default:
				oModel.setProperty(sPath + "/Answer", "");
			}

			this.checkAnswerCompleted();
		},

		onWSSurveyActivate: function () {
			this.checkAnswerCompleted();
		},

		//checking if all answer are completed
		checkAnswerCompleted: function () {
			var oTable = this.getView().byId("idTSurvey");
			var oBinding = oTable.getBinding("items");
			var oContexts = oBinding.getContexts();
			var oObject;
			var i;
			var bCombleted = true;

			if (oContexts.length === 0) {
				this._wizard.validateStep(this.getView().byId("idWSSurvey"));
				return;
			} else {
				this._wizard.invalidateStep(this.getView().byId("idWSSurvey"));
			}

			for (i = 0; i < oContexts.length; i++) {
				oObject = oContexts[i].getObject();

				if (oObject.Answer === "") {
					bCombleted = false;
					break;
				}
			}

			if (bCombleted) {
				this._wizard.validateStep(this.getView().byId("idWSSurvey"));
			} else {
				this._wizard.invalidateStep(this.getView().byId("idWSSurvey"));
			}
		},

		onBSurveySendTestPress: function () {
			this.onWSSurveyComplete();
		},

		onWSSurveyComplete: function () {
			// var oTable = this.getView().byId("idTSurvey");
			// var oBinding = oTable.getBinding("items");
			// var oContexts = oBinding.getContexts();

			var oModel = this.getView().getModel();

			if (!oModel.hasPendingChanges()) {
				if (this._ExecuteAutoConfirmation && this.sLastWizardStep === "Survey") {
					this.onBConfirmPress();
				}

				return;
			}

			var that = this;

			var fnSuccessHandler = function (oData, oResponse) {
				that._oBusyDialog.close();

				sap.m.MessageToast.show(that.getI18nText("SurveySendMessage_Success"));

				if (that._ExecuteAutoConfirmation && that.sLastWizardStep === "Survey") {
					that.onBConfirmPress();
				} else {
					if (that.bCheckSignature) {
						that.onWSSignatureActivate();
					}
				}
			};

			var fnErrorHandler = function (err) {
				that._oBusyDialog.close();

				//sap.m.MessageBox.error(that.getI18nText("ConfirmationMessage_Error"));
			};

			this._oBusyDialog.open();

			oModel.submitChanges({
				success: fnSuccessHandler,
				error: fnErrorHandler
			});
		},

		onWSInfoComplete: function () {
			this._onBInfoSend();
		},

		_onBInfoSend: function () {
			var oModel = this.getView().getModel();
			var that = this;

			if (!oModel.hasPendingChanges()) {
				if (this._ExecuteAutoConfirmation && this.sLastWizardStep === "Info") {
					this.onBConfirmPress();
				}

				return;
			}

			var fnSuccessHandler = function (oData, oResponce) {
				that._oBusyDialog.close();

				sap.m.MessageToast.show(that.getI18nText("SendInfoMessage_Success"));

				that.getView().byId("idILicencePlate").setEnabled(false);
				that.getView().byId("idIParking").setEnabled(false);
				that.getView().byId("idITrailerPoolText").setEnabled(false);

				if (that._ExecuteAutoConfirmation && that.sLastWizardStep === "Info") {
					that.onBConfirmPress();
				}
			};

			var fnErrorHandler = function (err) {
				that._oBusyDialog.close();

				//sap.m.MessageBox.error(that.getI18nText("SendInfoMessage_Error"));
			};

			this._oBusyDialog.open();

			oModel.submitChanges({
				success: fnSuccessHandler,
				error: fnErrorHandler
			});
		},

		onWSChecAndPictureComplete: function () {
			this.onWSCheckComplete();
			this.onWSPicturesComplete();

			if (this._ExecuteAutoConfirmation && this.sLastWizardStep === "Check") {
				this.onBConfirmPress();
			}
		},

		onWSCheckComplete: function () {
			if (this._oCheckFront.length === 0 && this._oCheckBack.length === 0 && this._oCheckLeft.length === 0 && this._oCheckRight.length ===
				0) {
				return;
			}

			this._bShowErrorMessage = true;

			this._oBusyDialog.open();

			var that = this;

			var fGo = setInterval(function () {
				clearInterval(fGo);

				that._sendCheck();
			}, 1);
		},

		_sendCheck: function () {
			this._SendCounterRequest = 0;
			this._SendCounterResponse = 0;

			if (this._oCheckFront.length !== 0) {
				this._SendCounterRequest = this._SendCounterRequest + 1;
			}

			if (this._oCheckBack.length !== 0) {
				this._SendCounterRequest = this._SendCounterRequest + 1;
			}

			if (this._oCheckLeft.length !== 0) {
				this._SendCounterRequest = this._SendCounterRequest + 1;
			}

			if (this._oCheckRight.length !== 0) {
				this._SendCounterRequest = this._SendCounterRequest + 1;
			}

			if (this._oCheckFront.length !== 0) {
				this._deleteOldCheckPictures("CF");
				this._sendByAjaxBase64(this._oCheckFront[0], "Front");
			}

			if (this._oCheckBack.length !== 0) {
				this._deleteOldCheckPictures("CB");
				this._sendByAjaxBase64(this._oCheckBack[0], "Back");
			}

			if (this._oCheckLeft.length !== 0) {
				this._deleteOldCheckPictures("CL");
				this._sendByAjaxBase64(this._oCheckLeft[0], "Left");
			}

			if (this._oCheckRight.length !== 0) {
				this._deleteOldCheckPictures("CR");
				this._sendByAjaxBase64(this._oCheckRight[0], "Right");
			}
		},

		_deleteOldCheckPictures: function (sType) {
			var oObject;
			var sObjectType;

			for (var i = 0; i < this._existingPictures.length; i++) {
				oObject = this._existingPictures[i];
				sObjectType = oObject.Name.replace("YLTrailerCheck_", "");
				sObjectType = sObjectType.substring(0, 2);

				if (sObjectType === sType) {
					this._deleteImage(this, oObject);
				}
			}
		},

		onWSPicturesComplete: function () {
			var oPictures = this.oAppPictureModel.getData();

			if (oPictures.length === 0) {
				return;
			}

			this._bShowErrorMessage = true;

			var that = this;

			var fGo = setInterval(function () {
				clearInterval(fGo);

				that._sendPictures();
			}, 1);

		},

		_sendPictures: function () {
			var oPictures = this.oAppPictureModel.getData();

			this._SendCounterRequest = oPictures.length;
			this._SendCounterResponse = 0;

			if (oPictures.length !== 0) {
				var i;

				for (i = 0; i < oPictures.length; i++) {
					if (oPictures[i].Status !== "FormBackend") {
						this._oBusyDialog.open();

						this._sendByAjaxBase64(oPictures[i], "Picture");
					}
				}
			}
		},

		onWSSignatureComplete: function () {
			if (this._oSignatureC.length === 0 && this._oSignatureD.length === 0) {
				if (this._ExecuteAutoConfirmation && this.sLastWizardStep === "Signature") {
					this.onBConfirmPress();
				}

				return;
			}

			this._bShowErrorMessage = true;

			this._oBusyDialog.open();

			var that = this;

			var fGo = setInterval(function () {
				clearInterval(fGo);

				that._sendSignature();
			}, 1);
		},

		_sendSignature: function () {
			this._SendCounterRequest = 2;
			this._SendCounterResponse = 0;

			if (this._oSignatureC.length !== 0) {
				this._sendByAjaxBase64(this._oSignatureC[0], "Signature");
			}

			if (this._oSignatureD.length !== 0) {
				this._sendByAjaxBase64(this._oSignatureD[0], "Signature");
			}

			if (this._ExecuteAutoConfirmation && this.sLastWizardStep === "Signature") {
				this.onBConfirmPress();
			}
		},

		_sendByAjaxBase64: function (oData, sType) {
			var that = this;

			var oView = that.getView();
			var oModel = oView.getModel(); //"DocumentService"
			var sToken = oModel.getSecurityToken();
			var oObject = oView.getBindingContext().getObject();
			var sTaskKey = oObject.Key;

			var sSlug;
			sSlug = window.btoa(oData.pictureName) + "," + window.btoa(oData.pictureDescr) + "," + window.btoa("image/png");

			var fnSuccessHandler = function (oData, oResponse) {
				that._SendCounterResponse = that._SendCounterResponse + 1;

				if (that._SendCounterRequest === that._SendCounterResponse) {
					that._oBusyDialog.close();

					if (sType === "Check") {
						sap.m.MessageToast.show(that.getI18nText("SendCheckMessage_Success"));
					}

					if (sType === "Picture") {
						sap.m.MessageToast.show(that.getI18nText("SendPictureMessage_Success"));
					}

					if (sType === "Signature") {
						sap.m.MessageToast.show(that.getI18nText("SendSignatureMessage_Success"));
					}
				}
			};

			var fnErrorHandler = function (oError) {
				that._oBusyDialog.close();

				that._bShowErrorMessage = false;

				if (that._bShowErrorMessage) {
					if (sType === "Check") {
						sap.m.MessageToast.show(that.getI18nText("SendCheckMessage_Error"));
					}

					if (sType === "Picture") {
						sap.m.MessageToast.show(that.getI18nText("SendPictureMessage_Error"));
					}

					if (sType === "Signature") {
						sap.m.MessageToast.show(that.getI18nText("SendSignatureMessage_Error"));
					}

					that._bShowErrorMessage = false;
				}
			};

			jQuery.ajax({
				url: this.sServicePictureUploadPath + "/YardTaskSet(guid'{$}')/YardTaskATFDocumentSet".replace("{$}", sTaskKey),
				async: false,
				cache: false,
				data: oData.pictureData,
				processData: false,
				type: "POST",
				beforeSend: function (xhr) {
					xhr.setRequestHeader("X-CSRF-Token", sToken);
					xhr.setRequestHeader("Content-Type", "image/png");
					xhr.setRequestHeader("slug", sSlug);
				},
				success: fnSuccessHandler,
				error: fnErrorHandler
			});
		},

		onParkingHelpRequest: function () {
			var sYardId = this._getModelData("AppConfigModel", "/sYardId");

			this.openParkingSelectionDialog(this, sYardId);
		},

		selectedParking: function (sParkingNo) {
			this.getView().byId("idIParking").setValue(sParkingNo);

			this.getView().byId("idIParking").setValueState("None");

			this.onInfoCompleteCheck();
		},

		onTrailerPoolHelpRequest: function () {
			this.openTrailerPoolSelectionDialog(this, "");
		},

		selectedTrailerPool: function (sTrailerPoolFix, sTrailerPoolText) {
			this.getView().byId("idITrailerPoolText").setValue(sTrailerPoolText);
			this.getView().byId("idITrailerPoolFix").setValue(sTrailerPoolFix);

			this.getView().byId("idITrailerPoolText").setValueState("None");

			// this.getView().byId("idITrailerSubPoolText").setValue("");
			// this.getView().byId("idITrailerSubPoolFix").setValue("00");

			// this.getView().byId("idITrailerSubPoolText").setValueState("None");

			this.onInfoCompleteCheck();
		},

		// onTrailerSubPoolHelpRequest: function () {
		// 	this.openTrailerSubPoolSelectionDialog(this, "", this.getView().byId("idITrailerPoolFix").getValue());
		// },

		// selectedTrailerSubPool: function (sTrailerSubPoolFix, sTrailerSubPoolText) {
		// 	this.getView().byId("idITrailerSubPoolText").setValue(sTrailerSubPoolText);
		// 	this.getView().byId("idITrailerSubPoolFix").setValue(sTrailerSubPoolFix);

		// 	this.getView().byId("idITrailerSubPoolText").setValueState("None");

		// 	this.onInfoCompleteCheck();
		// },

		onInfoCompleteCheck: function () {
			var validated = true;

			// if (this.getView().byId("idILicencePlate").getValue().length === 0) {
			// 	validated = false;
			// }

			if (this.getView().byId("idIParking").getValue().length === 0) {
				validated = false;
			}

			// if (!this.bPoolReadOnlly) {
			// 	if (this.getView().byId("idITrailerPoolText").getValue().length === 0) {
			// 		validated = false;
			// 	}
			// }

			if (validated) {
				this._wizard.validateStep(this.getView().byId("idWSInfo"));
			} else {
				this._wizard.invalidateStep(this.getView().byId("idWSInfo"));
			}
		},

		_imageListLoaded: function (oData) {
			this._existingPictures = oData.results;
			var oObject;
			var oImage;
			var sType;
			var bShowImage = false;
			var oPicture;
			var sImagePathTemplate = "/sap/opu/odata/sap/ZYL_TRAILER_CHECKER_SRV/YardTaskATFDocumentSet(guid'{$}')/$value";
			var sImagePath;
			var oPictures = this.oAppPictureModel.getData();
			var bAddToPictureModel = false;
			var sCheckType;

			for (var i = 0; i < oData.results.length; i++) {
				oObject = oData.results[i];

				sType = oObject.Name.replace("YLTrailerCheck_", "");
				sType = sType.substring(0, 2);

				bShowImage = false;
				bAddToPictureModel = false;

				switch (sType) {
				case "CF":
					bShowImage = true;
					oImage = this.getView().byId("idIFront");
					this._bDamageFront = true;

					break;
				case "CL":
					bShowImage = true;
					oImage = this.getView().byId("idILeft");
					this._bDamageLeft = true;

					break;
				case "CR":
					bShowImage = true;
					oImage = this.getView().byId("idIRight");
					this._bDamageRight = true;

					break;
				case "CB":
					bShowImage = true;
					oImage = this.getView().byId("idIBack");
					this._bDamageBack = true;

					break;

				}

				if (bShowImage) {
					sImagePath = sImagePathTemplate.replace("{$}", oObject.Key);

					oImage.setSrc(sImagePath);
				}

				switch (sType) {
				case "PF":
					bAddToPictureModel = true;
					sCheckType = "Front";

					break;
				case "PL":
					bAddToPictureModel = true;
					sCheckType = "Left";

					break;
				case "PR":
					bAddToPictureModel = true;
					sCheckType = "Right";
					this._bDamageRight = true;

					break;
				case "PB":
					bAddToPictureModel = true;
					sCheckType = "Back";
					this._bDamageBack = true;

					break;
				}

				if (bAddToPictureModel) {
					oPicture = {
						Key: oObject.Key,
						Status: "FormBackend",
						Text: oObject.Name,
						pictureName: oObject.Name,
						pictureDescr: oObject.Description,
						pictureData: sImagePath = sImagePathTemplate.replace("{$}", oObject.Key),
						pictureType: "Picture",
						pictureSide: sCheckType,
						enabled: false
					};

					oPictures.push(oPicture);
				}

			}

			this.oAppPictureModel.setData(oPictures);

			this._PictureRequired();
		},

		onBTestPress: function () {
			this._readImages(this, this._YardTaskKey);
		},

		onWSChecAndPictureActivate: function () {
			this._readImages(this, this._YardTaskKey);
		},
		onSnapshot: function (oEvent) {
			// The image is inside oEvent, on the image parameter,
			// let's grab it.
			var oModel = this.getView().getModel("AppPictureModel");
			var aPhotos = oModel.getProperty("/pictureData");
			aPhotos = aPhotos && aPhotos.length > 0 ? aPhotos : [];
			this._currentImage = oEvent.getParameter("image");
			aPhotos.push({
				src: oEvent.getParameter("image")
			});
			oModel.setProperty("/pictureData", aPhotos);
			this.addPicture(oEvent.getParameter("image"), true /* TRUE - Capture Image*/ );

			oModel.refresh(true);
		},
		onCapture: function () {
			var oCamera = sap.ui.getCore().byId("idCamera");
			oCamera._onUserClickedVideo();
			this._wizard.validateStep(this.getView().byId("idWSPictures"));
			this.onConfirmImage();
		},
		onConfirmImage: function () {
			this.oWarningMessageDialog = new sap.m.Dialog({
				type: sap.m.DialogType.Message,
				contentWidth: "500px",
				contentHeight: "500px",
				title: "confirm to capture image",
				state: "Warning",
				content: new sap.m.Image({
					src: this._currentImage,
					width: "400px",
					height: "400px"
				}),
				beginButton: new sap.m.Button({
					type: sap.m.ButtonType.Emphasized,
					text: "confirm",
					press: function () {
						this.oWarningMessageDialog.close();
						this.oWarningMessageDialog.destroy();
					}.bind(this)
				}),
				endButton: new sap.m.Button({
					type: sap.m.ButtonType.Emphasized,
					text: "Cancel",
					press: function () {
						this.oWarningMessageDialog.close();
						this.oWarningMessageDialog.destroy();
						// Cancel photo from list
						var oPictures = this.oAppPictureModel.getData();
						var iCurrentPicIndx = oPictures.findIndex(function (photos) {
							return photos.pictureData === this._currentImage;
						}.bind(this));
						oPictures.splice(iCurrentPicIndx, 1);
						this.oAppPictureModel.setData(oPictures);
						this.oAppPictureModel.refresh(true);

					}.bind(this)
				})
			});

			this.oWarningMessageDialog.open();
		},
		onRetake: function () {
			var oCamera = this.getView().byId("idCamera");
			oCamera.rerender();
		},
		onStop: function () {
			// var oCamera = this.getView().byId("idCamera");
			// oCamera.stopCamera();
			this.oDialog.close();
			this.oDialog.destroy();
		},
		capturePic: function () {
			Fragment.load({
				name: "com.westernacher.yl.trailercheck.demo.view.Camera",
				controller: this
			}).then(function (oDialog) {
				this.oDialog = oDialog;
				oDialog.open();

			}.bind(this));
		}

	});

});