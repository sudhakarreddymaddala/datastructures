jQuery.sap.declare("com.westernacher.yl.trailercheck.demo.dialogController.YardDialog");

com.westernacher.yl.trailercheck.demo.dialogController.YardDialog = {
	_myDialogNameSpace: "com.westernacher.yl.trailercheck.demo",
	_myDialogThis: undefined,
	_myDialog: undefined,
	_myDialogFragmentId: "",
	_myDialogParent: "",

	openYardDialog: function(oThis, sParent) {
		this._myDialogThis = oThis;
		this._myDialogFragmentId = "idDYard" + oThis.getView().getId();
		this._myDialogParent = sParent;
		this._myDialogParameter = {};

		//if (!this._myDialog) {
			this._myDialog = sap.ui.xmlfragment(this._myDialogFragmentId,
				this._myDialogNameSpace + ".fragment.YardDialog",
				this
			);
			this._myDialogThis.getView().addDependent(this._myDialog);
		//} 

		//sap.ui.getCore().byId(this._myDialogFragmentId + "--idDYard").setTitle(sTitle);

		this._myDialog.open();
	},

	onYardDialogConfirm: function(oEvent) {
		var sYardNo = "";
		var sYardDescr = "";

		var aContext = oEvent.getParameter("selectedContexts");

		if (aContext.length) {
			sYardNo = aContext.map(function(oContext) {
				return oContext.getObject().Yardid;
			}).join(", ");

			sYardDescr = aContext.map(function(oContext) {
				return oContext.getObject().Lnumt;
			}).join(", ");
		}

		oEvent.getSource().getBinding("items").filter([]);

		this._myDialogThis.selectedYard(sYardNo, sYardDescr);
		
		this._myDialog.destroy();
	},

	onYardDialogSearch: function(oEvent) {
		var sValue = oEvent.getParameter("value");
		var columns = ["Yardid"];
		var oFilter = null;

		//var oFilter = new sap.ui.model.Filter("Name", sap.ui.model.FilterOperator.Contains, sValue);

		if (sValue !== "") {
			oFilter = new sap.ui.model.Filter(columns.map(function(colName) {
				return new sap.ui.model.Filter(colName, sap.ui.model.FilterOperator.Contains, sValue);
			}), false);
		}

		var oBinding = oEvent.getSource().getBinding("items");
		oBinding.filter(oFilter);
	},
	
	onYardDialogCancel: function () {
		this._myDialog.destroy();
	}
};