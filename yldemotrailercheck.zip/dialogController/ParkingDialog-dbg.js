jQuery.sap.declare("com.westernacher.yl.trailercheck.demo.dialogController.ParkingDialog");

com.westernacher.yl.trailercheck.demo.dialogController.ParkingDialog = {
	_myDialogNameSpace: "com.westernacher.yl.trailercheck.demo",
	_myDialogThis: undefined,
	_myDialog: undefined,
	_myDialogFragmentId: "",
	_myDialogParent: "",

	openParkingDialog: function(oThis, sParent, sYardId) {
		this._myDialogThis = oThis;
		this._myDialogFragmentId = "idDParking" + oThis.getView().getId();
		this._myDialogParent = sParent;
		this._myDialogParameter = {
			sYardId: sYardId
		};

		//if (!this._myDialog) {
			this._myDialog = sap.ui.xmlfragment(this._myDialogFragmentId,
				this._myDialogNameSpace + ".fragment.ParkingDialog",
				this
			);
			this._myDialogThis.getView().addDependent(this._myDialog);
		//}

		//sap.ui.getCore().byId(this._myDialogFragmentId + "--idDParking").setTitle(sTitle);

		//var oFilters = this._initialFilterDoor();

		var oTable = sap.ui.getCore().byId(this._myDialogFragmentId + "--idTSDParking");
		// var oBinding = oTable.getBinding("items");
		// oBinding.filter(oFilters);

		this._myDialog.open();

		oTable._resetSelection();
	},

	_initialFilterDoor: function() {
		var oFilters = [];
		var oFilter = null;

		oFilter = new sap.ui.model.Filter("YardNo", sap.ui.model.FilterOperator.EQ, this._myDialogParameter.sYardId);
		oFilters.push(oFilter);

		oFilter = new sap.ui.model.Filter("StorBinType", sap.ui.model.FilterOperator.EQ, "DOOR");
		oFilters.push(oFilter);

		oFilter = new sap.ui.model.Filter("Section", sap.ui.model.FilterOperator.EQ, "DOOR");
		oFilters.push(oFilter);

		return oFilters;
	},

	onParkingDialogConfirm: function(oEvent) {
		var sParkingNo = "";
		// var sParkingIsEmpty = "";

		var aContext = oEvent.getParameter("selectedContexts");

		if (aContext.length) {
			sParkingNo = aContext.map(function(oContext) {
				return oContext.getObject().StorageBin;
			}).join(", ");

			// sParkingIsEmpty = aContext.map(function(oContext) {
			// 	return oContext.getObject().isEmpty;
			// }).join(", ");
		}

		oEvent.getSource().getBinding("items").filter([]);

		this._myDialogThis.selectedParking(sParkingNo);
		
		this._myDialog.destroy();
	},

	onParkingDialogSearch: function(oEvent) {
		var sValue = oEvent.getParameter("value");
		// var oFilters = this._initialFilterDoor();
		var oFilters = [];
		var oFilter = null;

		if (sValue !== "") {
			oFilter = new sap.ui.model.Filter("StorageBin", sap.ui.model.FilterOperator.Contains, sValue);
			oFilters.push(oFilter);
		}

		var oBinding = oEvent.getSource().getBinding("items");
		oBinding.filter(oFilters);
	},
	
	onParkingDialogCancel: function () {
		this._myDialog.destroy();
	}
};