jQuery.sap.declare("com.westernacher.yl.trailercheck.demo.dialogController.SignatureDialog");

com.westernacher.yl.trailercheck.demo.dialogController.SignatureDialog = {
	_myDialogNameSpace: "com.westernacher.yl.trailercheck.demo",
	_myDialogThis: undefined,
	_myDialog: undefined,
	_myDialogFragmentId: "",
	_myDialogParent: "",

	openSignatureDialog: function (oThis, sParent, sType, oObject, sTitle) {
		//sType: C - checker, D - driver
		this._myDialogThis = oThis;
		this._myDialogFragmentId = "idDSignature" + oThis.getView().getId();
		this._myDialogParent = sParent;
		this._myDialogParameter = {
			sType: sType,
			oObject: oObject,
			sTitle: sTitle
		};

		if (!this._myDialog) { 
			//  -  Can't be comment, Cuz if this method calls again when the Signature Dialog popup already opened
			// then we will face duplicate id error at second time 
			this._myDialog = sap.ui.xmlfragment(this._myDialogFragmentId,
				this._myDialogNameSpace + ".fragment.SignatureDialog",
				this
			);
			this._myDialogThis.getView().addDependent(this._myDialog);
		}

		sap.ui.getCore().byId(this._myDialogFragmentId + "--idDSignature").setTitle(sTitle);

		this._myDialog.open();
	},

	onBSignatureOKPress: function () {
		var oSignature = sap.ui.getCore().byId(this._myDialogFragmentId + "--idSignature");

		if (this._myDialog) {
			this._myDialog.close();
			this._myDialog.destroy();
			this._myDialog = null; // Invalidated the local variable after destroying the element from UI
		}

		this._myDialogThis.onSignatureShow(this._myDialogParameter.oObject, this._myDialogParameter.sType, this._myDialogParameter.sTitle,
			oSignature.export(),
			oSignature.isSignature());
	},

	onBSignatureCancelPress: function () {
		if (this._myDialogThis.getOwnerComponent()._KapselMode) {
			this._myDialogThis.lockPortrait(this._thatSignature);
		}

		if (this._myDialog) {
			this._myDialog.close();
			this._myDialog.destroy();
		}
	},

	onBSignatureClearPress: function () {
		var that = this;

		var bCompact = !!this._myDialogThis.getView().$().closest(".sapUiSizeCompact").length;
		sap.m.MessageBox.confirm("Clear signature?", {
			styleClass: bCompact ? "sapUiSizeCompact" : "",
			icon: "",
			onClose: function (oAction) {
				that.onSignatureClear(oAction);
			}
		});
	},

	onSignatureClear: function (oAction) {
		if (oAction === "CANCEL") {
			return;
		}

		var oSignature = sap.ui.getCore().byId(this._myDialogFragmentId + "--idSignature");
		oSignature.clear();
	}
};