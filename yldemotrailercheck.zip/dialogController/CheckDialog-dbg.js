jQuery.sap.declare("com.westernacher.yl.trailercheck.demo.dialogController.CheckDialog");

com.westernacher.yl.trailercheck.demo.dialogController.CheckDialog = {
	_myDialogNameSpace: "com.westernacher.yl.trailercheck.demo",
	_myDialogThis: undefined,
	_myDialog: undefined,
	_myDialogFragmentId: "",
	_myDialogParent: "",

	openCheckDialog: function (oThis, sParent, oObject, sTitle, sType) {
		this._myDialogThis = oThis;
		this._myDialogFragmentId = "idDCheck" + oThis.getView().getId();
		this._myDialogParent = sParent;
		this._myDialogParameter = {
			sType: sType,
			oObject: oObject,
			sTitle: sTitle
		};

		//if (!this._myDialog) {
			this._myDialog = sap.ui.xmlfragment(this._myDialogFragmentId,
				this._myDialogNameSpace + ".fragment.CheckDialog",
				this
			);
			this._myDialogThis.getView().addDependent(this._myDialog);
		//} 

		sap.ui.getCore().byId(this._myDialogFragmentId + "--idDCheck").setTitle(sTitle);

		this._myDialog.open();

		var oCheck = sap.ui.getCore().byId(this._myDialogFragmentId + "--idCheck");
		this._setBackgroundImage(oCheck, this._myDialogParameter.sType);
	},

	onBCheckOKPress: function () {
		var oCheck = sap.ui.getCore().byId(this._myDialogFragmentId + "--idCheck");
		
		this._myDialogThis.onCheckShow(this._myDialogParameter.oObject, this._myDialogParameter.sType, this._myDialogParameter.sTitle, oCheck.export(),
			oCheck.isSignature());

		this._myDialog.close();
		this._myDialog.destroy();
	},

	onBCheckCancelPress: function () {
		this._myDialog.close();
		this._myDialog.destroy();
	},

	onBCheckClearPress: function () {
		this._onCheckClear("OK");

		// var myThis = this;

		// var bCompact = !!this._myDialogThis.getView().$().closest(".sapUiSizeCompact").length;
		// sap.m.MessageBox.confirm("Clear Check?", {
		// 	styleClass: bCompact ? "sapUiSizeCompact" : "",
		// 	icon: "",
		// 	onClose: function(oAction) {
		// 		myThis._onCheckClear(oAction);
		// 	}
		// });
	},

	_onCheckClear: function (oAction) {
		if (oAction === "CANCEL") {
			return;
		}

		var oCheck = sap.ui.getCore().byId(this._myDialogFragmentId + "--idCheck");
		oCheck.clear();

		this._setBackgroundImageClear(oCheck, this._myDialogParameter.sType);

		this._myDialogThis.onCheckClear(this._myDialogParameter.sType);
	},

	_setBackgroundImage: function (oCheck, sType) {
		oCheck.setBackgroud(this._myDialogParameter.oObject.getSrc());
	},

	_setBackgroundImageClear: function (oCheck, sType) {
		var sImagePath = this._myDialogThis.getView().getModel("imageModel").getProperty("/path");

		switch (sType) {
		case "Front":
			oCheck.setBackgroud(sImagePath + "/image/TruckFront.png");

			break;
		case "Back":
			oCheck.setBackgroud(sImagePath + "/image/TruckBack.png");

			break;
		case "Left":
			oCheck.setBackgroud(sImagePath + "/image/TruckLeft.png");

			break;
		case "Right":
			oCheck.setBackgroud(sImagePath + "/image/TruckRight.png");

			break;
		}
	},

	onBPicturePress: function () {
		this._myDialogThis.takeAPicture(this._myDialogThis);
	}
};