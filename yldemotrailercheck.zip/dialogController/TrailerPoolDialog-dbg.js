jQuery.sap.declare("com.westernacher.yl.trailercheck.demo.dialogController.TrailerPoolDialog");

com.westernacher.yl.trailercheck.demo.dialogController.TrailerPoolDialog = {
	_myDialogNameSpace: "com.westernacher.yl.trailercheck.demo",
	_myDialogThis: undefined,
	_myDialog: undefined,
	_myDialogFragmentId: "",
	_myDialogParent: "",

	openTrailerPoolDialog: function (oThis, sParent) {
		this._myDialogThis = oThis;
		this._myDialogFragmentId = "idDTrailerPool" + oThis.getView().getId();
		this._myDialogParent = sParent;
		this._myDialogParameter = {

		};

		//if (!this._myDialog) {
		this._myDialog = sap.ui.xmlfragment(this._myDialogFragmentId,
			this._myDialogNameSpace + ".fragment.TrailerPoolDialog",
			this
		);
		this._myDialogThis.getView().addDependent(this._myDialog);
		//}

		//sap.ui.getCore().byId(this._myDialogFragmentId + "--idDTrailerPool").setTitle(sTitle);

		var oTable = sap.ui.getCore().byId(this._myDialogFragmentId + "--idTSDTrailerPool");
		// var oBinding = oTable.getBinding("items");
		// oBinding.filter(oFilters);

		this._myDialog.open();

		oTable._resetSelection();
	},

	onTrailerPoolDialogConfirm: function (oEvent) {
		var sTrailerPoolFix = "";
		var sTrailerPoolText = "";

		var aContext = oEvent.getParameter("selectedContexts");

		if (aContext.length) {
			sTrailerPoolFix = aContext.map(function (oContext) {
				return oContext.getObject().TrailerPoolFix;
			}).join(", ");

			sTrailerPoolText = aContext.map(function (oContext) {
				return oContext.getObject().TrailerPoolText;
			}).join(", ");
		}

		oEvent.getSource().getBinding("items").filter([]);

		this._myDialogThis.selectedTrailerPool(sTrailerPoolFix, sTrailerPoolText);

		this._myDialog.destroy();
	},

	onTrailerPoolDialogSearch: function (oEvent) {
		var sValue = oEvent.getParameter("value");
		// var oFilters = this._initialFilterDoor();
		var oFilters = [];
		var oFilter = null;

		if (sValue !== "") {
			oFilter = new sap.ui.model.Filter("TrailerPoolText", sap.ui.model.FilterOperator.Contains, sValue);
			oFilters.push(oFilter);
		}

		var oBinding = oEvent.getSource().getBinding("items");
		oBinding.filter(oFilters);
	},

	onTrailerPoolDialogCancel: function () {
		this._myDialog.destroy();
	}
};