jQuery.sap.declare("com.westernacher.yl.trailercheck.demo.dialogController.TrailerSubPoolDialog");

com.westernacher.yl.trailercheck.demo.dialogController.TrailerSubPoolDialog = {
	_myDialogNameSpace: "com.westernacher.yl.trailercheck.demo",
	_myDialogThis: undefined,
	_myDialog: undefined,
	_myDialogFragmentId: "",
	_myDialogParent: "",

	openTrailerSubPoolDialog: function (oThis, sParent, sTrailerPoolFix) {
		this._myDialogThis = oThis;
		this._myDialogFragmentId = "idDTrailerSubPool" + oThis.getView().getId();
		this._myDialogParent = sParent;
		this._myDialogParameter = {
			sTrailerPoolFix: sTrailerPoolFix
		};

		//if (!this._myDialog) {
		this._myDialog = sap.ui.xmlfragment(this._myDialogFragmentId,
			this._myDialogNameSpace + ".fragment.TrailerSubPoolDialog",
			this
		);
		this._myDialogThis.getView().addDependent(this._myDialog);
		//}

		//sap.ui.getCore().byId(this._myDialogFragmentId + "--idDTrailerSubPool").setTitle(sTitle);

		var oTable = sap.ui.getCore().byId(this._myDialogFragmentId + "--idTSDTrailerSubPool");
		// var oBinding = oTable.getBinding("items");
		// oBinding.filter(oFilters);

		this._myDialog.open();

		oTable._resetSelection();

		this.oTrailerPoolFilter = new sap.ui.model.Filter("TrailerPoolFix", sap.ui.model.FilterOperator.EQ, sTrailerPoolFix);
		var oBinding = oTable.getBinding("items");
		oBinding.filter(this.oTrailerPoolFilter);
	},

	onTrailerSubPoolDialogConfirm: function (oEvent) {
		var sTrailerSubPoolFix = "";
		var sTrailerSubPoolText = "";

		var aContext = oEvent.getParameter("selectedContexts");

		if (aContext.length) {
			sTrailerSubPoolFix = aContext.map(function (oContext) {
				return oContext.getObject().TrailerSubpoolFix;
			}).join(", ");

			sTrailerSubPoolText = aContext.map(function (oContext) {
				return oContext.getObject().TrailerSubpoolText;
			}).join(", ");
		}

		oEvent.getSource().getBinding("items").filter([]);

		this._myDialogThis.selectedTrailerSubPool(sTrailerSubPoolFix, sTrailerSubPoolText);

		this._myDialog.destroy();
	},

	onTrailerSubPoolDialogSearch: function (oEvent) {
		var sValue = oEvent.getParameter("value");
		// var oFilters = this._initialFilterDoor();
		var oFilters = [];
		var oFilter = null;

		if (sValue !== "") {
			oFilters.push(this.oTrailerPoolFilter);
			oFilter = new sap.ui.model.Filter("TrailerSubpoolText", sap.ui.model.FilterOperator.Contains, sValue);
			oFilters.push(oFilter);
		}

		var oBinding = oEvent.getSource().getBinding("items");
		oBinding.filter(oFilters);
	},

	onTrailerSubPoolDialogCancel: function () {
		this._myDialog.destroy();
	}
};