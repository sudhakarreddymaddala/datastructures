sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"com/westernacher/yl/trailercheck/demo/dialogController/YardDialog",
	"com/westernacher/yl/trailercheck/demo/dialogController/SignatureDialog",
	"com/westernacher/yl/trailercheck/demo/dialogController/PictureDialog",
	"com/westernacher/yl/trailercheck/demo/dialogController/CheckDialog",
	"com/westernacher/yl/trailercheck/demo/dialogController/ParkingDialog",
	"com/westernacher/yl/trailercheck/demo/dialogController/TrailerPoolDialog",
	"com/westernacher/yl/trailercheck/demo/dialogController/TrailerSubPoolDialog"
], function (Controller, YardDialog, SignatureDialog, PictureDialog, CheckDialog, ParkingDialog, TrailerPoolDialog, TrailerSubPoolDialog) {
	"use strict";

	return Controller.extend("com.westernacher.yl.trailercheck.demo.util.BaseController", {
		_AppStart: false,

		getRouter: function () {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},

		onNavigationBack: function () {
			var oHistory = sap.ui.core.routing.History.getInstance(),
				sPreviousHash = oHistory.getPreviousHash();

			if (sPreviousHash !== undefined) {
				// The history contains a previous entry
				history.go(-1);
			} else {
				this.getOwnerComponent().getRouter().navTo("tasklist", {}, false);
			}
		},

		openYardSelectionDialog: function (oThis) {
			YardDialog.openYardDialog(oThis);
		},

		openPictureDialog: function (oThis, oImage, sTitle, bDeleteVisble) {
			PictureDialog.openPictureDialog(oThis, "", oImage, sTitle, bDeleteVisble);
		},

		openSignatureDialog: function (oThis, sType, oObject, sTitle) {
			SignatureDialog.openSignatureDialog(oThis, "", sType, oObject, sTitle);
		},

		openCheckDialog: function (oThis, oObject, sTitle, sType) {
			CheckDialog.openCheckDialog(oThis, "", oObject, sTitle, sType);
		},

		openParkingSelectionDialog: function (oThis, sYardId) {
			ParkingDialog.openParkingDialog(oThis, "", sYardId);
		},

		openTrailerPoolSelectionDialog: function (oThis) {
			TrailerPoolDialog.openTrailerPoolDialog(oThis, "");
		},

		openTrailerSubPoolSelectionDialog: function (oThis, sParent, sTrailerPoolFix) {
			TrailerSubPoolDialog.openTrailerSubPoolDialog(oThis, sParent, sTrailerPoolFix);
		},

		_generatePictureName: function (sPrePictureName) {
			var n = new Date(),
				d = "0" + n.getDate(),
				h = "0" + n.getHours(),
				m = "0" + n.getMinutes(),
				ms = "00" + n.getMilliseconds();
			var sFileName;

			sFileName = sPrePictureName + ms.substr(ms.length - 3) + "_" + n.getFullYear() + (n.getMonth() - 1) + d.substr(d.length - 2) + h.substr(
					h
					.length -
					2) +
				m.substr(m.length - 2) + ".png";

			return sFileName;
		},

		getI18nText: function (cValue) {
			var oBundle = this.getView().getModel("i18n").getResourceBundle();
			var sText = oBundle.getText(cValue);

			return sText;
		},

		_checkResponse: function (oData) {
			var i;
			var oBody;
			var oReturn = {};

			if (oData.__batchResponses[0].hasOwnProperty("response")) {
				oBody = oData.__batchResponses[0].response.body;

				oReturn.error = true;

				var oErrorDetails = JSON.parse(oBody).error.innererror.errordetails;

				var sMessageText = "";

				for (i = 0; i < oErrorDetails.length; i++) {
					sMessageText = sMessageText + "\n\n- " + oErrorDetails[i].code + "\n- " + oErrorDetails[i].message;
				}

				oReturn.errorMessage = sMessageText;
			} else {
				oReturn.error = false;
				oReturn.errorMessage = "";
			}

			return oReturn;
		},

		_getModelData: function (sModelName, sPath) {
			var oModel = this.getView().getModel(sModelName);
			return oModel.getProperty(sPath);
		},

		_readImages: function (oThis, sKey) {
			var oModel = this.getView().getModel();
			var oFilter = new sap.ui.model.Filter("ParentKey", "EQ", sKey);

			var mParameters = {
				success: function (oData) {
					oThis._imageListLoaded(oData);
				},
				error: function () {
					sap.m.MessageToast.show("Error while retrieving images");
				},
				filters: [oFilter]
			};

			var sEntitySet = "YardTaskATFDocumentSet";

			oModel.read("/" + sEntitySet,
				mParameters
			);
		},

		_deleteImage: function (oThis, oPicture) {
			var sDeleteImage = "/YardTaskATFDocumentSet(guid'{$}')/$value";
			var oModel = oThis.getView().getModel();
			//oModel.setUseBatch(false);

			oModel.remove(sDeleteImage.replace("{$}", oPicture.Key), {
				urlParameters: null,
				context: null,
				async: true,
				success: function (oData) {
					//oModel.setUseBatch(true);
					sap.m.MessageToast.show("Picture deleted");
				},
				error: function () {
					//oModel.setUseBatch(true);
					sap.m.MessageToast.show("Error while deleting images");
				}
			});
		},

		_YardTaskCancel: function (oThis, oCurrentItemData) {
			var ofunctionParams = {
				YardTaskNo: oCurrentItemData.YardTaskNo,
				YardNo: oCurrentItemData.YardNo
			};

			var oModel = oThis.getView().getModel();

			oThis._oBusyDialog.open();

			oModel.callFunction("/RejectYardTask", {
				method: "POST",
				urlParameters: ofunctionParams,
				success: function (oData, oResponse) {
					oThis._oBusyDialog.close();
					//sap.m.MessageBox.information(that.getI18nText("ConfirmationMessage_Success"));
				},
				error: function (oError) {
					oThis._oBusyDialog.close();
					//sap.m.MessageBox.error(that.getI18nText("ConfirmationMessage_Error"));
				}
			});
		}

	});

});