sap.ui.define([
	"sap/ui/core/Control",
	"com/westernacher/yl/trailercheck/demo/util/Signature"
], function(Control, Signature) {
	"use strict";
	
	return Control.extend("com.westernacher.yl.trailercheck.demo.util.SignaturePad", {
		signaturePad: null,

		resizeCanvas: function resizeCanvas() {
			var canvas = document.querySelector("canvas");
			if (canvas) {
				var ratio = Math.max(window.devicePixelRatio || 1, 1);
				canvas.width = canvas.offsetWidth * ratio;
				canvas.height = canvas.offsetHeight * ratio;
				//canvas.clientWidth = iWidth * ratio;
				canvas.getContext("2d").scale(ratio, ratio);
			}
		},
		onAfterRendering: function() {
			var canvas = document.querySelector("canvas");
			try {
				this.signaturePad = new Signature(canvas);
			} catch (e) {
				//console.error(e);
			}
		},
		clear: function() {
			if (this.signaturePad) {
				this.signaturePad.clear();
			}
		},
		export: function() {
			return this.signaturePad.toDataURL();
		},

		setBackgroud: function(dataUrl) {
			this.signaturePad.fromDataURL(dataUrl);
		},

		isSignature: function() {
			return this.signaturePad.isSignature();
		},

		signatureOff: function() {
			this.signaturePad.off();
		},

		signatureOn: function() {
			this.signaturePad.on();
		},

		metadata: {
			properties: {
				"width": {
					type: "sap.ui.core.CSSSize",
					defaultValue: "300px"
				},
				"height": {
					type: "sap.ui.core.CSSSize",
					defaultValue: "100px"
				},
				"thickness": {
					type: "int",
					defaultValue: 2
				},
				"bgcolor": {
					type: "sap.ui.core.CSSColor",
					defaultValue: "lightgrey"
				},
				"signcolor": {
					type: "sap.ui.core.CSSColor",
					defaultValue: "black"
				}
			}
		},

		renderer: function(oRm, oControl) {
			var thickness = parseInt(oControl.getProperty("thickness"), 10);
			oRm.write("<div");
			oRm.writeControlData(oControl);
			oRm.addStyle("width", oControl.getProperty("width"));
			oRm.addStyle("height", oControl.getProperty("height"));
			oRm.addStyle("background-color", oControl.getProperty("bgcolor"));
			oRm.writeStyles();
			//oRm.addClass("rpb");        // add a CSS class for styles common to all control instances
			oRm.writeClasses();
			oRm.write(">");
			//TODO Write a canvas
			oRm.write("<canvas width='" + oControl.getProperty("width") + "' " +
				"height='" + oControl.getProperty("height") + "'");
			oRm.writeControlData(oControl);
			oRm.addStyle("width", oControl.getProperty("width"));
			oRm.addStyle("height", oControl.getProperty("height"));
			oRm.writeStyles();
			oRm.write("></canvas>");
			oRm.write("</div>");
		}
	
	});
 });