jQuery.sap.declare("com.westernacher.yl.trailercheck.demo.util.Formatter");

com.westernacher.yl.trailercheck.demo.util.Formatter = {

	uppercaseFirstChar: function (sStr) {
		return sStr.charAt(0).toUpperCase() + sStr.slice(1);
	},

	sliderAnswer: function (sAnswer) {
		switch (sAnswer) {
		case "1":
			return 2;

		case "0":
			return 0;

		default:
			return 1;
		}
	},

	StatusName: function (sStatus) {
		var oBundle = this.getModel("i18n").getResourceBundle();

		if (sStatus === "0") {
			return oBundle.getText("SatusName_No");
		} else if (sStatus === "1") {
			return oBundle.getText("SatusName_Yes");
		} else {
			return oBundle.getText("SatusName_ToDo");
		}
	},

	StatusStatus: function (sStatus) {
		if (sStatus === "0") {
			return "Error";
		} else if (sStatus === "1") {
			return "Success";
		} else {
			return "None";
		}
	},

	StatusIcon: function (sStatus) {
		if (sStatus === 0) {
			return "sap-icon://sys-cancel";
		} else if (sStatus === 2) {
			return "sap-icon://sys-enter";
		} else {
			return "sap-icon://sys-help";
		}
	},

	iconDirection: function (sDirection) {
		if (sDirection === "I") {
			return "sap-icon://download";
		} else {
			return "sap-icon://upload";
		}
	},

	emptyState: function (bEmpty) {
		if (bEmpty) {
			return "Leer";
		} else {
			return "Voll";
		}
	},

	statusState: function (sStatus) {
		if (sStatus === "03") {
			return "Success";
		} else {
			return "Warning";
		}
	},

	statusText: function (sStatus) {
		var oBundle = this.getModel("i18n").getResourceBundle();

		if (sStatus === "03") {
			return oBundle.getText("YPStatusText_Started");
		} else {
			return oBundle.getText("YPStatusText_NotStarted");
		}
	},

	iconStatus: function (sStatus) {
		if (sStatus === "Active") {
			return "sap-icon://circle-task-2";
		} else {
			return "sap-icon://circle-task";
		}
	},

	iconColorStatus: function (sStatus) {
		if (sStatus === "Active") {
			return "#009900";
		} else {
			return "";
		}
	},

	ParkingIsEmptyIcon: function (bIsEmpty) {
		if (bIsEmpty) {
			return "sap-icon://accept";
		} else {
			return "";
		}
	},

	ListDateFormat: function (oDate) {
		var dDateformat = sap.ui.core.format.DateFormat.getDateInstance({
			pattern: "dd.MM.yyyy HH:mm"
		});

		return dDateformat.format(oDate);
	},

	convertToNumber: function (sValue) {
		var fValue = parseFloat(sValue);

		return fValue;
	}

};