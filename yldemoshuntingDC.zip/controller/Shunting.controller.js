var tutype = "";
var tunumber = "";
var yardTaskNo = "";
var YardNoFinal = "";

var comboBoxChanged = false;
sap.ui.define([
	"westernacher/yl/shunting/v2/util/BaseController",
	"sap/m/MessageBox",
	"westernacher/yl/shunting/v2/util/Formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/json/JSONModel"
], function (BaseController, MessageBox, Formatter, Filter, FilterOperator, JSONModel) {
	"use strict";

	return BaseController.extend("westernacher.yl.shunting.v2.controller.Shunting", {
		_OriginalStatus: "",
		_OriginalDestination: "",
		_CurrentPath: "",
		formatter: Formatter,

		onInit: function () {

			// sap.ui.core.BusyIndicator.show(3);

			this.getRouter().attachRoutePatternMatched(this.onRouteMatched, this);

			this._oAppView = this.getOwnerComponent().getModel("AppView");
			var oButtonVisiblityModel = new JSONModel({
				startVisible: false,
				confirmVisible: false,
				rejectVisible: false,
				backVisible: false
			});

			this.getView().setModel(oButtonVisiblityModel, "buttonsVisible");
			var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/ZYL_SHUNTING_SRV/");
			this.getView().setModel(oModel, "functionModel");
			// var that = this;
			// var oComboBox = that.getView().byId("combobox1");
			var addtext = "";
			// that.getView().byId("Trailerhooked").focus();

			/*	this.getView().byId("combobox1").setFilterFunction(function (sTerm, oItem) {
					// A case-insensitive 'string contains' filter
					return oItem.getText().match(new RegExp(sTerm, "i")) || oItem.getKey().match(new RegExp(sTerm, "i"));
				});*/

			oModel.read("/StorBinDestShSet", {
				success: function (oData, oResponse) {

					var arrayData = oData.results;
					for (var i = 0; i < arrayData.length; i++) {

						if (arrayData[i].Kzler === true && arrayData[i].Reserved === true) {
							addtext = "Reserved";
						} else if (arrayData[i].Kzler === true && arrayData[i].Reserved === false) {
							addtext = "Empty";
						} else if (arrayData[i].Kzler === false && arrayData[i].Reserved === true) {
							addtext = "Occupied and Reserved";
						} else if (arrayData[i].Kzler === false && arrayData[i].Reserved === false) {
							addtext = "Occupied";
						}
						arrayData[i]["addtext"] = addtext;
					}
					var jsondata = {
						items: arrayData

					};
					var jsonModel = new sap.ui.model.json.JSONModel();
					jsonModel.setSizeLimit(500);
					jsonModel.setData(jsondata);
					this.getView().setModel(jsonModel, "oComboBoxModel");

					/*oComboBox.bindAggregation("items", "/items", new sap.ui.core.ListItem({
						text: "{Lgpla}",
						additionalText: "{addtext}"

					}));
*/
				}.bind(this)
			});

		},

		onRouteMatched: function (oEvent) {
			$.sap.iteration = 0;

			// this.getView().byId("tuNumber").setText("");
			// this.getView().byId("tuType").setText("");
			this._oAppView.setProperty("/TuNumber", "");
			this._oAppView.setProperty("/TuType", "");
			this._oAppView.setProperty("/TemperatureHigh", "");
			this._oAppView.setProperty("/duration", "");
			this._oAppView.setProperty("/startTime", "");

			// this.getView().byId("combobox1").setPlaceholder("");
			// this.getView().byId("licPlate").setText("");
			// this.getView().byId("storbinsrc").setText("");
			this._oAppView.setProperty("/oneSealFlag", "");

			this._oAppView.setProperty("/LicencePlate", "");
			this._oAppView.setProperty("/StorBinsrc", "");

			// this.getView().byId("temperatureLow").setText("");
			// this.getView().byId("oneSealFlag").setText("");
			// this.getView().byId("duration").setText("");
			// this.getView().byId("startTime").setText("");
			this._oAppView.setProperty("/duration", "");
			this._oAppView.setProperty("/startTime", "");

			this.getView().byId("Trailerhooked").setSelected(false);

			yardTaskNo = oEvent.getParameter("arguments").yardTaskNo;
			var yardNo = oEvent.getParameter("arguments").yardNo;

			 if ($.sap.countStep === 0) {
			 	if (yardTaskNo) {
			 		this.getView().getModel().metadataLoaded().then(function () {

			 			var sObjectPath = "/CurrentShuntingTaskSet";
			 			this._bindView(sObjectPath);
			 		}.bind(this));

			 	}
			 }

			var oModel = this.getView().getModel();
			// var that = this;
			// var oComboBox = that.getView().byId("combobox1");
			var addtext = "";
			// that.getView().byId("Trailerhooked").focus();

			/*	this.getView().byId("combobox1").setFilterFunction(function (sTerm, oItem) {
					// A case-insensitive 'string contains' filter
					return oItem.getText().match(new RegExp(sTerm, "i")) || oItem.getKey().match(new RegExp(sTerm, "i"));
				});*/

			oModel.read("/StorBinDestShSet", {
				success: function (oData, oResponse) {

					var arrayData = oData.results;
					for (var i = 0; i < arrayData.length; i++) {

						if (arrayData[i].Kzler === true && arrayData[i].Reserved === true) {
							addtext = "Reserved";
						} else if (arrayData[i].Kzler === true && arrayData[i].Reserved === false) {
							addtext = "Empty";
						} else if (arrayData[i].Kzler === false && arrayData[i].Reserved === true) {
							addtext = "Occupied and Reserved";
						} else if (arrayData[i].Kzler === false && arrayData[i].Reserved === false) {
							addtext = "Occupied";
						}
						arrayData[i]["addtext"] = addtext;
					}
					var jsondata = {
						items: arrayData

					};

					var jsonModel = new sap.ui.model.json.JSONModel();
					jsonModel.setSizeLimit(500);
					jsonModel.setData(jsondata);
					this.getView().setModel(jsonModel, "oComboBoxModel");

					/*oComboBox.bindAggregation("items", "/items", new sap.ui.core.ListItem({
						text: "{Lgpla}",
						additionalText: "{addtext}"

					}));*/

				}.bind(this)
			});

			var yardFilter = new Filter('YardTaskNo', 'EQ', yardTaskNo);
			var yardNoFilter = new Filter('YardTaskNo', 'EQ', yardNo);
			var readurl = "/CurrentShuntingTaskSet";
			var that = this;
			// that.getView().byId("Trailerhooked").focus();

			oModel.read(readurl, {
				filters: [yardFilter, yardNoFilter],
				success: function (oData, oResponse) {

					var oCurrentTask = oData.results[0];

					// that.getView().byId("combobox1").setPlaceholder(oCurrentTask.StorBindst);
					this._oAppView.setProperty("/comboBoxPlaceHolder", oCurrentTask.StorBindst);
					YardNoFinal = oCurrentTask.YardNo;
					tutype = oCurrentTask.TuType;
					tunumber = oCurrentTask.TuNumber;

					// that.getView().byId("tuNumber").setText(tunumber);
					this._oAppView.setProperty("/TuNumber", tunumber);

					// that.getView().byId("licPlate").setText(oCurrentTask.LicencePlate);
					this._oAppView.setProperty("/LicencePlate", oCurrentTask.LicencePlate);
					// that.getView().byId("tuType").setText(tutype);
					this._oAppView.setProperty("/TuType", tutype);

					if ($.sap.iteration === 0) {
						that.getView().byId("Trailerhooked").setSelected(oCurrentTask.TrailerHooked);
						$.sap.iteration = 1;

					}

					// that.getView().byId("storbinsrc").setText(oCurrentTask.StorBinsrc);
					this._oAppView.setProperty("/StorBinsrc", oCurrentTask.StorBinsrc);

					// that.getView().byId("temperatureLow").setText(oCurrentTask.TemperatureHigh);
					this._oAppView.setProperty("/TemperatureHigh", oCurrentTask.TemperatureHigh);

					if (oCurrentTask.OneSeal === true) {
						this._oAppView.setProperty("/oneSealFlag", "Yes");
						// that.getView().byId("oneSealFlag").setText("Yes");
					} else {
						// that.getView().byId("oneSealFlag").setText("No");
						this._oAppView.setProperty("/oneSealFlag", "No");
					}
					this._oAppView.setProperty("/duration", oCurrentTask.DurationPlan + " " + oCurrentTask.TimeUnit);
					this._oAppView.setProperty("/startTime", oCurrentTask.StartTmstmpPlan.getHours() + ":" + oCurrentTask.StartTmstmpPlan
						.getMinutes());

					/* that.getView().byId("duration").setText(oCurrentTask.DurationPlan + " " + oCurrentTask.TimeUnit);
					that.getView().byId("startTime").setText(oCurrentTask.StartTmstmpPlan.getHours() + ":" + oCurrentTask.StartTmstmpPlan
						.getMinutes());*/
					$.sap.countStep = $.sap.countStep + 1;

				}.bind(this)
			});

		},
		_bindView: function (sObjectPath) {

			this.getView().bindElement({
				path: sObjectPath,
				events: {
					dataReceived: function (oEvent) {

						var myModel = this.getOwnerComponent().getModel();
						sap.ui.getCore().setModel(myModel);
						var yardFilter = new Filter('YardTaskNo', 'EQ', yardTaskNo);
						var readurl = "/CurrentShuntingTaskSet";
						var that = this;
						// that.getView().byId("Trailerhooked").focus();
						var iter = 0;

						myModel.read(readurl, {
							filters: [yardFilter],
							success: function (oData, oResponse) {

								var oCurrentTask = oData.results[0];

								// that.getView().byId("combobox1").setPlaceholder(oCurrentTask.StorBindst);
								this._oAppView.setProperty("/comboBoxPlaceHolder", oCurrentTask.StorBindst);

								YardNoFinal = oCurrentTask.YardNo;
								tutype = oCurrentTask.TuType;
								tunumber = oCurrentTask.TuNumber;

								// that.getView().byId("tuNumber").setText(tunumber);
								this._oAppView.setProperty("/TuNumber", tunumber);

								// that.getView().byId("licPlate").setText(oCurrentTask.LicencePlate);
								this._oAppView.setProperty("/LicencePlate", oCurrentTask.LicencePlate);

								// that.getView().byId("tuType").setText(tutype);
								this._oAppView.setProperty("/TuType", tutype);

								if ($.sap.iteration === 0) {
									that.getView().byId("Trailerhooked").setSelected(oCurrentTask.TrailerHooked);
									$.sap.iteration = 1;

								}

								// that.getView().byId("storbinsrc").setText(oCurrentTask.StorBinsrc);
								this._oAppView.setProperty("/StorBinsrc", oCurrentTask.StorBinsrc);

								// that.getView().byId("temperatureLow").setText(oCurrentTask.TemperatureHigh);
								this._oAppView.setProperty("/TemperatureHigh", oCurrentTask.TemperatureHigh);

								if (oCurrentTask.OneSeal === true) {
									this._oAppView.setProperty("/oneSealFlag", "Yes");
									// that.getView().byId("oneSealFlag").setText("Yes");
								} else {
									// that.getView().byId("oneSealFlag").setText("No");
									this._oAppView.setProperty("/oneSealFlag", "No");
								}
								that.getView().byId("duration").setText(oCurrentTask.DurationPlan + " " + oCurrentTask.TimeUnit);
								that.getView().byId("startTime").setText(oCurrentTask.StartTmstmpPlan.getHours() + ":" + oCurrentTask.StartTmstmpPlan
									.getMinutes());

								/*	this._oAppView.setProperty("/duration", oCurrentTask.DurationPlan + " " + oCurrentTask.TimeUnit);
									this._oAppView.setProperty("/startTime", oCurrentTask.StartTmstmpPlan.getHours() + ":" + oCurrentTask.StartTmstmpPlan
									.getMinutes());*/

								$.sap.countStep = $.sap.countStep + 1;

							}
						});

						this._manageButtonsAvailability(oCurrentTask);

					}.bind(this)
				}
			});

			var oCurrentTask = this.getView().getModel().getProperty(sObjectPath);
			if (oCurrentTask) {
				this._manageButtonsAvailability(oCurrentTask);
			}

		},
		onComboboxChange: function (oEvent) {
			comboBoxChanged = true;
		},

		_manageButtonsAvailability: function (oCurrentTask) {
			sap.ui.core.BusyIndicator.hide();
			 var that = this;
			 that.getView().byId("Trailerhooked").focus();
			 var oModel = this.getView().getModel("buttonsVisible");
			 if (oCurrentTask && oCurrentTask.LifecycleStatus === "02") {
			 	this.getView.byId("start").setVisible(true);
			 	this.getView.byId("confirm").setVisible(false);
			 	oModel.setProperty("/startVisible", true);
			 	oModel.setProperty("/confirmVisible", false);
			 	oModel.setProperty("/rejectVisible", false);
			 	oModel.setProperty("/backVisible", true);
			 	oModel.setProperty("/breakVisible", false);
			 } else if (oCurrentTask && oCurrentTask.LifecycleStatus === "03") {
			 	this.getView.byId("start").setVisible(false);
			 	this.getView.byId("confirm").setVisible(true);
			 	oModel.setProperty("/rejectVisible", true);
			 	oModel.setProperty("/backVisible", false);
			 	oModel.setProperty("/breakVisible", true);
			 } else {
			 	this.getView.byId("start").setVisible(false);
			 	this.getView.byId("confirm").setVisible(false);
			 	oModel.setProperty("/rejectVisible", false);
			 	oModel.setProperty("/backVisible", true);
			 	oModel.setProperty("/breakVisible", false);
			 }

			 if (!oCurrentTask.ShowStartButton) {
			 	oModel.setProperty("/startVisible", false);
			 }
			 if (!oCurrentTask.ShowConfirmButton) {
			 	oModel.setProperty("/confirmVisible", false);
			 }

		},
		onBStartShunting: function () {
			// this.getView().byId("combobox1").setEnabled("true");
			this._oAppView.setProperty("/comboBoxEnabled", true);
			var oObject = this.getView().byId("idTYOShunt");
			var oSelectedItem = oObject.getSelectedItem();

			if (!oSelectedItem) {
				sap.m.MessageToast.show(this.getI18nText("Message_SelectTask"));

				return;
			}

			var aContext = oSelectedItem.getBindingContext();
			var oItemObject = aContext.getObject();

			if (oItemObject.Status === "done") {
				sap.m.MessageToast.show(this.getI18nText("Message_TaskDone"));

				return;
			}

			var sPath = aContext.getPath();
			var objectId = sPath.replace("/TUSet/", "");

			this.getRouter().navTo("secureloading", {
				objectId: objectId
			}, false);
		},
		onNavBack: function () {
			this.getRouter().navTo("mafi", {}, true);
			$.sap.countStep = 0;
		},
		onBCancelPress: function () {
			var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;

			var myThis = this;
		},
		onBStopBreakPress: function () {
			var oModel = this.getView().getModel();
			oModel.setProperty(this._CurrentPath + "/Status", "stop");

			this.getRouter().navTo("tasklist", {});
		},

		onBDestinationChangePress: function () {
			this.openConfirmationDialog(this, "", this.getI18nText("ConfirmationDialog_Title"), "");
		},

		onConfirmationDialogComplette: function (sDialogId, sValue) {

			var oView = this.getView();
			var oBinding = oView.getBindingContext();
			var oTask = oBinding.getObject().CurrentTask;
			if (!oTask) {
				return;
			}
			var sPath = "/" + oTask.__ref;
			oView.getModel().update(sPath, {
				"StorBindst": sValue
			}, {
				success: function (oResponse) {
					sap.m.MessageToast.show(this.getI18nText("Message_UpdateSuccess"));
				}
			});
		},
		onStartTaskButtonPress: function () {
			//StartYardTask
			// this.getView().byId("combobox1").setEditable(true);
			this._oAppView.setProperty("/comboBoxEnabled", true);

			this.getView().byId("Trailerhooked").setEditable(true);
			var oBinding = this.getView().getBindingContext();
			var sYardNo = YardNoFinal;
			var sYardtaskNo = yardTaskNo;
			var functionParams = {
				YardNo: sYardNo,
				YardTaskNo: sYardtaskNo
			};
			var fnSuccess = function (oData, oResponse) {
				//oModel.refresh();
				sap.m.MessageToast.show(this.getI18nText("Message_SuccessStart"));
				this.getView().getModel().refresh(true);
				var that = this;
				that.getView.byId("confirm").setVisible(true);
				that.getView.byId("start").setVisible(false);
			}.bind(this);
			var fnError = function (oError) {
				var oErrorResponse = JSON.parse(oError.responseText);
				var sErrorText = oErrorResponse.error.message.value;
				if (sErrorText) {
					sap.m.MessageToast.show(sErrorText);
				} else {
					sap.m.MessageToast.show(this.getI18nText("Message_UnexpectedErrorStart"));
				}

			}.bind(this);
			this.callFunctionImport('StartYardTask', functionParams, fnSuccess, fnError);
		},

		onUpdate: function () {
			//StartYardTask
			// this.getView().byId("combobox1").setEditable(true);
			this._oAppView.setProperty("/comboBoxEnabled", true);

			var oBinding = this.getView().getBindingContext();
			var oView = this.getView();
			var dest = this._oAppView.getProperty("/comboBoxSelectedKey");
			var trailerHooked = oView.byId("Trailerhooked").getSelected();
			var placeholder;

			var sPath = "/CurrentShuntingTaskSet(YardTaskNo='" + yardTaskNo + "')";
			oView.getModel().update(sPath, {
				"StorBindst": dest,
				"TrailerHooked": trailerHooked

			}, {
				success: function (oResponse) {
					if (dest !== "") {
						placeholder = dest;
						sap.m.MessageToast.show(this.getI18nText("Message_UpdateSuccess"));

					} else {
						placeholder = this._oAppView.getProperty("/comboBoxPlaceHolder");

					}
					var sYardNo = YardNoFinal;
					var sYardtaskNo = yardTaskNo;
					var functionParams = {
						YardNo: sYardNo,
						YardTaskNo: sYardtaskNo
					};
					var that = this;
					var fnSuccess = function (oData, oResponse) {
						//oModel.refresh();
						sap.m.MessageToast.show(this.getI18nText("Message_SuccessConfirm"));
						this.getOwnerComponent().getTargets().display("mafi");
						$.sap.ManualRefresh = true;
						$.sap.countStep = 0;
						var router = sap.ui.core.UIComponent.getRouterFor(that);
						router.navTo("mafi");
						// this.getView().getModel().refresh(true);
					}.bind(this);
					var fnError = function (oError) {
						var oErrorResponse = JSON.parse(oError.responseText);
						var sErrorText = oErrorResponse.error.message.value;
						if (sErrorText) {
							if (placeholder.includes("SOMEWHERE")) {
								sap.m.MessageToast.show("The Yard Task can't be confirmed. Please set correct destination location.");
							} else {
								sap.m.MessageToast.show("The Yard Task can't be confirmed.");
							}

						} else {
							sap.m.MessageToast.show(this.getI18nText("Message_UnexpectedErrorConfirm"));
						}

					}.bind(this);
					this.callFunctionImport('ConfirmYardTask', functionParams, fnSuccess, fnError);

				}.bind(this),
				error: function (oError) {
					var disMsg = JSON.parse(oError.responseText).error.message.value;
					this._handleMessageBoxOpen("The Yard Task can't be confirmed because it was not started yet!", "error");

				}.bind(this),
			});
		},
		onConfirmationButtonPress: function () {
			this.onUpdate();
		},

		_handleMessageBoxOpen: function (sMessage, sMessageBoxType) {
			MessageBox[sMessageBoxType](sMessage, {
				actions: [MessageBox.Action.OK],
				onClose: function (oAction) {
					if (oAction === MessageBox.Action.OK) {}
				}.bind(this)
			});
		},
		onRejectButtonPress: function () {
			//StartYardTask
			var oBinding = this.getView().getBindingContext();
			var sYardNo = YardNoFinal;
			var sYardtaskNo = yardTaskNo;
			var functionParams = {
				YardNo: sYardNo,
				YardTaskNo: sYardtaskNo
			};
			var fnSuccess = function (oData, oResponse) {
				sap.m.MessageToast.show(this.getI18nText("Message_SuccessReject"));
				this.getView().getModel().refresh(true);
			}.bind(this);
			var fnError = function (oError) {
				var oErrorResponse = JSON.parse(oError.responseText);
				var sErrorText = oErrorResponse.error.message.value;
				if (sErrorText) {
					sap.m.MessageToast.show(sErrorText);
				} else {
					sap.m.MessageToast.show(this.getI18nText("Message_UnexpectedErrorReject"));
				}

			}.bind(this);
			this.callFunctionImport('RejectYardTask', functionParams, fnSuccess, fnError);
		},
		onBreakButtonPress: function (oEvent) {
			if (!this._breakDialog) {
				this._breakDialog = sap.ui.xmlfragment("westernacher.yl.shunting.v2.fragment.BreakDialog", this);
				this.getView().addDependent(this._breakDialog);
			}
			this._breakDialog.open();
		}
	});

});