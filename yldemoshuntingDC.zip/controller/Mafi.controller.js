$.sap.GlobalRefreshCount = 0;
$.sap.ManualRefresh = false;
$.sap.countStep = 0;


sap.ui.define([
	"westernacher/yl/shunting/v2/util/BaseController",
	"sap/m/MessageBox",
	"westernacher/yl/shunting/v2/util/Formatter",
	"sap/ui/model/Filter",
	'sap/ui/core/BusyIndicator',
	"sap/ui/model/FilterOperator",
	"sap/ui/model/json/JSONModel"
], function (BaseController, MessageBox, Formatter, Filter, BusyIndicator, FilterOperator, JSONModel) {
	"use strict";

	return BaseController.extend("westernacher.yl.shunting.v2.controller.Mafi", {
		formatter: Formatter,
		onInit: function () {

			var oProductsSet = new sap.ui.model.json.JSONModel();
			this.getView().setModel(oProductsSet, "oProductsSet");

			var myModel = this.getOwnerComponent().getModel();
			sap.ui.getCore().setModel(myModel);

			var readurl = "/CurrentShuntingTaskSet";

			myModel.read(readurl, {
				success: function (oData, oResponse) {

					oProductsSet.setData(oData);

				},
				error: function () {

					that._handleMessageBoxOpen("No shunting task found!", "error");

				}

			});

			// if ($.sap.countStep === 0) {
			var that = this;
			$.sap.ShuntingfGoAutoRefresh = setInterval(function () {
				// clearInterval(	$.sap.ShuntingfGoAutoRefresh);
				that.autoRefresh();

			}, 1000 * 15);
			// }
			this.getRouter().attachRoutePatternMatched(this.onRouteMatched, this);

		},

		onExit: function () {
			// clearInterval(	$.sap.ShuntingfGoAutoRefresh);
		},

		onRouteMatched: function (oEvent) {

			BaseController._AppStart = true;
			var that = this;

			if ($.sap.ManualRefresh === true) {
				var oProductsSet = new sap.ui.model.json.JSONModel();
				this.getView().setModel(oProductsSet, "oProductsSet");

				var myModel = this.getOwnerComponent().getModel();
				sap.ui.getCore().setModel(myModel);

				var readurl = "/CurrentShuntingTaskSet";
			
				myModel.read(readurl, {
					success: function (oData, oResponse) {
						if (oData.results.length > 0) {
							oProductsSet.setData(oData);
						}
						// else {
						// 	that._handleMessageBoxOpen("No shunting task found!", "warning");
						// }

					}

				});
			}

			// if ($.sap.countStep === 0) {
			// 	// clearInterval(this.fGoAutoRefresh);

			// 	this.fGoAutoRefresh = setInterval(function () {

			// 		that.autoRefresh();

			// 	}, 1000 * 15);
			// }

		},

		autoRefresh: function () {

			if ($.sap.countStep === 0) {
				var oProductsSet = this.getView().getModel("oProductsSet");
				var myModel = this.getOwnerComponent().getModel();
				var readurl = "/CurrentShuntingTaskSet";

				myModel.read(readurl, {
					success: function (oData, oResponse) {
						oProductsSet.setData(oData);

					},
					error: function () {

						that._handleMessageBoxOpen("No shunting task found!", "error");

					}

				});
			}
		},

		onBRefreshPress: function () {
			// $.sap.ManualRefresh = true;
			// this.onRouteMatched();
			var oProductsSet = this.getView().getModel("oProductsSet");
			var myModel = this.getOwnerComponent().getModel();
			var readurl = "/CurrentShuntingTaskSet";

			myModel.read(readurl, {
				success: function (oData, oResponse) {
					oProductsSet.setData(oData);

				},
				error: function () {

					that._handleMessageBoxOpen("No shunting task found!", "error");

				}

			});

		},

		onBConfirmationPress: function (oEvent) {
			var oBindingContext = oEvent.getParameter("listItem").getBindingContext("oProductsSet");
			var path = oBindingContext.getPath();
			var index = "";
			var index1 = "";
			var index2 = "";
			var index3 = "";
			if (path.length === 10) {
				index = path.charAt(path.length - 1);
			} else if (path.length === 11) {
				index1 = path.charAt(path.length - 1);
				index2 = path.charAt(path.length - 2);
				index = index2 + index1;
			} else if (path.length === 12) {
				index1 = path.charAt(path.length - 1);
				index2 = path.charAt(path.length - 2);
				index3 = path.charAt(path.length - 3);
				index = index3 + index2 + index1;
			}

			var newModel = this.getView().getModel("oProductsSet");
			var oData = newModel.getData();
			var ytNo = oData.results[index].YardTaskNo;
			this.onExit();
			this.getRouter().navTo("shunting", {
				yardTaskNo: ytNo,

			}, false);

			// }
		},

		// onBRefreshPress: function () {
		// 	this.onRouteMatched();
		// },

		_handleMessageBoxOpen: function (sMessage, sMessageBoxType) {
			MessageBox[sMessageBoxType](sMessage, {
				actions: [MessageBox.Action.OK],
				onClose: function (oAction) {
					if (oAction === MessageBox.Action.OK) {}
				}.bind(this)
			});
		},

	});

});