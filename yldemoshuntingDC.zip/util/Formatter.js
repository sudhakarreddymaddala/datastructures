jQuery.sap.declare("westernacher.yl.shunting.v2.util.Formatter");

westernacher.yl.shunting.v2.util.Formatter = {

	uppercaseFirstChar: function(sStr) {
		return sStr.charAt(0).toUpperCase() + sStr.slice(1);
	},

	StatusIcon: function(sStatus) {
		if (sStatus === "01") {
			return "sap-icon://pending";
		} else if (sStatus === "02") {
			return "sap-icon://media-play";
		} else if (sStatus === "03") {
			return "sap-icon://message-success";
		} else if (sStatus === "04") {
			return "sap-icon://stop";
		}
	},

	StatusColor: function(sStatus) {
		if (sStatus === "01") {
			return "#27a3dd";
		} else if (sStatus === "02") {
			return "#3fa45b";
		} else if (sStatus === "03") {
			return "#3fa45b";
		} else if (sStatus === "04") {
			return "#dc0d0e";
		}
	},

	UrgentIcon: function(bUrgent) {
		if (bUrgent) {
			return "sap-icon://warning";
		} else {
			return "";
		}
	},
	DateFormat: function(oDate) {
		if (oDate) {
			var localTime = oDate.getTime();
			var localOffset = oDate.getTimezoneOffset() * 60000;
			var oNewDate = new Date(localTime + localOffset);
			var sPatter = "dd.MM.YYYY HH:mm";
			var oFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
				pattern: sPatter
			});
			var sDate = oFormat.format(oNewDate);
			return sDate;
		} else {
			return '';
		}
	},
	StatusDateFormat: function(oDate) {
		var oCurrentDate = new Date();
		if (oDate > oCurrentDate) {
			return "Success";
		} else {
			return "Warning";
		}
	},
	StatusDurationFormat: function(sDurationPlan, sDurationActual) {
		if (parseInt(sDurationPlan) >= parseInt(sDurationActual)) {
			return "Success";
		} else {
			return "Warning";
		}
	}

};