jQuery.sap.declare("westernacher.yl.shunting.v2.dialogController.MafiDialog");

westernacher.yl.shunting.v2.dialogController.MafiDialog = {
	_myDialogNameSpace: "westernacher.yl.shunting.v2",
	_myDialogThis: undefined,
	_myDialog: undefined,
	_myDialogFragmentId: "",
	_myDialogParent: "",

	openMafiDialog: function(oThis, oInput, sParent) {
		this._myDialogThis = oThis;
		this._myDialogFragmentId = "idTSDMafi" + oThis.getView().getId();
		this._myDialogParent = sParent;
		this._MyDialogInput = oInput;

		if (!this._myDialog) {
			this._myDialog = sap.ui.xmlfragment(this._myDialogFragmentId,
				this._myDialogNameSpace + ".fragment.MafiDialog",
				this
			);
			this._myDialogThis.getView().addDependent(this._myDialog);
		}

		var oTable = sap.ui.getCore().byId(this._myDialogFragmentId + "--idTSDMafi");

		this._myDialog.open();

		oTable._resetSelection();
	},

	onMafiDialogSearchConfirm: function(oEvent) {
		var sMafiName = "";

		var aContext = oEvent.getParameter("selectedContexts");

		if (aContext.length) {
			sMafiName = aContext.map(function(oContext) {
				return oContext.getObject().Name;
			}).join(", ");
		}

		oEvent.getSource().getBinding("items").filter([]);
		this._myDialogThis.selectedMafi(this._myDialogThis, this._myDialogParent, this._MyDialogInput, sMafiName);
	},

	onMafiDialogSearch: function(oEvent) {
		var sValue = oEvent.getParameter("value");
		var oFilters = []; 
		var oFilter = null;

		if (sValue !== "") {
			oFilter = new sap.ui.model.Filter("Name", sap.ui.model.FilterOperator.Contains, sValue);
			oFilters.push(oFilter);
		}

		var oBinding = oEvent.getSource().getBinding("items");
		oBinding.filter(oFilters);
	}
};